--
-- PostgreSQL database dump
--

\restrict WvlNJr3bqBYGRdg5bcOhWv9ARkFq3o0Iuw8mpiVzraDk7BgFWGSuRJR3rVKFbqA

-- Dumped from database version 14.19
-- Dumped by pg_dump version 14.19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: timestamp_id(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.timestamp_id(table_name text) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
  DECLARE
    time_part bigint;
    sequence_base bigint;
    tail bigint;
  BEGIN
    time_part := (
      -- Get the time in milliseconds
      ((date_part('epoch', now()) * 1000))::bigint
      -- And shift it over two bytes
      << 16);

    sequence_base := (
      'x' ||
      -- Take the first two bytes (four hex characters)
      substr(
        -- Of the MD5 hash of the data we documented
        md5(table_name || '9a527909335f7bc315e4f2a7c140d457' || time_part::text),
        1, 4
      )
    -- And turn it into a bigint
    )::bit(16)::bigint;

    -- Finally, add our sequence number to our base, and chop
    -- it to the last two bytes
    tail := (
      (sequence_base + nextval(table_name || '_id_seq'))
      & 65535);

    -- Return the time part and the sequence part. OR appears
    -- faster here than addition, but they're equivalent:
    -- time_part has no trailing two bytes, and tail is only
    -- the last two bytes.
    RETURN time_part | tail;
  END
$$;


ALTER FUNCTION public.timestamp_id(table_name text) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_aliases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_aliases (
    id bigint NOT NULL,
    account_id bigint,
    acct character varying DEFAULT ''::character varying NOT NULL,
    uri character varying DEFAULT ''::character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.account_aliases OWNER TO postgres;

--
-- Name: account_aliases_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_aliases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_aliases_id_seq OWNER TO postgres;

--
-- Name: account_aliases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_aliases_id_seq OWNED BY public.account_aliases.id;


--
-- Name: account_conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_conversations (
    id bigint NOT NULL,
    account_id bigint,
    conversation_id bigint,
    participant_account_ids bigint[] DEFAULT '{}'::bigint[] NOT NULL,
    status_ids bigint[] DEFAULT '{}'::bigint[] NOT NULL,
    last_status_id bigint,
    lock_version integer DEFAULT 0 NOT NULL,
    unread boolean DEFAULT false NOT NULL
);


ALTER TABLE public.account_conversations OWNER TO postgres;

--
-- Name: account_conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_conversations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_conversations_id_seq OWNER TO postgres;

--
-- Name: account_conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_conversations_id_seq OWNED BY public.account_conversations.id;


--
-- Name: account_deletion_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_deletion_requests (
    id bigint NOT NULL,
    account_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.account_deletion_requests OWNER TO postgres;

--
-- Name: account_deletion_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_deletion_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_deletion_requests_id_seq OWNER TO postgres;

--
-- Name: account_deletion_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_deletion_requests_id_seq OWNED BY public.account_deletion_requests.id;


--
-- Name: account_domain_blocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_domain_blocks (
    id bigint NOT NULL,
    domain character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    account_id bigint
);


ALTER TABLE public.account_domain_blocks OWNER TO postgres;

--
-- Name: account_domain_blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_domain_blocks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_domain_blocks_id_seq OWNER TO postgres;

--
-- Name: account_domain_blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_domain_blocks_id_seq OWNED BY public.account_domain_blocks.id;


--
-- Name: account_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_migrations (
    id bigint NOT NULL,
    account_id bigint,
    acct character varying DEFAULT ''::character varying NOT NULL,
    followers_count bigint DEFAULT 0 NOT NULL,
    target_account_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.account_migrations OWNER TO postgres;

--
-- Name: account_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_migrations_id_seq OWNER TO postgres;

--
-- Name: account_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_migrations_id_seq OWNED BY public.account_migrations.id;


--
-- Name: account_moderation_notes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_moderation_notes (
    id bigint NOT NULL,
    content text NOT NULL,
    account_id bigint NOT NULL,
    target_account_id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.account_moderation_notes OWNER TO postgres;

--
-- Name: account_moderation_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_moderation_notes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_moderation_notes_id_seq OWNER TO postgres;

--
-- Name: account_moderation_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_moderation_notes_id_seq OWNED BY public.account_moderation_notes.id;


--
-- Name: account_notes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_notes (
    id bigint NOT NULL,
    account_id bigint,
    target_account_id bigint,
    comment text NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.account_notes OWNER TO postgres;

--
-- Name: account_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_notes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_notes_id_seq OWNER TO postgres;

--
-- Name: account_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_notes_id_seq OWNED BY public.account_notes.id;


--
-- Name: account_pins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_pins (
    id bigint NOT NULL,
    account_id bigint,
    target_account_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.account_pins OWNER TO postgres;

--
-- Name: account_pins_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_pins_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_pins_id_seq OWNER TO postgres;

--
-- Name: account_pins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_pins_id_seq OWNED BY public.account_pins.id;


--
-- Name: account_relationship_severance_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_relationship_severance_events (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    relationship_severance_event_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    followers_count integer DEFAULT 0 NOT NULL,
    following_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.account_relationship_severance_events OWNER TO postgres;

--
-- Name: account_relationship_severance_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_relationship_severance_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_relationship_severance_events_id_seq OWNER TO postgres;

--
-- Name: account_relationship_severance_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_relationship_severance_events_id_seq OWNED BY public.account_relationship_severance_events.id;


--
-- Name: account_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_stats (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    statuses_count bigint DEFAULT 0 NOT NULL,
    following_count bigint DEFAULT 0 NOT NULL,
    followers_count bigint DEFAULT 0 NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    last_status_at timestamp without time zone
);


ALTER TABLE public.account_stats OWNER TO postgres;

--
-- Name: account_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_stats_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_stats_id_seq OWNER TO postgres;

--
-- Name: account_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_stats_id_seq OWNED BY public.account_stats.id;


--
-- Name: account_statuses_cleanup_policies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_statuses_cleanup_policies (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    min_status_age integer DEFAULT 1209600 NOT NULL,
    keep_direct boolean DEFAULT true NOT NULL,
    keep_pinned boolean DEFAULT true NOT NULL,
    keep_polls boolean DEFAULT false NOT NULL,
    keep_media boolean DEFAULT false NOT NULL,
    keep_self_fav boolean DEFAULT true NOT NULL,
    keep_self_bookmark boolean DEFAULT true NOT NULL,
    min_favs integer,
    min_reblogs integer,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.account_statuses_cleanup_policies OWNER TO postgres;

--
-- Name: account_statuses_cleanup_policies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_statuses_cleanup_policies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_statuses_cleanup_policies_id_seq OWNER TO postgres;

--
-- Name: account_statuses_cleanup_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_statuses_cleanup_policies_id_seq OWNED BY public.account_statuses_cleanup_policies.id;


--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    id bigint DEFAULT public.timestamp_id('accounts'::text) NOT NULL,
    username character varying DEFAULT ''::character varying NOT NULL,
    domain character varying,
    private_key text,
    public_key text DEFAULT ''::text NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    display_name character varying DEFAULT ''::character varying NOT NULL,
    uri character varying DEFAULT ''::character varying NOT NULL,
    url character varying,
    avatar_file_name character varying,
    avatar_content_type character varying,
    avatar_file_size integer,
    avatar_updated_at timestamp without time zone,
    header_file_name character varying,
    header_content_type character varying,
    header_file_size integer,
    header_updated_at timestamp without time zone,
    avatar_remote_url character varying,
    locked boolean DEFAULT false NOT NULL,
    header_remote_url character varying DEFAULT ''::character varying NOT NULL,
    last_webfingered_at timestamp without time zone,
    inbox_url character varying DEFAULT ''::character varying NOT NULL,
    outbox_url character varying DEFAULT ''::character varying NOT NULL,
    shared_inbox_url character varying DEFAULT ''::character varying NOT NULL,
    followers_url character varying DEFAULT ''::character varying NOT NULL,
    protocol integer DEFAULT 0 NOT NULL,
    memorial boolean DEFAULT false NOT NULL,
    moved_to_account_id bigint,
    featured_collection_url character varying,
    fields jsonb,
    actor_type character varying,
    discoverable boolean,
    also_known_as character varying[],
    silenced_at timestamp without time zone,
    suspended_at timestamp without time zone,
    hide_collections boolean,
    avatar_storage_schema_version integer,
    header_storage_schema_version integer,
    sensitized_at timestamp without time zone,
    suspension_origin integer,
    trendable boolean,
    reviewed_at timestamp without time zone,
    requested_review_at timestamp without time zone,
    indexable boolean DEFAULT false NOT NULL,
    attribution_domains character varying[] DEFAULT '{}'::character varying[]
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: statuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.statuses (
    id bigint DEFAULT public.timestamp_id('statuses'::text) NOT NULL,
    uri character varying,
    text text DEFAULT ''::text NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    in_reply_to_id bigint,
    reblog_of_id bigint,
    url character varying,
    sensitive boolean DEFAULT false NOT NULL,
    visibility integer DEFAULT 0 NOT NULL,
    spoiler_text text DEFAULT ''::text NOT NULL,
    reply boolean DEFAULT false NOT NULL,
    language character varying,
    conversation_id bigint,
    local boolean,
    account_id bigint NOT NULL,
    application_id bigint,
    in_reply_to_account_id bigint,
    poll_id bigint,
    deleted_at timestamp without time zone,
    edited_at timestamp without time zone,
    trendable boolean,
    ordered_media_attachment_ids bigint[]
);


ALTER TABLE public.statuses OWNER TO postgres;

--
-- Name: account_summaries; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.account_summaries AS
 SELECT accounts.id AS account_id,
    mode() WITHIN GROUP (ORDER BY t0.language) AS language,
    mode() WITHIN GROUP (ORDER BY t0.sensitive) AS sensitive
   FROM (public.accounts
     CROSS JOIN LATERAL ( SELECT statuses.account_id,
            statuses.language,
            statuses.sensitive
           FROM public.statuses
          WHERE ((statuses.account_id = accounts.id) AND (statuses.deleted_at IS NULL) AND (statuses.reblog_of_id IS NULL))
          ORDER BY statuses.id DESC
         LIMIT 20) t0)
  WHERE ((accounts.suspended_at IS NULL) AND (accounts.silenced_at IS NULL) AND (accounts.moved_to_account_id IS NULL) AND (accounts.discoverable = true) AND (accounts.locked = false))
  GROUP BY accounts.id
  WITH NO DATA;


ALTER TABLE public.account_summaries OWNER TO postgres;

--
-- Name: account_warning_presets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_warning_presets (
    id bigint NOT NULL,
    text text DEFAULT ''::text NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    title character varying DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.account_warning_presets OWNER TO postgres;

--
-- Name: account_warning_presets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_warning_presets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_warning_presets_id_seq OWNER TO postgres;

--
-- Name: account_warning_presets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_warning_presets_id_seq OWNED BY public.account_warning_presets.id;


--
-- Name: account_warnings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_warnings (
    id bigint NOT NULL,
    account_id bigint,
    target_account_id bigint,
    action integer DEFAULT 0 NOT NULL,
    text text DEFAULT ''::text NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    report_id bigint,
    status_ids character varying[],
    overruled_at timestamp without time zone
);


ALTER TABLE public.account_warnings OWNER TO postgres;

--
-- Name: account_warnings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_warnings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_warnings_id_seq OWNER TO postgres;

--
-- Name: account_warnings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_warnings_id_seq OWNED BY public.account_warnings.id;


--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_id_seq OWNER TO postgres;

--
-- Name: accounts_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts_tags (
    account_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


ALTER TABLE public.accounts_tags OWNER TO postgres;

--
-- Name: admin_action_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_action_logs (
    id bigint NOT NULL,
    account_id bigint,
    action character varying DEFAULT ''::character varying NOT NULL,
    target_type character varying,
    target_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    human_identifier character varying,
    route_param character varying,
    permalink character varying
);


ALTER TABLE public.admin_action_logs OWNER TO postgres;

--
-- Name: admin_action_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.admin_action_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_action_logs_id_seq OWNER TO postgres;

--
-- Name: admin_action_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.admin_action_logs_id_seq OWNED BY public.admin_action_logs.id;


--
-- Name: announcement_mutes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.announcement_mutes (
    id bigint NOT NULL,
    account_id bigint,
    announcement_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.announcement_mutes OWNER TO postgres;

--
-- Name: announcement_mutes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.announcement_mutes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.announcement_mutes_id_seq OWNER TO postgres;

--
-- Name: announcement_mutes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.announcement_mutes_id_seq OWNED BY public.announcement_mutes.id;


--
-- Name: announcement_reactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.announcement_reactions (
    id bigint NOT NULL,
    account_id bigint,
    announcement_id bigint,
    name character varying DEFAULT ''::character varying NOT NULL,
    custom_emoji_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.announcement_reactions OWNER TO postgres;

--
-- Name: announcement_reactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.announcement_reactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.announcement_reactions_id_seq OWNER TO postgres;

--
-- Name: announcement_reactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.announcement_reactions_id_seq OWNED BY public.announcement_reactions.id;


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.announcements (
    id bigint NOT NULL,
    text text DEFAULT ''::text NOT NULL,
    published boolean DEFAULT false NOT NULL,
    all_day boolean DEFAULT false NOT NULL,
    scheduled_at timestamp without time zone,
    starts_at timestamp without time zone,
    ends_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    published_at timestamp without time zone,
    status_ids bigint[]
);


ALTER TABLE public.announcements OWNER TO postgres;

--
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.announcements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.announcements_id_seq OWNER TO postgres;

--
-- Name: announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.announcements_id_seq OWNED BY public.announcements.id;


--
-- Name: appeals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appeals (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    account_warning_id bigint NOT NULL,
    text text DEFAULT ''::text NOT NULL,
    approved_at timestamp without time zone,
    approved_by_account_id bigint,
    rejected_at timestamp without time zone,
    rejected_by_account_id bigint,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.appeals OWNER TO postgres;

--
-- Name: appeals_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.appeals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.appeals_id_seq OWNER TO postgres;

--
-- Name: appeals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.appeals_id_seq OWNED BY public.appeals.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO postgres;

--
-- Name: backups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backups (
    id bigint NOT NULL,
    user_id bigint,
    dump_file_name character varying,
    dump_content_type character varying,
    dump_updated_at timestamp without time zone,
    processed boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    dump_file_size bigint
);


ALTER TABLE public.backups OWNER TO postgres;

--
-- Name: backups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.backups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.backups_id_seq OWNER TO postgres;

--
-- Name: backups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.backups_id_seq OWNED BY public.backups.id;


--
-- Name: blocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blocks (
    id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    account_id bigint NOT NULL,
    target_account_id bigint NOT NULL,
    uri character varying
);


ALTER TABLE public.blocks OWNER TO postgres;

--
-- Name: blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blocks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blocks_id_seq OWNER TO postgres;

--
-- Name: blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blocks_id_seq OWNED BY public.blocks.id;


--
-- Name: bookmarks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bookmarks (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    status_id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.bookmarks OWNER TO postgres;

--
-- Name: bookmarks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bookmarks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bookmarks_id_seq OWNER TO postgres;

--
-- Name: bookmarks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bookmarks_id_seq OWNED BY public.bookmarks.id;


--
-- Name: bulk_import_rows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bulk_import_rows (
    id bigint NOT NULL,
    bulk_import_id bigint NOT NULL,
    data jsonb,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.bulk_import_rows OWNER TO postgres;

--
-- Name: bulk_import_rows_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bulk_import_rows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bulk_import_rows_id_seq OWNER TO postgres;

--
-- Name: bulk_import_rows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bulk_import_rows_id_seq OWNED BY public.bulk_import_rows.id;


--
-- Name: bulk_imports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bulk_imports (
    id bigint NOT NULL,
    type integer NOT NULL,
    state integer NOT NULL,
    total_items integer DEFAULT 0 NOT NULL,
    imported_items integer DEFAULT 0 NOT NULL,
    processed_items integer DEFAULT 0 NOT NULL,
    finished_at timestamp without time zone,
    overwrite boolean DEFAULT false NOT NULL,
    likely_mismatched boolean DEFAULT false NOT NULL,
    original_filename character varying DEFAULT ''::character varying NOT NULL,
    account_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.bulk_imports OWNER TO postgres;

--
-- Name: bulk_imports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bulk_imports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bulk_imports_id_seq OWNER TO postgres;

--
-- Name: bulk_imports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bulk_imports_id_seq OWNED BY public.bulk_imports.id;


--
-- Name: canonical_email_blocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.canonical_email_blocks (
    id bigint NOT NULL,
    canonical_email_hash character varying DEFAULT ''::character varying NOT NULL,
    reference_account_id bigint,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.canonical_email_blocks OWNER TO postgres;

--
-- Name: canonical_email_blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.canonical_email_blocks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.canonical_email_blocks_id_seq OWNER TO postgres;

--
-- Name: canonical_email_blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.canonical_email_blocks_id_seq OWNED BY public.canonical_email_blocks.id;


--
-- Name: conversation_mutes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversation_mutes (
    id bigint NOT NULL,
    conversation_id bigint NOT NULL,
    account_id bigint NOT NULL
);


ALTER TABLE public.conversation_mutes OWNER TO postgres;

--
-- Name: conversation_mutes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.conversation_mutes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.conversation_mutes_id_seq OWNER TO postgres;

--
-- Name: conversation_mutes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.conversation_mutes_id_seq OWNED BY public.conversation_mutes.id;


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversations (
    id bigint NOT NULL,
    uri character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.conversations OWNER TO postgres;

--
-- Name: conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.conversations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.conversations_id_seq OWNER TO postgres;

--
-- Name: conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.conversations_id_seq OWNED BY public.conversations.id;


--
-- Name: custom_emoji_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_emoji_categories (
    id bigint NOT NULL,
    name character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.custom_emoji_categories OWNER TO postgres;

--
-- Name: custom_emoji_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.custom_emoji_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.custom_emoji_categories_id_seq OWNER TO postgres;

--
-- Name: custom_emoji_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.custom_emoji_categories_id_seq OWNED BY public.custom_emoji_categories.id;


--
-- Name: custom_emojis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_emojis (
    id bigint NOT NULL,
    shortcode character varying DEFAULT ''::character varying NOT NULL,
    domain character varying,
    image_file_name character varying,
    image_content_type character varying,
    image_file_size integer,
    image_updated_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    disabled boolean DEFAULT false NOT NULL,
    uri character varying,
    image_remote_url character varying,
    visible_in_picker boolean DEFAULT true NOT NULL,
    category_id bigint,
    image_storage_schema_version integer
);


ALTER TABLE public.custom_emojis OWNER TO postgres;

--
-- Name: custom_emojis_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.custom_emojis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.custom_emojis_id_seq OWNER TO postgres;

--
-- Name: custom_emojis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.custom_emojis_id_seq OWNED BY public.custom_emojis.id;


--
-- Name: custom_filter_keywords; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_filter_keywords (
    id bigint NOT NULL,
    custom_filter_id bigint NOT NULL,
    keyword text DEFAULT ''::text NOT NULL,
    whole_word boolean DEFAULT true NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.custom_filter_keywords OWNER TO postgres;

--
-- Name: custom_filter_keywords_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.custom_filter_keywords_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.custom_filter_keywords_id_seq OWNER TO postgres;

--
-- Name: custom_filter_keywords_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.custom_filter_keywords_id_seq OWNED BY public.custom_filter_keywords.id;


--
-- Name: custom_filter_statuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_filter_statuses (
    id bigint NOT NULL,
    custom_filter_id bigint NOT NULL,
    status_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.custom_filter_statuses OWNER TO postgres;

--
-- Name: custom_filter_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.custom_filter_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.custom_filter_statuses_id_seq OWNER TO postgres;

--
-- Name: custom_filter_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.custom_filter_statuses_id_seq OWNED BY public.custom_filter_statuses.id;


--
-- Name: custom_filters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_filters (
    id bigint NOT NULL,
    account_id bigint,
    expires_at timestamp without time zone,
    phrase text DEFAULT ''::text NOT NULL,
    context character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    action integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.custom_filters OWNER TO postgres;

--
-- Name: custom_filters_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.custom_filters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.custom_filters_id_seq OWNER TO postgres;

--
-- Name: custom_filters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.custom_filters_id_seq OWNED BY public.custom_filters.id;


--
-- Name: domain_allows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.domain_allows (
    id bigint NOT NULL,
    domain character varying DEFAULT ''::character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.domain_allows OWNER TO postgres;

--
-- Name: domain_allows_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.domain_allows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.domain_allows_id_seq OWNER TO postgres;

--
-- Name: domain_allows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.domain_allows_id_seq OWNED BY public.domain_allows.id;


--
-- Name: domain_blocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.domain_blocks (
    id bigint NOT NULL,
    domain character varying DEFAULT ''::character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    severity integer DEFAULT 0,
    reject_media boolean DEFAULT false NOT NULL,
    reject_reports boolean DEFAULT false NOT NULL,
    private_comment text,
    public_comment text,
    obfuscate boolean DEFAULT false NOT NULL
);


ALTER TABLE public.domain_blocks OWNER TO postgres;

--
-- Name: domain_blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.domain_blocks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.domain_blocks_id_seq OWNER TO postgres;

--
-- Name: domain_blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.domain_blocks_id_seq OWNED BY public.domain_blocks.id;


--
-- Name: email_domain_blocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_domain_blocks (
    id bigint NOT NULL,
    domain character varying DEFAULT ''::character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    parent_id bigint,
    allow_with_approval boolean DEFAULT false NOT NULL
);


ALTER TABLE public.email_domain_blocks OWNER TO postgres;

--
-- Name: email_domain_blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.email_domain_blocks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.email_domain_blocks_id_seq OWNER TO postgres;

--
-- Name: email_domain_blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.email_domain_blocks_id_seq OWNED BY public.email_domain_blocks.id;


--
-- Name: favourites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.favourites (
    id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    account_id bigint NOT NULL,
    status_id bigint NOT NULL
);


ALTER TABLE public.favourites OWNER TO postgres;

--
-- Name: favourites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.favourites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.favourites_id_seq OWNER TO postgres;

--
-- Name: favourites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.favourites_id_seq OWNED BY public.favourites.id;


--
-- Name: featured_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.featured_tags (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    tag_id bigint NOT NULL,
    statuses_count bigint DEFAULT 0 NOT NULL,
    last_status_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    name character varying
);


ALTER TABLE public.featured_tags OWNER TO postgres;

--
-- Name: featured_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.featured_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.featured_tags_id_seq OWNER TO postgres;

--
-- Name: featured_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.featured_tags_id_seq OWNED BY public.featured_tags.id;


--
-- Name: follow_recommendation_mutes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.follow_recommendation_mutes (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    target_account_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.follow_recommendation_mutes OWNER TO postgres;

--
-- Name: follow_recommendation_mutes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.follow_recommendation_mutes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.follow_recommendation_mutes_id_seq OWNER TO postgres;

--
-- Name: follow_recommendation_mutes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.follow_recommendation_mutes_id_seq OWNED BY public.follow_recommendation_mutes.id;


--
-- Name: follow_recommendation_suppressions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.follow_recommendation_suppressions (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.follow_recommendation_suppressions OWNER TO postgres;

--
-- Name: follow_recommendation_suppressions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.follow_recommendation_suppressions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.follow_recommendation_suppressions_id_seq OWNER TO postgres;

--
-- Name: follow_recommendation_suppressions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.follow_recommendation_suppressions_id_seq OWNED BY public.follow_recommendation_suppressions.id;


--
-- Name: follow_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.follow_requests (
    id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    account_id bigint NOT NULL,
    target_account_id bigint NOT NULL,
    show_reblogs boolean DEFAULT true NOT NULL,
    uri character varying,
    notify boolean DEFAULT false NOT NULL,
    languages character varying[]
);


ALTER TABLE public.follow_requests OWNER TO postgres;

--
-- Name: follow_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.follow_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.follow_requests_id_seq OWNER TO postgres;

--
-- Name: follow_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.follow_requests_id_seq OWNED BY public.follow_requests.id;


--
-- Name: follows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.follows (
    id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    account_id bigint NOT NULL,
    target_account_id bigint NOT NULL,
    show_reblogs boolean DEFAULT true NOT NULL,
    uri character varying,
    notify boolean DEFAULT false NOT NULL,
    languages character varying[]
);


ALTER TABLE public.follows OWNER TO postgres;

--
-- Name: follows_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.follows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.follows_id_seq OWNER TO postgres;

--
-- Name: follows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.follows_id_seq OWNED BY public.follows.id;


--
-- Name: generated_annual_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.generated_annual_reports (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    year integer NOT NULL,
    data jsonb NOT NULL,
    schema_version integer NOT NULL,
    viewed_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.generated_annual_reports OWNER TO postgres;

--
-- Name: generated_annual_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.generated_annual_reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.generated_annual_reports_id_seq OWNER TO postgres;

--
-- Name: generated_annual_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.generated_annual_reports_id_seq OWNED BY public.generated_annual_reports.id;


--
-- Name: status_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status_stats (
    id bigint NOT NULL,
    status_id bigint NOT NULL,
    replies_count bigint DEFAULT 0 NOT NULL,
    reblogs_count bigint DEFAULT 0 NOT NULL,
    favourites_count bigint DEFAULT 0 NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.status_stats OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    sign_in_count integer DEFAULT 0 NOT NULL,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    confirmation_token character varying,
    confirmed_at timestamp without time zone,
    confirmation_sent_at timestamp without time zone,
    unconfirmed_email character varying,
    locale character varying,
    encrypted_otp_secret character varying,
    encrypted_otp_secret_iv character varying,
    encrypted_otp_secret_salt character varying,
    consumed_timestep integer,
    otp_required_for_login boolean DEFAULT false NOT NULL,
    last_emailed_at timestamp without time zone,
    otp_backup_codes character varying[],
    account_id bigint NOT NULL,
    disabled boolean DEFAULT false NOT NULL,
    invite_id bigint,
    chosen_languages character varying[],
    created_by_application_id bigint,
    approved boolean DEFAULT true NOT NULL,
    sign_in_token character varying,
    sign_in_token_sent_at timestamp without time zone,
    webauthn_id character varying,
    sign_up_ip inet,
    skip_sign_in_token boolean,
    role_id bigint,
    settings text,
    time_zone character varying,
    otp_secret character varying
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: global_follow_recommendations; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.global_follow_recommendations AS
 SELECT t0.account_id,
    sum(t0.rank) AS rank,
    array_agg(t0.reason) AS reason
   FROM ( SELECT account_summaries.account_id,
            ((count(follows.id))::numeric / (1.0 + (count(follows.id))::numeric)) AS rank,
            'most_followed'::text AS reason
           FROM ((public.follows
             JOIN public.account_summaries ON ((account_summaries.account_id = follows.target_account_id)))
             JOIN public.users ON ((users.account_id = follows.account_id)))
          WHERE ((users.current_sign_in_at >= (now() - '30 days'::interval)) AND (account_summaries.sensitive = false) AND (NOT (EXISTS ( SELECT 1
                   FROM public.follow_recommendation_suppressions
                  WHERE (follow_recommendation_suppressions.account_id = follows.target_account_id)))))
          GROUP BY account_summaries.account_id
         HAVING (count(follows.id) >= 5)
        UNION ALL
         SELECT account_summaries.account_id,
            (sum((status_stats.reblogs_count + status_stats.favourites_count)) / (1.0 + sum((status_stats.reblogs_count + status_stats.favourites_count)))) AS rank,
            'most_interactions'::text AS reason
           FROM ((public.status_stats
             JOIN public.statuses ON ((statuses.id = status_stats.status_id)))
             JOIN public.account_summaries ON ((account_summaries.account_id = statuses.account_id)))
          WHERE ((statuses.id >= (((date_part('epoch'::text, (now() - '30 days'::interval)) * (1000)::double precision))::bigint << 16)) AND (account_summaries.sensitive = false) AND (NOT (EXISTS ( SELECT 1
                   FROM public.follow_recommendation_suppressions
                  WHERE (follow_recommendation_suppressions.account_id = statuses.account_id)))))
          GROUP BY account_summaries.account_id
         HAVING (sum((status_stats.reblogs_count + status_stats.favourites_count)) >= (5)::numeric)) t0
  GROUP BY t0.account_id
  ORDER BY (sum(t0.rank)) DESC
  WITH NO DATA;


ALTER TABLE public.global_follow_recommendations OWNER TO postgres;

--
-- Name: identities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.identities (
    id bigint NOT NULL,
    provider character varying DEFAULT ''::character varying NOT NULL,
    uid character varying DEFAULT ''::character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_id bigint
);


ALTER TABLE public.identities OWNER TO postgres;

--
-- Name: identities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.identities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.identities_id_seq OWNER TO postgres;

--
-- Name: identities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.identities_id_seq OWNED BY public.identities.id;


--
-- Name: imports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.imports (
    id bigint NOT NULL,
    type integer NOT NULL,
    approved boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    data_file_name character varying,
    data_content_type character varying,
    data_file_size integer,
    data_updated_at timestamp without time zone,
    account_id bigint NOT NULL,
    overwrite boolean DEFAULT false NOT NULL
);


ALTER TABLE public.imports OWNER TO postgres;

--
-- Name: imports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.imports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.imports_id_seq OWNER TO postgres;

--
-- Name: imports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.imports_id_seq OWNED BY public.imports.id;


--
-- Name: instances; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.instances AS
 WITH domain_counts(domain, accounts_count) AS (
         SELECT accounts.domain,
            count(*) AS accounts_count
           FROM public.accounts
          WHERE (accounts.domain IS NOT NULL)
          GROUP BY accounts.domain
        )
 SELECT domain_counts.domain,
    domain_counts.accounts_count
   FROM domain_counts
UNION
 SELECT domain_blocks.domain,
    COALESCE(domain_counts.accounts_count, (0)::bigint) AS accounts_count
   FROM (public.domain_blocks
     LEFT JOIN domain_counts ON (((domain_counts.domain)::text = (domain_blocks.domain)::text)))
UNION
 SELECT domain_allows.domain,
    COALESCE(domain_counts.accounts_count, (0)::bigint) AS accounts_count
   FROM (public.domain_allows
     LEFT JOIN domain_counts ON (((domain_counts.domain)::text = (domain_allows.domain)::text)))
  WITH NO DATA;


ALTER TABLE public.instances OWNER TO postgres;

--
-- Name: invites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invites (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    code character varying DEFAULT ''::character varying NOT NULL,
    expires_at timestamp without time zone,
    max_uses integer,
    uses integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    autofollow boolean DEFAULT false NOT NULL,
    comment text
);


ALTER TABLE public.invites OWNER TO postgres;

--
-- Name: invites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invites_id_seq OWNER TO postgres;

--
-- Name: invites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invites_id_seq OWNED BY public.invites.id;


--
-- Name: ip_blocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ip_blocks (
    id bigint NOT NULL,
    ip inet DEFAULT '0.0.0.0'::inet NOT NULL,
    severity integer DEFAULT 0 NOT NULL,
    expires_at timestamp without time zone,
    comment text DEFAULT ''::text NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ip_blocks OWNER TO postgres;

--
-- Name: ip_blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ip_blocks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ip_blocks_id_seq OWNER TO postgres;

--
-- Name: ip_blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ip_blocks_id_seq OWNED BY public.ip_blocks.id;


--
-- Name: list_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.list_accounts (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    account_id bigint NOT NULL,
    follow_id bigint,
    follow_request_id bigint
);


ALTER TABLE public.list_accounts OWNER TO postgres;

--
-- Name: list_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.list_accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.list_accounts_id_seq OWNER TO postgres;

--
-- Name: list_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.list_accounts_id_seq OWNED BY public.list_accounts.id;


--
-- Name: lists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lists (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    title character varying DEFAULT ''::character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    replies_policy integer DEFAULT 0 NOT NULL,
    exclusive boolean DEFAULT false NOT NULL
);


ALTER TABLE public.lists OWNER TO postgres;

--
-- Name: lists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lists_id_seq OWNER TO postgres;

--
-- Name: lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lists_id_seq OWNED BY public.lists.id;


--
-- Name: login_activities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.login_activities (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    authentication_method character varying,
    provider character varying,
    success boolean,
    failure_reason character varying,
    ip inet,
    user_agent character varying,
    created_at timestamp without time zone
);


ALTER TABLE public.login_activities OWNER TO postgres;

--
-- Name: login_activities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.login_activities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.login_activities_id_seq OWNER TO postgres;

--
-- Name: login_activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.login_activities_id_seq OWNED BY public.login_activities.id;


--
-- Name: markers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.markers (
    id bigint NOT NULL,
    user_id bigint,
    timeline character varying DEFAULT ''::character varying NOT NULL,
    last_read_id bigint DEFAULT 0 NOT NULL,
    lock_version integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.markers OWNER TO postgres;

--
-- Name: markers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.markers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.markers_id_seq OWNER TO postgres;

--
-- Name: markers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.markers_id_seq OWNED BY public.markers.id;


--
-- Name: media_attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media_attachments (
    id bigint DEFAULT public.timestamp_id('media_attachments'::text) NOT NULL,
    status_id bigint,
    file_file_name character varying,
    file_content_type character varying,
    file_file_size integer,
    file_updated_at timestamp without time zone,
    remote_url character varying DEFAULT ''::character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    shortcode character varying,
    type integer DEFAULT 0 NOT NULL,
    file_meta json,
    account_id bigint,
    description text,
    scheduled_status_id bigint,
    blurhash character varying,
    processing integer,
    file_storage_schema_version integer,
    thumbnail_file_name character varying,
    thumbnail_content_type character varying,
    thumbnail_file_size integer,
    thumbnail_updated_at timestamp without time zone,
    thumbnail_remote_url character varying
);


ALTER TABLE public.media_attachments OWNER TO postgres;

--
-- Name: media_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.media_attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.media_attachments_id_seq OWNER TO postgres;

--
-- Name: mentions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mentions (
    id bigint NOT NULL,
    status_id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    account_id bigint NOT NULL,
    silent boolean DEFAULT false NOT NULL
);


ALTER TABLE public.mentions OWNER TO postgres;

--
-- Name: mentions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mentions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mentions_id_seq OWNER TO postgres;

--
-- Name: mentions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mentions_id_seq OWNED BY public.mentions.id;


--
-- Name: mutes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mutes (
    id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    hide_notifications boolean DEFAULT true NOT NULL,
    account_id bigint NOT NULL,
    target_account_id bigint NOT NULL,
    expires_at timestamp without time zone
);


ALTER TABLE public.mutes OWNER TO postgres;

--
-- Name: mutes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mutes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mutes_id_seq OWNER TO postgres;

--
-- Name: mutes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mutes_id_seq OWNED BY public.mutes.id;


--
-- Name: notification_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_permissions (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    from_account_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.notification_permissions OWNER TO postgres;

--
-- Name: notification_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_permissions_id_seq OWNER TO postgres;

--
-- Name: notification_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_permissions_id_seq OWNED BY public.notification_permissions.id;


--
-- Name: notification_policies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_policies (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    for_not_following integer DEFAULT 0 NOT NULL,
    for_not_followers integer DEFAULT 0 NOT NULL,
    for_new_accounts integer DEFAULT 0 NOT NULL,
    for_private_mentions integer DEFAULT 1 NOT NULL,
    for_limited_accounts integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.notification_policies OWNER TO postgres;

--
-- Name: notification_policies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_policies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_policies_id_seq OWNER TO postgres;

--
-- Name: notification_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_policies_id_seq OWNED BY public.notification_policies.id;


--
-- Name: notification_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_requests (
    id bigint DEFAULT public.timestamp_id('notification_requests'::text) NOT NULL,
    account_id bigint NOT NULL,
    from_account_id bigint NOT NULL,
    last_status_id bigint,
    notifications_count bigint DEFAULT 0 NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.notification_requests OWNER TO postgres;

--
-- Name: notification_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_requests_id_seq OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    activity_id bigint NOT NULL,
    activity_type character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    account_id bigint NOT NULL,
    from_account_id bigint NOT NULL,
    type character varying,
    filtered boolean DEFAULT false NOT NULL,
    group_key character varying
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_id_seq OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: oauth_access_grants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_access_grants (
    id bigint NOT NULL,
    token character varying NOT NULL,
    expires_in integer NOT NULL,
    redirect_uri text NOT NULL,
    created_at timestamp without time zone NOT NULL,
    revoked_at timestamp without time zone,
    scopes character varying,
    application_id bigint NOT NULL,
    resource_owner_id bigint NOT NULL,
    code_challenge character varying,
    code_challenge_method character varying
);


ALTER TABLE public.oauth_access_grants OWNER TO postgres;

--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_access_grants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_access_grants_id_seq OWNER TO postgres;

--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_access_grants_id_seq OWNED BY public.oauth_access_grants.id;


--
-- Name: oauth_access_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_access_tokens (
    id bigint NOT NULL,
    token character varying NOT NULL,
    refresh_token character varying,
    expires_in integer,
    revoked_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    scopes character varying,
    application_id bigint,
    resource_owner_id bigint,
    last_used_at timestamp without time zone,
    last_used_ip inet
);


ALTER TABLE public.oauth_access_tokens OWNER TO postgres;

--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_access_tokens_id_seq OWNER TO postgres;

--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_access_tokens_id_seq OWNED BY public.oauth_access_tokens.id;


--
-- Name: oauth_applications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_applications (
    id bigint NOT NULL,
    name character varying NOT NULL,
    uid character varying NOT NULL,
    secret character varying NOT NULL,
    redirect_uri text NOT NULL,
    scopes character varying DEFAULT ''::character varying NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    superapp boolean DEFAULT false NOT NULL,
    website character varying,
    owner_type character varying,
    owner_id bigint,
    confidential boolean DEFAULT true NOT NULL
);


ALTER TABLE public.oauth_applications OWNER TO postgres;

--
-- Name: oauth_applications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_applications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_applications_id_seq OWNER TO postgres;

--
-- Name: oauth_applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_applications_id_seq OWNED BY public.oauth_applications.id;


--
-- Name: pghero_space_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pghero_space_stats (
    id bigint NOT NULL,
    database text,
    schema text,
    relation text,
    size bigint,
    captured_at timestamp without time zone
);


ALTER TABLE public.pghero_space_stats OWNER TO postgres;

--
-- Name: pghero_space_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pghero_space_stats_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pghero_space_stats_id_seq OWNER TO postgres;

--
-- Name: pghero_space_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pghero_space_stats_id_seq OWNED BY public.pghero_space_stats.id;


--
-- Name: poll_votes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.poll_votes (
    id bigint NOT NULL,
    account_id bigint,
    poll_id bigint,
    choice integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    uri character varying
);


ALTER TABLE public.poll_votes OWNER TO postgres;

--
-- Name: poll_votes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.poll_votes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.poll_votes_id_seq OWNER TO postgres;

--
-- Name: poll_votes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.poll_votes_id_seq OWNED BY public.poll_votes.id;


--
-- Name: polls; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.polls (
    id bigint NOT NULL,
    account_id bigint,
    status_id bigint,
    expires_at timestamp without time zone,
    options character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    cached_tallies bigint[] DEFAULT '{}'::bigint[] NOT NULL,
    multiple boolean DEFAULT false NOT NULL,
    hide_totals boolean DEFAULT false NOT NULL,
    votes_count bigint DEFAULT 0 NOT NULL,
    last_fetched_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    lock_version integer DEFAULT 0 NOT NULL,
    voters_count bigint
);


ALTER TABLE public.polls OWNER TO postgres;

--
-- Name: polls_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.polls_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.polls_id_seq OWNER TO postgres;

--
-- Name: polls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.polls_id_seq OWNED BY public.polls.id;


--
-- Name: preview_card_providers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.preview_card_providers (
    id bigint NOT NULL,
    domain character varying DEFAULT ''::character varying NOT NULL,
    icon_file_name character varying,
    icon_content_type character varying,
    icon_file_size bigint,
    icon_updated_at timestamp without time zone,
    trendable boolean,
    reviewed_at timestamp without time zone,
    requested_review_at timestamp without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.preview_card_providers OWNER TO postgres;

--
-- Name: preview_card_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.preview_card_providers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.preview_card_providers_id_seq OWNER TO postgres;

--
-- Name: preview_card_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.preview_card_providers_id_seq OWNED BY public.preview_card_providers.id;


--
-- Name: preview_card_trends; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.preview_card_trends (
    id bigint NOT NULL,
    preview_card_id bigint NOT NULL,
    score double precision DEFAULT 0.0 NOT NULL,
    rank integer DEFAULT 0 NOT NULL,
    allowed boolean DEFAULT false NOT NULL,
    language character varying
);


ALTER TABLE public.preview_card_trends OWNER TO postgres;

--
-- Name: preview_card_trends_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.preview_card_trends_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.preview_card_trends_id_seq OWNER TO postgres;

--
-- Name: preview_card_trends_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.preview_card_trends_id_seq OWNED BY public.preview_card_trends.id;


--
-- Name: preview_cards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.preview_cards (
    id bigint NOT NULL,
    url character varying DEFAULT ''::character varying NOT NULL,
    title character varying DEFAULT ''::character varying NOT NULL,
    description character varying DEFAULT ''::character varying NOT NULL,
    image_file_name character varying,
    image_content_type character varying,
    image_file_size integer,
    image_updated_at timestamp without time zone,
    type integer DEFAULT 0 NOT NULL,
    html text DEFAULT ''::text NOT NULL,
    author_name character varying DEFAULT ''::character varying NOT NULL,
    author_url character varying DEFAULT ''::character varying NOT NULL,
    provider_name character varying DEFAULT ''::character varying NOT NULL,
    provider_url character varying DEFAULT ''::character varying NOT NULL,
    width integer DEFAULT 0 NOT NULL,
    height integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    embed_url character varying DEFAULT ''::character varying NOT NULL,
    image_storage_schema_version integer,
    blurhash character varying,
    language character varying,
    max_score double precision,
    max_score_at timestamp without time zone,
    trendable boolean,
    link_type integer,
    published_at timestamp(6) without time zone,
    image_description character varying DEFAULT ''::character varying NOT NULL,
    author_account_id bigint
);


ALTER TABLE public.preview_cards OWNER TO postgres;

--
-- Name: preview_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.preview_cards_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.preview_cards_id_seq OWNER TO postgres;

--
-- Name: preview_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.preview_cards_id_seq OWNED BY public.preview_cards.id;


--
-- Name: preview_cards_statuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.preview_cards_statuses (
    preview_card_id bigint NOT NULL,
    status_id bigint NOT NULL,
    url character varying
);


ALTER TABLE public.preview_cards_statuses OWNER TO postgres;

--
-- Name: relationship_severance_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.relationship_severance_events (
    id bigint NOT NULL,
    type integer NOT NULL,
    target_name character varying NOT NULL,
    purged boolean DEFAULT false NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.relationship_severance_events OWNER TO postgres;

--
-- Name: relationship_severance_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.relationship_severance_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.relationship_severance_events_id_seq OWNER TO postgres;

--
-- Name: relationship_severance_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.relationship_severance_events_id_seq OWNED BY public.relationship_severance_events.id;


--
-- Name: relays; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.relays (
    id bigint NOT NULL,
    inbox_url character varying DEFAULT ''::character varying NOT NULL,
    follow_activity_id character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    state integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.relays OWNER TO postgres;

--
-- Name: relays_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.relays_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.relays_id_seq OWNER TO postgres;

--
-- Name: relays_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.relays_id_seq OWNED BY public.relays.id;


--
-- Name: report_notes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report_notes (
    id bigint NOT NULL,
    content text NOT NULL,
    report_id bigint NOT NULL,
    account_id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.report_notes OWNER TO postgres;

--
-- Name: report_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.report_notes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.report_notes_id_seq OWNER TO postgres;

--
-- Name: report_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.report_notes_id_seq OWNED BY public.report_notes.id;


--
-- Name: reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reports (
    id bigint NOT NULL,
    status_ids bigint[] DEFAULT '{}'::bigint[] NOT NULL,
    comment text DEFAULT ''::text NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    account_id bigint NOT NULL,
    action_taken_by_account_id bigint,
    target_account_id bigint NOT NULL,
    assigned_account_id bigint,
    uri character varying,
    forwarded boolean,
    category integer DEFAULT 0 NOT NULL,
    action_taken_at timestamp without time zone,
    rule_ids bigint[],
    application_id bigint
);


ALTER TABLE public.reports OWNER TO postgres;

--
-- Name: reports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reports_id_seq OWNER TO postgres;

--
-- Name: reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reports_id_seq OWNED BY public.reports.id;


--
-- Name: rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rules (
    id bigint NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    deleted_at timestamp without time zone,
    text text DEFAULT ''::text NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    hint text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.rules OWNER TO postgres;

--
-- Name: rules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rules_id_seq OWNER TO postgres;

--
-- Name: rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rules_id_seq OWNED BY public.rules.id;


--
-- Name: scheduled_statuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scheduled_statuses (
    id bigint NOT NULL,
    account_id bigint,
    scheduled_at timestamp without time zone,
    params jsonb
);


ALTER TABLE public.scheduled_statuses OWNER TO postgres;

--
-- Name: scheduled_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.scheduled_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scheduled_statuses_id_seq OWNER TO postgres;

--
-- Name: scheduled_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.scheduled_statuses_id_seq OWNED BY public.scheduled_statuses.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO postgres;

--
-- Name: session_activations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session_activations (
    id bigint NOT NULL,
    session_id character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_agent character varying DEFAULT ''::character varying NOT NULL,
    ip inet,
    access_token_id bigint,
    user_id bigint NOT NULL,
    web_push_subscription_id bigint
);


ALTER TABLE public.session_activations OWNER TO postgres;

--
-- Name: session_activations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.session_activations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.session_activations_id_seq OWNER TO postgres;

--
-- Name: session_activations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.session_activations_id_seq OWNED BY public.session_activations.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settings (
    id bigint NOT NULL,
    var character varying NOT NULL,
    value text,
    thing_type character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    thing_id bigint
);


ALTER TABLE public.settings OWNER TO postgres;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.settings_id_seq OWNER TO postgres;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: severed_relationships; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.severed_relationships (
    id bigint NOT NULL,
    relationship_severance_event_id bigint NOT NULL,
    local_account_id bigint NOT NULL,
    remote_account_id bigint NOT NULL,
    direction integer NOT NULL,
    show_reblogs boolean,
    notify boolean,
    languages character varying[],
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.severed_relationships OWNER TO postgres;

--
-- Name: severed_relationships_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.severed_relationships_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.severed_relationships_id_seq OWNER TO postgres;

--
-- Name: severed_relationships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.severed_relationships_id_seq OWNED BY public.severed_relationships.id;


--
-- Name: site_uploads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.site_uploads (
    id bigint NOT NULL,
    var character varying DEFAULT ''::character varying NOT NULL,
    file_file_name character varying,
    file_content_type character varying,
    file_file_size integer,
    file_updated_at timestamp without time zone,
    meta json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    blurhash character varying
);


ALTER TABLE public.site_uploads OWNER TO postgres;

--
-- Name: site_uploads_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.site_uploads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.site_uploads_id_seq OWNER TO postgres;

--
-- Name: site_uploads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.site_uploads_id_seq OWNED BY public.site_uploads.id;


--
-- Name: software_updates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.software_updates (
    id bigint NOT NULL,
    version character varying NOT NULL,
    urgent boolean DEFAULT false NOT NULL,
    type integer DEFAULT 0 NOT NULL,
    release_notes character varying DEFAULT ''::character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.software_updates OWNER TO postgres;

--
-- Name: software_updates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.software_updates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.software_updates_id_seq OWNER TO postgres;

--
-- Name: software_updates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.software_updates_id_seq OWNED BY public.software_updates.id;


--
-- Name: status_edits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status_edits (
    id bigint NOT NULL,
    status_id bigint NOT NULL,
    account_id bigint,
    text text DEFAULT ''::text NOT NULL,
    spoiler_text text DEFAULT ''::text NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    ordered_media_attachment_ids bigint[],
    media_descriptions text[],
    poll_options character varying[],
    sensitive boolean
);


ALTER TABLE public.status_edits OWNER TO postgres;

--
-- Name: status_edits_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.status_edits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.status_edits_id_seq OWNER TO postgres;

--
-- Name: status_edits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.status_edits_id_seq OWNED BY public.status_edits.id;


--
-- Name: status_pins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status_pins (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    status_id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.status_pins OWNER TO postgres;

--
-- Name: status_pins_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.status_pins_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.status_pins_id_seq OWNER TO postgres;

--
-- Name: status_pins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.status_pins_id_seq OWNED BY public.status_pins.id;


--
-- Name: status_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.status_stats_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.status_stats_id_seq OWNER TO postgres;

--
-- Name: status_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.status_stats_id_seq OWNED BY public.status_stats.id;


--
-- Name: status_trends; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status_trends (
    id bigint NOT NULL,
    status_id bigint NOT NULL,
    account_id bigint NOT NULL,
    score double precision DEFAULT 0.0 NOT NULL,
    rank integer DEFAULT 0 NOT NULL,
    allowed boolean DEFAULT false NOT NULL,
    language character varying
);


ALTER TABLE public.status_trends OWNER TO postgres;

--
-- Name: status_trends_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.status_trends_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.status_trends_id_seq OWNER TO postgres;

--
-- Name: status_trends_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.status_trends_id_seq OWNED BY public.status_trends.id;


--
-- Name: statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.statuses_id_seq OWNER TO postgres;

--
-- Name: statuses_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.statuses_tags (
    status_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


ALTER TABLE public.statuses_tags OWNER TO postgres;

--
-- Name: tag_follows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tag_follows (
    id bigint NOT NULL,
    tag_id bigint NOT NULL,
    account_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.tag_follows OWNER TO postgres;

--
-- Name: tag_follows_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tag_follows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tag_follows_id_seq OWNER TO postgres;

--
-- Name: tag_follows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tag_follows_id_seq OWNED BY public.tag_follows.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tags (
    id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    usable boolean,
    trendable boolean,
    listable boolean,
    reviewed_at timestamp without time zone,
    requested_review_at timestamp without time zone,
    last_status_at timestamp without time zone,
    max_score double precision,
    max_score_at timestamp without time zone,
    display_name character varying
);


ALTER TABLE public.tags OWNER TO postgres;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tags_id_seq OWNER TO postgres;

--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: tombstones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tombstones (
    id bigint NOT NULL,
    account_id bigint,
    uri character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    by_moderator boolean
);


ALTER TABLE public.tombstones OWNER TO postgres;

--
-- Name: tombstones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tombstones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tombstones_id_seq OWNER TO postgres;

--
-- Name: tombstones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tombstones_id_seq OWNED BY public.tombstones.id;


--
-- Name: unavailable_domains; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.unavailable_domains (
    id bigint NOT NULL,
    domain character varying DEFAULT ''::character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.unavailable_domains OWNER TO postgres;

--
-- Name: unavailable_domains_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.unavailable_domains_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.unavailable_domains_id_seq OWNER TO postgres;

--
-- Name: unavailable_domains_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.unavailable_domains_id_seq OWNED BY public.unavailable_domains.id;


--
-- Name: user_invite_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_invite_requests (
    id bigint NOT NULL,
    user_id bigint,
    text text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_invite_requests OWNER TO postgres;

--
-- Name: user_invite_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_invite_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_invite_requests_id_seq OWNER TO postgres;

--
-- Name: user_invite_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_invite_requests_id_seq OWNED BY public.user_invite_requests.id;


--
-- Name: user_ips; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.user_ips AS
 SELECT t0.user_id,
    t0.ip,
    max(t0.used_at) AS used_at
   FROM ( SELECT users.id AS user_id,
            users.sign_up_ip AS ip,
            users.created_at AS used_at
           FROM public.users
          WHERE (users.sign_up_ip IS NOT NULL)
        UNION ALL
         SELECT session_activations.user_id,
            session_activations.ip,
            session_activations.updated_at
           FROM public.session_activations
        UNION ALL
         SELECT login_activities.user_id,
            login_activities.ip,
            login_activities.created_at
           FROM public.login_activities
          WHERE (login_activities.success = true)) t0
  GROUP BY t0.user_id, t0.ip;


ALTER TABLE public.user_ips OWNER TO postgres;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    color character varying DEFAULT ''::character varying NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    permissions bigint DEFAULT 0 NOT NULL,
    highlighted boolean DEFAULT false NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: user_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_roles_id_seq OWNER TO postgres;

--
-- Name: user_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_roles_id_seq OWNED BY public.user_roles.id;


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: web_push_subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.web_push_subscriptions (
    id bigint NOT NULL,
    endpoint character varying NOT NULL,
    key_p256dh character varying NOT NULL,
    key_auth character varying NOT NULL,
    data json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    access_token_id bigint,
    user_id bigint
);


ALTER TABLE public.web_push_subscriptions OWNER TO postgres;

--
-- Name: web_push_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.web_push_subscriptions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.web_push_subscriptions_id_seq OWNER TO postgres;

--
-- Name: web_push_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.web_push_subscriptions_id_seq OWNED BY public.web_push_subscriptions.id;


--
-- Name: web_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.web_settings (
    id bigint NOT NULL,
    data json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.web_settings OWNER TO postgres;

--
-- Name: web_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.web_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.web_settings_id_seq OWNER TO postgres;

--
-- Name: web_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.web_settings_id_seq OWNED BY public.web_settings.id;


--
-- Name: webauthn_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.webauthn_credentials (
    id bigint NOT NULL,
    external_id character varying NOT NULL,
    public_key character varying NOT NULL,
    nickname character varying NOT NULL,
    sign_count bigint DEFAULT 0 NOT NULL,
    user_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.webauthn_credentials OWNER TO postgres;

--
-- Name: webauthn_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.webauthn_credentials_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.webauthn_credentials_id_seq OWNER TO postgres;

--
-- Name: webauthn_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.webauthn_credentials_id_seq OWNED BY public.webauthn_credentials.id;


--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.webhooks (
    id bigint NOT NULL,
    url character varying NOT NULL,
    events character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    secret character varying DEFAULT ''::character varying NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    template text
);


ALTER TABLE public.webhooks OWNER TO postgres;

--
-- Name: webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.webhooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.webhooks_id_seq OWNER TO postgres;

--
-- Name: webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.webhooks_id_seq OWNED BY public.webhooks.id;


--
-- Name: account_aliases id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_aliases ALTER COLUMN id SET DEFAULT nextval('public.account_aliases_id_seq'::regclass);


--
-- Name: account_conversations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_conversations ALTER COLUMN id SET DEFAULT nextval('public.account_conversations_id_seq'::regclass);


--
-- Name: account_deletion_requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_deletion_requests ALTER COLUMN id SET DEFAULT nextval('public.account_deletion_requests_id_seq'::regclass);


--
-- Name: account_domain_blocks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_domain_blocks ALTER COLUMN id SET DEFAULT nextval('public.account_domain_blocks_id_seq'::regclass);


--
-- Name: account_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_migrations ALTER COLUMN id SET DEFAULT nextval('public.account_migrations_id_seq'::regclass);


--
-- Name: account_moderation_notes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_moderation_notes ALTER COLUMN id SET DEFAULT nextval('public.account_moderation_notes_id_seq'::regclass);


--
-- Name: account_notes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_notes ALTER COLUMN id SET DEFAULT nextval('public.account_notes_id_seq'::regclass);


--
-- Name: account_pins id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_pins ALTER COLUMN id SET DEFAULT nextval('public.account_pins_id_seq'::regclass);


--
-- Name: account_relationship_severance_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_relationship_severance_events ALTER COLUMN id SET DEFAULT nextval('public.account_relationship_severance_events_id_seq'::regclass);


--
-- Name: account_stats id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_stats ALTER COLUMN id SET DEFAULT nextval('public.account_stats_id_seq'::regclass);


--
-- Name: account_statuses_cleanup_policies id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_statuses_cleanup_policies ALTER COLUMN id SET DEFAULT nextval('public.account_statuses_cleanup_policies_id_seq'::regclass);


--
-- Name: account_warning_presets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_warning_presets ALTER COLUMN id SET DEFAULT nextval('public.account_warning_presets_id_seq'::regclass);


--
-- Name: account_warnings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_warnings ALTER COLUMN id SET DEFAULT nextval('public.account_warnings_id_seq'::regclass);


--
-- Name: admin_action_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_action_logs ALTER COLUMN id SET DEFAULT nextval('public.admin_action_logs_id_seq'::regclass);


--
-- Name: announcement_mutes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_mutes ALTER COLUMN id SET DEFAULT nextval('public.announcement_mutes_id_seq'::regclass);


--
-- Name: announcement_reactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_reactions ALTER COLUMN id SET DEFAULT nextval('public.announcement_reactions_id_seq'::regclass);


--
-- Name: announcements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcements ALTER COLUMN id SET DEFAULT nextval('public.announcements_id_seq'::regclass);


--
-- Name: appeals id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appeals ALTER COLUMN id SET DEFAULT nextval('public.appeals_id_seq'::regclass);


--
-- Name: backups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backups ALTER COLUMN id SET DEFAULT nextval('public.backups_id_seq'::regclass);


--
-- Name: blocks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blocks ALTER COLUMN id SET DEFAULT nextval('public.blocks_id_seq'::regclass);


--
-- Name: bookmarks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookmarks ALTER COLUMN id SET DEFAULT nextval('public.bookmarks_id_seq'::regclass);


--
-- Name: bulk_import_rows id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bulk_import_rows ALTER COLUMN id SET DEFAULT nextval('public.bulk_import_rows_id_seq'::regclass);


--
-- Name: bulk_imports id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bulk_imports ALTER COLUMN id SET DEFAULT nextval('public.bulk_imports_id_seq'::regclass);


--
-- Name: canonical_email_blocks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.canonical_email_blocks ALTER COLUMN id SET DEFAULT nextval('public.canonical_email_blocks_id_seq'::regclass);


--
-- Name: conversation_mutes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_mutes ALTER COLUMN id SET DEFAULT nextval('public.conversation_mutes_id_seq'::regclass);


--
-- Name: conversations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations ALTER COLUMN id SET DEFAULT nextval('public.conversations_id_seq'::regclass);


--
-- Name: custom_emoji_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_emoji_categories ALTER COLUMN id SET DEFAULT nextval('public.custom_emoji_categories_id_seq'::regclass);


--
-- Name: custom_emojis id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_emojis ALTER COLUMN id SET DEFAULT nextval('public.custom_emojis_id_seq'::regclass);


--
-- Name: custom_filter_keywords id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_filter_keywords ALTER COLUMN id SET DEFAULT nextval('public.custom_filter_keywords_id_seq'::regclass);


--
-- Name: custom_filter_statuses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_filter_statuses ALTER COLUMN id SET DEFAULT nextval('public.custom_filter_statuses_id_seq'::regclass);


--
-- Name: custom_filters id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_filters ALTER COLUMN id SET DEFAULT nextval('public.custom_filters_id_seq'::regclass);


--
-- Name: domain_allows id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.domain_allows ALTER COLUMN id SET DEFAULT nextval('public.domain_allows_id_seq'::regclass);


--
-- Name: domain_blocks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.domain_blocks ALTER COLUMN id SET DEFAULT nextval('public.domain_blocks_id_seq'::regclass);


--
-- Name: email_domain_blocks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_domain_blocks ALTER COLUMN id SET DEFAULT nextval('public.email_domain_blocks_id_seq'::regclass);


--
-- Name: favourites id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favourites ALTER COLUMN id SET DEFAULT nextval('public.favourites_id_seq'::regclass);


--
-- Name: featured_tags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.featured_tags ALTER COLUMN id SET DEFAULT nextval('public.featured_tags_id_seq'::regclass);


--
-- Name: follow_recommendation_mutes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follow_recommendation_mutes ALTER COLUMN id SET DEFAULT nextval('public.follow_recommendation_mutes_id_seq'::regclass);


--
-- Name: follow_recommendation_suppressions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follow_recommendation_suppressions ALTER COLUMN id SET DEFAULT nextval('public.follow_recommendation_suppressions_id_seq'::regclass);


--
-- Name: follow_requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follow_requests ALTER COLUMN id SET DEFAULT nextval('public.follow_requests_id_seq'::regclass);


--
-- Name: follows id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows ALTER COLUMN id SET DEFAULT nextval('public.follows_id_seq'::regclass);


--
-- Name: generated_annual_reports id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generated_annual_reports ALTER COLUMN id SET DEFAULT nextval('public.generated_annual_reports_id_seq'::regclass);


--
-- Name: identities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identities ALTER COLUMN id SET DEFAULT nextval('public.identities_id_seq'::regclass);


--
-- Name: imports id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imports ALTER COLUMN id SET DEFAULT nextval('public.imports_id_seq'::regclass);


--
-- Name: invites id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invites ALTER COLUMN id SET DEFAULT nextval('public.invites_id_seq'::regclass);


--
-- Name: ip_blocks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ip_blocks ALTER COLUMN id SET DEFAULT nextval('public.ip_blocks_id_seq'::regclass);


--
-- Name: list_accounts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.list_accounts ALTER COLUMN id SET DEFAULT nextval('public.list_accounts_id_seq'::regclass);


--
-- Name: lists id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lists ALTER COLUMN id SET DEFAULT nextval('public.lists_id_seq'::regclass);


--
-- Name: login_activities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_activities ALTER COLUMN id SET DEFAULT nextval('public.login_activities_id_seq'::regclass);


--
-- Name: markers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.markers ALTER COLUMN id SET DEFAULT nextval('public.markers_id_seq'::regclass);


--
-- Name: mentions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentions ALTER COLUMN id SET DEFAULT nextval('public.mentions_id_seq'::regclass);


--
-- Name: mutes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mutes ALTER COLUMN id SET DEFAULT nextval('public.mutes_id_seq'::regclass);


--
-- Name: notification_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_permissions ALTER COLUMN id SET DEFAULT nextval('public.notification_permissions_id_seq'::regclass);


--
-- Name: notification_policies id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_policies ALTER COLUMN id SET DEFAULT nextval('public.notification_policies_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: oauth_access_grants id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_grants ALTER COLUMN id SET DEFAULT nextval('public.oauth_access_grants_id_seq'::regclass);


--
-- Name: oauth_access_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.oauth_access_tokens_id_seq'::regclass);


--
-- Name: oauth_applications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_applications ALTER COLUMN id SET DEFAULT nextval('public.oauth_applications_id_seq'::regclass);


--
-- Name: pghero_space_stats id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pghero_space_stats ALTER COLUMN id SET DEFAULT nextval('public.pghero_space_stats_id_seq'::regclass);


--
-- Name: poll_votes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_votes ALTER COLUMN id SET DEFAULT nextval('public.poll_votes_id_seq'::regclass);


--
-- Name: polls id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.polls ALTER COLUMN id SET DEFAULT nextval('public.polls_id_seq'::regclass);


--
-- Name: preview_card_providers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preview_card_providers ALTER COLUMN id SET DEFAULT nextval('public.preview_card_providers_id_seq'::regclass);


--
-- Name: preview_card_trends id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preview_card_trends ALTER COLUMN id SET DEFAULT nextval('public.preview_card_trends_id_seq'::regclass);


--
-- Name: preview_cards id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preview_cards ALTER COLUMN id SET DEFAULT nextval('public.preview_cards_id_seq'::regclass);


--
-- Name: relationship_severance_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relationship_severance_events ALTER COLUMN id SET DEFAULT nextval('public.relationship_severance_events_id_seq'::regclass);


--
-- Name: relays id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relays ALTER COLUMN id SET DEFAULT nextval('public.relays_id_seq'::regclass);


--
-- Name: report_notes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_notes ALTER COLUMN id SET DEFAULT nextval('public.report_notes_id_seq'::regclass);


--
-- Name: reports id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports ALTER COLUMN id SET DEFAULT nextval('public.reports_id_seq'::regclass);


--
-- Name: rules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rules ALTER COLUMN id SET DEFAULT nextval('public.rules_id_seq'::regclass);


--
-- Name: scheduled_statuses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduled_statuses ALTER COLUMN id SET DEFAULT nextval('public.scheduled_statuses_id_seq'::regclass);


--
-- Name: session_activations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_activations ALTER COLUMN id SET DEFAULT nextval('public.session_activations_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: severed_relationships id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.severed_relationships ALTER COLUMN id SET DEFAULT nextval('public.severed_relationships_id_seq'::regclass);


--
-- Name: site_uploads id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_uploads ALTER COLUMN id SET DEFAULT nextval('public.site_uploads_id_seq'::regclass);


--
-- Name: software_updates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.software_updates ALTER COLUMN id SET DEFAULT nextval('public.software_updates_id_seq'::regclass);


--
-- Name: status_edits id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_edits ALTER COLUMN id SET DEFAULT nextval('public.status_edits_id_seq'::regclass);


--
-- Name: status_pins id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_pins ALTER COLUMN id SET DEFAULT nextval('public.status_pins_id_seq'::regclass);


--
-- Name: status_stats id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_stats ALTER COLUMN id SET DEFAULT nextval('public.status_stats_id_seq'::regclass);


--
-- Name: status_trends id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_trends ALTER COLUMN id SET DEFAULT nextval('public.status_trends_id_seq'::regclass);


--
-- Name: tag_follows id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tag_follows ALTER COLUMN id SET DEFAULT nextval('public.tag_follows_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: tombstones id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tombstones ALTER COLUMN id SET DEFAULT nextval('public.tombstones_id_seq'::regclass);


--
-- Name: unavailable_domains id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unavailable_domains ALTER COLUMN id SET DEFAULT nextval('public.unavailable_domains_id_seq'::regclass);


--
-- Name: user_invite_requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_invite_requests ALTER COLUMN id SET DEFAULT nextval('public.user_invite_requests_id_seq'::regclass);


--
-- Name: user_roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN id SET DEFAULT nextval('public.user_roles_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: web_push_subscriptions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.web_push_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.web_push_subscriptions_id_seq'::regclass);


--
-- Name: web_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.web_settings ALTER COLUMN id SET DEFAULT nextval('public.web_settings_id_seq'::regclass);


--
-- Name: webauthn_credentials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webauthn_credentials ALTER COLUMN id SET DEFAULT nextval('public.webauthn_credentials_id_seq'::regclass);


--
-- Name: webhooks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhooks ALTER COLUMN id SET DEFAULT nextval('public.webhooks_id_seq'::regclass);


--
-- Data for Name: account_aliases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_aliases (id, account_id, acct, uri, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: account_conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_conversations (id, account_id, conversation_id, participant_account_ids, status_ids, last_status_id, lock_version, unread) FROM stdin;
\.


--
-- Data for Name: account_deletion_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_deletion_requests (id, account_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: account_domain_blocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_domain_blocks (id, domain, created_at, updated_at, account_id) FROM stdin;
\.


--
-- Data for Name: account_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_migrations (id, account_id, acct, followers_count, target_account_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: account_moderation_notes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_moderation_notes (id, content, account_id, target_account_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: account_notes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_notes (id, account_id, target_account_id, comment, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: account_pins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_pins (id, account_id, target_account_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: account_relationship_severance_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_relationship_severance_events (id, account_id, relationship_severance_event_id, created_at, updated_at, followers_count, following_count) FROM stdin;
\.


--
-- Data for Name: account_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_stats (id, account_id, statuses_count, following_count, followers_count, created_at, updated_at, last_status_at) FROM stdin;
1	115338428152261473	1	0	0	2025-10-08 11:59:15.273211	2025-10-08 11:59:15.273211	2025-10-08 11:59:15.268083
2	115338428325536028	6	0	0	2025-10-08 11:59:15.324117	2025-10-13 20:09:15.234228	2025-10-10 05:05:29.775659
65	115407279078399620	0	0	1	2025-10-20 15:49:26.318205	2025-10-20 15:49:26.318205	\N
67	115407279337451464	0	0	1	2025-10-20 15:49:39.706035	2025-10-20 15:49:39.706035	\N
46	115383646696917550	8	0	1	2025-10-16 11:44:46.165046	2025-10-12 06:09:33.385591	2025-10-16 13:10:22.96345
50	115383709981264049	6	0	1	2025-10-16 12:09:56.554645	2025-10-12 06:09:43.15319	2025-10-16 13:12:24.810106
70	115410778295457737	4	0	1	2025-10-21 06:46:58.895175	2025-10-12 06:09:56.979329	2025-10-21 06:53:34.587396
76	115445893227871976	12	0	1	2025-10-01 02:31:22.903263	2025-10-12 06:10:03.626115	2025-10-11 04:00:30.8163
88	115347680385540244	4	0	1	2025-10-03 03:07:40.435043	2025-10-12 06:10:11.827509	2025-10-12 06:02:42.996304
89	115347680582977591	10	0	1	2025-10-03 03:13:31.085377	2025-10-12 06:10:17.776789	2025-10-12 06:01:13.024497
92	115347680754305497	10	0	1	2025-10-03 03:19:37.429923	2025-10-12 06:10:26.429497	2025-10-12 06:02:14.815065
69	115407279554762986	1	0	1	2025-10-20 15:49:47.425491	2025-10-15 14:33:11.8835	2025-10-15 14:33:11.8835
3	115338428522805842	3	11	0	2025-10-08 11:59:15.369581	2025-10-15 14:32:13.176215	2025-10-15 14:31:07.655292
156	115378678396852544	9	0	1	2025-10-02 14:31:55.301142	2025-10-15 14:32:13.176215	2025-10-15 14:30:49.387925
\.


--
-- Data for Name: account_statuses_cleanup_policies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_statuses_cleanup_policies (id, account_id, enabled, min_status_age, keep_direct, keep_pinned, keep_polls, keep_media, keep_self_fav, keep_self_bookmark, min_favs, min_reblogs, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: account_warning_presets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_warning_presets (id, text, created_at, updated_at, title) FROM stdin;
\.


--
-- Data for Name: account_warnings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_warnings (id, account_id, target_account_id, action, text, created_at, updated_at, report_id, status_ids, overruled_at) FROM stdin;
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (id, username, domain, private_key, public_key, created_at, updated_at, note, display_name, uri, url, avatar_file_name, avatar_content_type, avatar_file_size, avatar_updated_at, header_file_name, header_content_type, header_file_size, header_updated_at, avatar_remote_url, locked, header_remote_url, last_webfingered_at, inbox_url, outbox_url, shared_inbox_url, followers_url, protocol, memorial, moved_to_account_id, featured_collection_url, fields, actor_type, discoverable, also_known_as, silenced_at, suspended_at, hide_collections, avatar_storage_schema_version, header_storage_schema_version, sensitized_at, suspension_origin, trendable, reviewed_at, requested_review_at, indexable, attribution_domains) FROM stdin;
-99	mastodon.internal	\N	-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKCAQEA0tlq8p1C2EhdElWKRnTIbcC011tno19OeaJ43nm2BD7MTbGG\nJ1pFeL4JVWHF34ZtC4e+mpxc+2u20BAsuAzmFvlTHiAQ/BC9X0PlvEVZwP3cTYVl\nKlfl6N73bzzXkKirgtGRB1js04Uh4+l/h/lFRzgg4oMPTnK6E9rhhwAxdZzrVQ6v\ndDphUAE7aAc/THqIEo+iZ+qM5U1egSzPBN/6otrcuUjh1pnfE3gD/j5uhdUcai5w\nXhujPIXbCBVlS0rNpKq+8dwrqEfI4eIMX3eRvXL+1WHBt9mXOUuVNRHjM49Prwkr\nZV3hCc3rKZTReZRe3KNW84KJ3ceKqDwv5dURIQIDAQABAoIBAAJ63Wwu8pXZf9bx\nSkWWH80S3kwNDPJ7jCnrO4P1Xarq3Xg/985mCS/LspxbGiq5zM99CFF1K5uAh4EA\nVOa3+x66NIxKPDaBkJkKkvmkcKy8p6Vo3193DKYxDvfs8nJtTQtTIVZhnFmucajt\nBDhoxrpyo+6TtBlCfIlzGOI5O7uwzqKiucLWtgj7xIAwbJVMsfN51UUXVLQSYwmX\nK7cWHwYGnWIE9L6Sd58FP3+TF63jJxReEmTZ7H47ztOi73Zx+RU0dSgGhF+GTJQv\nnUN4Zdy7rM/xGao2o5D6keuGL+aKV9WFHVEO4U8pjtR/PaDSO0uRipFHTxBYQtGQ\ny1MxlaECgYEA/r/u8uBot3RTQv3Hl4b0WNOp38J3jRZl/lp2ZUjwdT63TCDPq69m\n5t8QxXUYHOBDr8TS5zZVkORf0z0vkUHc9l0Gc4ys53Nb7FEuZ9Ay2ca6+UGmS342\ng98CpGbnkbcVopx3D/t9Q/hz/pGGAnfyNZWgFx74RzSyLatEIsPkSFECgYEA0+JT\n+HgQTvgh4fIIVbDKfcy7Jtx62OJCxyel5Znh0XIbrJ1PNABr0ix1nlNqxBDhHgdF\nnNNHUraiTZ70kwYru6wPFM9ce+E0hscFV6oOx/pTk325yE1QOG90CnRgZP0YkRiZ\nWgA1dlq3o+0hMOAvwGm/bbAyxKGWCRRg6Q+a19ECgYEAk5T/yiblo3o5jjLVgVxG\njHs7C41ukwbp2ZvwwSarX1ERAYJ0rOK1u4R5A9udN4VY0Sg2gopAsesL9KWavA0r\nBHLJ/QD/Xiq/kz1IpA3Cl9WAlkxJGa0pyeXVcwbGmu01FHqOo2yvmkQCdvU5bI6u\nfAqNrzda4G2P19NDatyPkLECgYBg3yo7AFGceS+siKas3s5FY7PxGX6E6DVVrlfX\nuFoZEw16BtXuVX72MWN5BnRavcjenL6D68jBFUTxLgptqbWW8RxYDFIhRR5pvFZB\n9TsazOUnGqU04bwagUJRgVGM+nYf6Fo8XroSqXkqVkEFgonyc6aUtKkRYzsgXZPN\nGlhV8QKBgQDO2WeN+GkV/2L1B8LWTVnjXv09esq2dRuDgktIXr1ULcUzUOuHYsFS\n0VGh27bXiTTcSXjrRoihb58cosrBLnNePuKGQJOBezebINa4LAuyRyaBodntdLr9\nyF0/5w/OYJ065CxZMunohTMz+7YmI91zVBc04e7bIcg3F5b5KQGRrg==\n-----END RSA PRIVATE KEY-----\n	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0tlq8p1C2EhdElWKRnTI\nbcC011tno19OeaJ43nm2BD7MTbGGJ1pFeL4JVWHF34ZtC4e+mpxc+2u20BAsuAzm\nFvlTHiAQ/BC9X0PlvEVZwP3cTYVlKlfl6N73bzzXkKirgtGRB1js04Uh4+l/h/lF\nRzgg4oMPTnK6E9rhhwAxdZzrVQ6vdDphUAE7aAc/THqIEo+iZ+qM5U1egSzPBN/6\notrcuUjh1pnfE3gD/j5uhdUcai5wXhujPIXbCBVlS0rNpKq+8dwrqEfI4eIMX3eR\nvXL+1WHBt9mXOUuVNRHjM49PrwkrZV3hCc3rKZTReZRe3KNW84KJ3ceKqDwv5dUR\nIQIDAQAB\n-----END PUBLIC KEY-----\n	2025-10-08 11:57:24.759098	2025-10-08 11:57:24.759098				\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t		\N					0	f	\N	\N	\N	Application	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	{}
115338428152261473	owner	\N	-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKCAQEAwvq2TPyE2KzuWmfbhOKmXptCs+Ehl3pWAgi0/WSGGhZJUSwE\nLDKJnaTj7eOtuUc4v/NZVHbhO6OOGNp89pfpok5RKwA03zQAV7yyfU1cNV1tVGLx\nISBVhC7j4H6nnRXVO81gPIx8XQ1Fc1tHl6r9mcj4mwU3YCw9YerTJCUxI3M79AN+\ngGydFIld3jP+IE4YMII1ugrl2PYVRBslBdKPlAZR/LSvmmaTI8ZzsS/tKCV0ANBV\n8yDVauFhP9ELG69Ssvq5+Yb965mVThi5/jp/hHpgBZcYs0p/wBmgRfokXysUpwOe\nf/HHQxAkziWA7adv/5qcGM5rTF2R/dGfoI7HRwIDAQABAoIBAD5evJn73PMCvmwk\n9M+ZQObae4fW6EvwUjrsVhkIYu1NW76feeY5dFP9PvwF7Lhr0/dy/IxMStgtBXNl\n0LuA9Ld6nfRHaKJNnB50uhPi/zAC5sorrD6QfUp/RV22ph9VsJQkqjg0KEQLzr+L\n32bgx6a95uiPzprxC+GaoFfbndBcqGSNQK+VP69uuZT4iPHZxCSSoVGPg1Uvi63k\nxBNOrL/TG9KUMkcoYOFr6AmO9znJA08RGgpISCMvWdfhGgA5vhTFJCAExS/LHPmC\n3t3Md5KgpVIz4arRADvSZ2M7PC3dD80wCmmTgFjMUD1oDx94FYwuRmsktPvvwcaY\nd9r0SIECgYEA+hgFRWHbstzXIW2nUS3EJcedndTvTM9FAQPDqrZnjkz+SbVh/DcK\nCQNpWYLnhIyHqAvY+32CChiZmy+am9A9L1c5r0tTmu0l5trMtMjFAb4nnxSZqG8P\nyUXibFyU/xVXNWIJ27R31Kg/TkJCaek+aKR/4dyCjh39Q3iOSaNz/7ECgYEAx5V9\nG+ZFs5mNr+oZt+iXD+JKEky/g0sDFJNftWmdULgDWPN0cU7QWiNVamqSDusJV2kE\nuTo+lm2XYSha8sVeIdBCqshF+28vF8EDI1aiHpXqIH9cP+BbNO3AkP3UU1YfH3lX\nD5v5m1Bd8MFrEdho96xWPRNf1x3O+FP/zSFYrHcCgYEA6sPBru+9nJlSGT8l4T5k\n8lH/0zkfqaqny9wMwSOY8iu0SNzLrka8VNmu+ye2zOZeMZFtjiay+2c8SkDVkY5Y\n4SewLq03Pid/fMXHg60zwf8OknZ0B3i6COZhNfdypkESLDprpqIyGp4VTxFD5sfc\nnb5NjWfB5kagh8WTS+zz5wECgYAeRiGtGrfV72PbnEH8cI6BfUzJC9U9ACLeeyBY\nb0XKma8ATiWKjm7yTUvGkZXIJ4TKOobZ5ejafpMozKtHCgMmU+XY6/oZkprtGnz0\nXk7HHuxds5P1qH2NQMcl9yq+3WBpMMmw93LcSUuGmoA4O8BoWT7XktnF0qKzbmJt\n5jICLwKBgQC3ccbqWTKTAR2cqcLKOquFeBfpkOdYf+61rZknoP2E2ZRha2TrW5cx\nFBijY1srmRMjgUubj9yCfGLYOh3hqDTnUqrf0yqMibBcFGrwvQ8NrB5ehSVuA0nO\nr/50KrPI9l0GArdHgecVd/fl4B4M/rDn74TIo6Su8MCCJjwIhpJhGA==\n-----END RSA PRIVATE KEY-----\n	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwvq2TPyE2KzuWmfbhOKm\nXptCs+Ehl3pWAgi0/WSGGhZJUSwELDKJnaTj7eOtuUc4v/NZVHbhO6OOGNp89pfp\nok5RKwA03zQAV7yyfU1cNV1tVGLxISBVhC7j4H6nnRXVO81gPIx8XQ1Fc1tHl6r9\nmcj4mwU3YCw9YerTJCUxI3M79AN+gGydFIld3jP+IE4YMII1ugrl2PYVRBslBdKP\nlAZR/LSvmmaTI8ZzsS/tKCV0ANBV8yDVauFhP9ELG69Ssvq5+Yb965mVThi5/jp/\nhHpgBZcYs0p/wBmgRfokXysUpwOef/HHQxAkziWA7adv/5qcGM5rTF2R/dGfoI7H\nRwIDAQAB\n-----END PUBLIC KEY-----\n	2025-10-08 11:59:06.062286	2025-10-08 11:59:06.062286				\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f		\N					0	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	{}
115338428325536028	demo	\N	-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKCAQEAuA3Odz7NEoSPvPAnICQ3YC4cKGTnb85giqkpFs+1z96/0RGE\n+CKD94FBB78VrJnoa6ULUqKkTeT35Z6aDbCOQjWOb8s7n2yOixxbQpxXC9ZtC+WF\nqL2o5zQ7yP8CHlWNsz8+m6gvmVdxx2fl42DvFsMy6oeYpecEqvo1F8DqqxJ3dzRX\nT3FqWYPJOp18eCg3tdvMHCgBV0TQTeSsYH1VNlzgX/Wtp0GJEH2Hou+8TYNu4Euu\nyBfgHyqCbK+8q4T5xahDLsikEe3PF8PQKZ8hLfoQhMFANUI4XY1/FwuWRu6D0dPw\nSlrgaTBwNVAY1+1xdd/L2O0jtYjnPX0eunLFjwIDAQABAoIBABqOoMWjVyhz3jWk\nmqX6886PTgV6FyGShWrx4PmR+6mZz32q6c/P/dC0YsjBBq9Cqemrr92QQDrzwzKW\nVvjgtTYnz3yhYOIDt5xU+XS8EEdR/PwOyza/ibk1V+cMUfxEhfoLhyIjUMhEeNNi\np3t5R3u2VgjHNfxs6scs69pDPi50GsyGHk08SaN58+CgfJh9hDXvzUbu8fZS9EVc\no1j2Jq/Gnl8BluglwSsuuPi8bCuvIUTKRWdEGwFrhoslaTUe0PPq3C5IFwVs6unW\nuGd1NokHz4fMkUwNkJ6LqUX1hsqGY6e19gqYOrDfhSECl4b856uoLiHHBhg5556G\naRsQSKECgYEA+IvYVK3eupw98+SJsVikOZsYz623JAybRUmNWixpFRq58CwQZj3c\n0ge/wJBM0g0R9eBJWHSF1zZzbIgkjhbRx3pkqDmYVCLqGbqWMoVfr/8mpd6JSSBt\n+yCSmuvnApN37ltFi33yN6vEejaQIUQT5fhk0WxMuhIsjTUVGsDH6xECgYEAvZLW\nPDQK5dEwzpkEGpRYbuHmyYjZEQ3/IxIa5UueOhT6QkkaWd9tN0sEGyLp9ofJkMoO\n9ynduF/Oxjq0l501e2dzbfOaKfAd98u2l7CjlwXPzQVPaCAc2ssJR8RWr0I8KsLr\nCkhKhT77Tlom3tqz+nzFgzpzBpWr5JDPsUavZp8CgYEA1nDR1T2uTZNAYI1tv3Wb\nO5h1b7mRqai2zrEHJCXtBChrBKz/+Tamrw/AgYP+w7xDIsDAh3EBiQ2RyLIt1+oY\nVONktT/8DZuSH2C89hnc1RxvW+0ExfMU8PbJhqDCT5asgxp8hj3EHgQ1ILyy3gC+\nqkwFsCqgiGnlxm9mJg7ubgECgYBRIFuKHANl4iXu49C7xywpF4d6S5QJFmJPEdps\nsfWeiYengj1CpLjKZtH1AvX4yJdb3PyWjVYTJv0IG+tYzrAqhVUCgrNAqz9H4efb\n9n2rjZMl+9XFi6iNgUIRclZeXgv9iLipB9LMPu2w1Ce6SwGmemrUA9lhwf9zqv0W\nslcxpQKBgQCZs3tQn2oxor+KnfOtUSERR7VtiXAInF+a0JAwnyC2o5rqWkwH5ee0\nKyHwQNNEM4TaJadXpJeni8VR3AtsMz4CbDL+R/58PCJwI1eKk3auUJdqBzQa6YvC\nvl9GUneSHIbUmT8M39qv4F0DOw7kn9fz9EHz7OEYvfl029XrF+fZZA==\n-----END RSA PRIVATE KEY-----\n	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuA3Odz7NEoSPvPAnICQ3\nYC4cKGTnb85giqkpFs+1z96/0RGE+CKD94FBB78VrJnoa6ULUqKkTeT35Z6aDbCO\nQjWOb8s7n2yOixxbQpxXC9ZtC+WFqL2o5zQ7yP8CHlWNsz8+m6gvmVdxx2fl42Dv\nFsMy6oeYpecEqvo1F8DqqxJ3dzRXT3FqWYPJOp18eCg3tdvMHCgBV0TQTeSsYH1V\nNlzgX/Wtp0GJEH2Hou+8TYNu4EuuyBfgHyqCbK+8q4T5xahDLsikEe3PF8PQKZ8h\nLfoQhMFANUI4XY1/FwuWRu6D0dPwSlrgaTBwNVAY1+1xdd/L2O0jtYjnPX0eunLF\njwIDAQAB\n-----END PUBLIC KEY-----\n	2025-10-08 11:59:08.665289	2025-10-08 14:39:24.943949		demo		\N	90b961acc01a2951.png	image/png	23336	2025-10-08 14:39:24.744187	\N	\N	\N	\N	\N	f		\N					0	f	\N	\N	[]	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	f	{}
115383709981264049	openUniversity	\N	-----BEGIN RSA PRIVATE KEY-----\nMIIEogIBAAKCAQEAiEIOjDn4mmEsRx/zwEzO803WuwIFkkqWdSO+TXPt5bxnSYaG\nETMpaYzyFbeGKBtyM6EhS8wNxY516il8VaGyoSj6hd6VAS+JWdqqgGSmjmIRLIjD\nz399QD/cjhp9YrZ8ItQsDzKWkxPjpJ+T81suMtjgX82/1wZXhLKF7nTG0jHzipc4\nCU3z3aDXZkWHb9gGnVzNp8ps/vwDJ1BFVh6Z/nPWRDkTp/mXzB7n8hXjiMAWX2W+\nNQz34w/1Nr8qS0CIS5Gt+EJ3Y4hIJZ5pQwA4QW21+RycQHhCqJTvdyelHplSSdqU\ngEhQBzo5h6qSRELDZzBPr7Hv7J7aSleQb4IheQIDAQABAoIBAAQHrXXOR8u2cLXQ\nfHLFPXW1aVLHS4eOdzFoaOTSN0i32szc6Agy3YMGrSj2mvGCu6JKng582YdsoDuD\nFe9TxKcUQYdGFF11nM1bNKHELaeWakWelz6thEnV2bMbliEeSUD1H4ck4Dk3ZGCR\nFlzN5z7lFTXK2GVcBaiiExNWFtn5SdqoV69QCyNG11vmbalJdYrYWXSXLMmOc0Xt\n9fpdz8sM1upiVBnjYbWFRMTyksKplh8Un3LtMW32GxUUIvfh0XWOi+/m0Db5AeEu\n2hsw3tS0adywlPYMxVP9rn0SMjnVo8v8mQP08OvoNu8NDGL1Kx1rnoImMKm640hW\nnguBUSUCgYEAvz7eD6veBK7Z2bOHawqblL+Lag94ZnPFgieLo22nAVpIgmwWzDp5\nazZDP5f1LBzsE5zZw6pGS59GLvnGEORMiK4CzO2S3NIHmJL169oEQ1rfyHZQ9M0F\nndbUB36dI+fSh5EHrm+KOlABBdWHXoOpC2o7IzVTurxLMVLBhbXaBicCgYEAtmTh\nCtOLsrIEDnYmSSlY827kPFVdVXhtYWI4E2cm95NQAQyqmfz/2mfEjPwMEFGWiaZR\nLj3pzRYbyRNMH1fLAtLe2X+aUyVDHZuhaGeqpCwrEBmmw5ZDIs2+/mlql5L7DZmP\nA2Z2j9CE8cG5cUwVX2wFhB3TP6IOaJL11Olf/18CgYA9nci37dzDT3566J+5uho0\nS55kVoWpJKW+8HTJ+9sx0V/JPX/+3twd0cbK52+jfdIF46Q5qVOqq69WFT1eVd/e\nrYnTcru9j6HI45h+G6kB9nZhRNWCecfUedGodH+2gMtQyEZcSi2T6hDaS1io9+xv\n9BMHnffTEzV6t7oIFXYgQwKBgDdXYoTzbQa6RsrQhItcVVX/hpbb2+bsFFwg/hy9\nBrDF7Nd0rWrtvf/ZzmRssYheCQwY/7bFKGSG2cVn6of0Dm/75Ywe0Id73eJk71OL\naNZJZIONFPFxbUtpHBN7jtEQ0sXsmt0QQNcgEMZ93jOHP1DlqMLOfeNn23FVbeu9\nJ9iHAoGAXwbiBDpVL5HjjHoJ6sSQlG+YG1UvIpqg+Go2Rk7fNEQV9SC7+NOQDnXx\n5Vb1vmN9NNSmwYj7x/DWn4r7PuZtSS9LjoE4gtb4VgSHxPargs7GJbYmqJ8jJ1Fn\nSxrmPESY71dPE0YDcV4dzzab/f7ibsMSUpqwPpnVxy2OBbmJuG8=\n-----END RSA PRIVATE KEY-----\n	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAiEIOjDn4mmEsRx/zwEzO\n803WuwIFkkqWdSO+TXPt5bxnSYaGETMpaYzyFbeGKBtyM6EhS8wNxY516il8VaGy\noSj6hd6VAS+JWdqqgGSmjmIRLIjDz399QD/cjhp9YrZ8ItQsDzKWkxPjpJ+T81su\nMtjgX82/1wZXhLKF7nTG0jHzipc4CU3z3aDXZkWHb9gGnVzNp8ps/vwDJ1BFVh6Z\n/nPWRDkTp/mXzB7n8hXjiMAWX2W+NQz34w/1Nr8qS0CIS5Gt+EJ3Y4hIJZ5pQwA4\nQW21+RycQHhCqJTvdyelHplSSdqUgEhQBzo5h6qSRELDZzBPr7Hv7J7aSleQb4Ih\neQIDAQAB\n-----END PUBLIC KEY-----\n	2025-10-16 11:54:51.924916	2025-10-16 12:13:48.514143	We focus on the education cause	openUniversity		\N	e427532fbe2f0444.jpg	image/jpeg	37767	2025-10-16 12:13:48.441779	\N	\N	\N	\N	\N	f		\N					0	f	\N	\N	[]	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	f	{}
115383646696917550	frank	\N	-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKCAQEAzwJUO3BAJ6z37KOmX2QLQDEsGwHYAKiH8ZUy9NGzsSL4N8tx\nuOc9WY0aOgk66GyaZRwf/5rs0zHG7WDpu8FX+v4wyoqWN8ko0ONxTwHkWgHRya2z\nKactwpc9v5jfQ1l1W5K1yXaTBQOsfhVytLyS+bAaAVhNiKrZqtu/fHlcq/UuqWxT\nBgpo4bb3+RKRwr376tOVkwnFetXehraU6L7aU5w+0woM25fp/7Pm3cCRhy1S1SIa\nZOEkG9BItzvz+BKBYl3skJ0TD1yEct/S2IFQ30qhmO69XeHF07faBwVK7A1oxqgc\nbQEjFsu+kmxvzNKEPtL0a5ih/omVrQvyNoEY/QIDAQABAoIBAE3s/AVmA5iL6cZY\ncnQ9RmjzOb2u63+P8aDU/9oeKK0ZU2Q5fwVScwtHbSSEvfqpi1Ndi4Qeb2EvP0mz\nrjkCFtsCnh5YniTA4k8EF27c8Pea8LyhWSzoZHb4lQOPihgh0GZY63q72qtMDz5l\nV4lG5XL9wkRYV9OHMSo6z7INQ3/tPj37tKT+Yc4AK9n1t4fIKO7WKHJSCUzvgo3X\nmKCioTkiCEjhUl+ihR8twif2jWZVQhkSretPuZZ+e2o4bH8xWLLcRGemtulvZ70x\nUClRDdjxtoyPgpcD4dNwACDewWW8rXeUhCfy0Q5wgP3ke25gPuFUdjtpjMdASZov\nwUTSCZcCgYEA6ZaCMmbdx9ZMPU+nZ4G+DGWK8I6o6LmSXA4doKvOCzzyc6WcSWcN\nBWSFuFbymqGJrf7+aPnxa9FTtszreEaUdn/0c7RdltFevNGaDvCjk+OZqSqlkXVc\nsY1VgG0PZupPUGVjnoPTn3tcGC6TP62V6bqbITlegr9p59B61uaD6icCgYEA4t76\nuUcJ+6/WRoYPH4zfaE0REvbfiRJhf6UbZ+fL78MiARCd13OkEHohs0Dk5LEy2A7V\nz3ATm+XaHL5ywrScuPkogXAFs58UB+23tXcRiDpLL0+InmJuevHMvgdybLSIkIek\nGIEYC2UWUoFdiPrP/MCmF9GtvkHLimjeC7HUDjsCgYBg+aND2YDpngY4zgDp7+s+\nqklsZU2qkKA6p4GVWr5H3B2r9W1U6/tz6a+6QB6oI7hNDDgCzQF1iYn/skNvw52P\nNL//6TmRi4qRSVN0MGM42pzIpnPmV5sL+2kr0Bs81rnm3rDk9kW9SDGLuIpZPW+n\ngVk2CeM61Mza+KqG3VyWsQKBgQDSLbdj7H9AL8+4eDwMg6r5auRViGbhCylOYvy3\nz1Ps5P9cszM3xgeJyEvuUEF96PfsmBnW2sMf29qsZHfXEBJdf17aQ5jUppydF8rp\nD80rQq4iv3EXIqOtvNNsfWOxd7NJCpCorvhCnj0G5Jht7cbAJw345SUsLLJPoQWN\nGgsVvwKBgQChV/rIJfMzhg3xVIp881wE2lU39v7zCTQCleLcVaakKfeW0l+Ri24u\noKG/wKW1/5Zxi11A+TnA7zh3PBdaRUs1IDJHsnwkaolsOzG1HrkzOUx/Bc1byjIN\n1z/tNqRYxZJFvSM+gptkN33w4/K1y8P2NScgb5m0Ekk/XdVPBtgD3g==\n-----END RSA PRIVATE KEY-----\n	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAzwJUO3BAJ6z37KOmX2QL\nQDEsGwHYAKiH8ZUy9NGzsSL4N8txuOc9WY0aOgk66GyaZRwf/5rs0zHG7WDpu8FX\n+v4wyoqWN8ko0ONxTwHkWgHRya2zKactwpc9v5jfQ1l1W5K1yXaTBQOsfhVytLyS\n+bAaAVhNiKrZqtu/fHlcq/UuqWxTBgpo4bb3+RKRwr376tOVkwnFetXehraU6L7a\nU5w+0woM25fp/7Pm3cCRhy1S1SIaZOEkG9BItzvz+BKBYl3skJ0TD1yEct/S2IFQ\n30qhmO69XeHF07faBwVK7A1oxqgcbQEjFsu+kmxvzNKEPtL0a5ih/omVrQvyNoEY\n/QIDAQAB\n-----END PUBLIC KEY-----\n	2025-10-16 11:38:47.541278	2025-10-16 12:01:43.323948		frank		\N	d8e2455a28963838.png	image/png	89188	2025-10-16 12:01:43.175692	\N	\N	\N	\N	\N	f		\N					0	f	\N	\N	[]	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	f	{}
115407279078399620	alex	\N	-----BEGIN RSA PRIVATE KEY-----\nMIIEogIBAAKCAQEAm6yc8RdHLxJhKK6IoOgZH/WrNhwdrpm5BetSFqyiseM95fzE\nVVhM9pWD6+ECzdq29FH33ibAF3Q87oqvC48N9gZEz/zNtrFOgRuaj1Q/0/SGbJRS\nUJ21Dz/1muUoMjqZgZ0c8lMma3kT6OFOaV17psPZGsMG42OU77HHkazBz9K68FPf\ndiG357U5vxbRRi5y3xypCuJhDUTDkbCZXXUrhaJpQVso+Mp0p6L/IRN6CRrU9ayf\nkJyPRNSE/xFbzNjGEj8uaXbWez52OnYTaVa8lP/c+EhfyLU7+L/Ym34awsFFIH+X\nqohC4HcOKiqEtHOUXP/bqLtbE5qRSxgcBolaAwIDAQABAoIBAAYlcQbVx/I0VBCy\nn2NW9pL79JgM0SExIYx5x4Jsq3nBgpKfgbLq6xL7QTuhZSZygbGwwMwNFJ14ceVr\nJVEcA02Y3sOldAvIAVT4nYgWJ/T63QnRa1SSfXEOMei9LnKZPLFQ3jE1Fjm9DIuv\nxZREZBrn9ZzoYU++AUXba4k1XGuTkwmcZCXOQ4IUVCLhRPzMJZ63D/dvSt1rJRyZ\n3wvbEpbo0O+Asf8H5dZKEs4joT6Pa+ncxpR1AZX8fLb0SoM+hPVjyMu49gm5UAUM\nMC8PT/qgnRoWSnF0Jc+a8vb/qSZiPUBW3HDtu52IGg+QHJy5VIwitsUTVq+G2VMa\nxTP8Qc0CgYEA2hPR3MzGdPoEZwqwRhUElKYZ7Y7T/lmTAhE7Fo1CjM23+v/wdrf0\ncFIGfIZ8XWdMLiyHC1OA57QYrK3epqyLS/zfw+gGk/r2RTzudkY9Inh72rhz3y4y\nIzoaj4ovRVE4c9C605KnoMmkPnRRZ+9XhEkXvAtxC2P2Pn4VNzZ8Mc0CgYEAtr7I\nxj2sD+R0y9t9dfag/yIKCSaMgDa8VtK6G/68ZTzY4nmmTlqR9hGmflQanGQBKVrQ\nJwnZnBbiqG/3i92qTzQE62uMSF6b0ZRKGfioBKw2eAOjLd4tGBObYn/oRUmfzqHs\nwiKk+Dy+kc8PXLMb1oyVkdu1e9/4I1DJSCt5Kw8CgYAHoHHSewblyGinAeSwTsPe\nPwDhIgGf/5n4lImwfDg7nGY2zQSn4j8WPogjisCGs7oiU0RVzRHRCKdkQqBqy9YD\nTlC1FURFoJ1ERqFAWayBrB0IxTKoN4FhYgLTyk1k6zZCNqaSB6r9IJAx7vd53xD8\ne2HtHalScKiH/vjW+XzWcQKBgEpEWsAGDEkhJT47407vfhpxsPZrDiqFFCGM3knG\nSrYx9kqD+cxaDnucTLeGYpIwKjCuUW2sGR3QRykA5++VlEM/9sfeG1LF8DlKNJs9\nbLsJadF4WPapFlZ0kW+EX9bYxvNo5xk2jyi7Nw92wN2BhMy6sYZnbef765IeoM6N\nrF6NAoGAWZxlhSq/9n0+pkMpai0hrc14Tvrh3KqgcD43r2eXW3xT92fotp4EedU8\nhF1rEekTK+YoptuPVGFUPYEN/nukkYzqjCxtYNOJGMLp23Xq3waC20qQ+GVyqGFU\nAL9xJ06dHISvyhiDsZr1Kafn3kAIa661U02N7ODr+MxvEUwq1Os=\n-----END RSA PRIVATE KEY-----\n	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAm6yc8RdHLxJhKK6IoOgZ\nH/WrNhwdrpm5BetSFqyiseM95fzEVVhM9pWD6+ECzdq29FH33ibAF3Q87oqvC48N\n9gZEz/zNtrFOgRuaj1Q/0/SGbJRSUJ21Dz/1muUoMjqZgZ0c8lMma3kT6OFOaV17\npsPZGsMG42OU77HHkazBz9K68FPfdiG357U5vxbRRi5y3xypCuJhDUTDkbCZXXUr\nhaJpQVso+Mp0p6L/IRN6CRrU9ayfkJyPRNSE/xFbzNjGEj8uaXbWez52OnYTaVa8\nlP/c+EhfyLU7+L/Ym34awsFFIH+XqohC4HcOKiqEtHOUXP/bqLtbE5qRSxgcBola\nAwIDAQAB\n-----END PUBLIC KEY-----\n	2025-10-20 15:48:47.765517	2025-10-20 15:48:47.765517				\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f		\N					0	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	{}
115407279337451464	emma	\N	-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEAyxt8OxKcEWmRre/WTnLOmq7n2bR8iAma8ZDrNvPNXrChIozA\nA4xU29c4BZzRPwhkGeGo2wae7Xb42TvuP+DQD2yC8AusLcpM/6ElxLlJ7BXhn7BJ\nye4DZkBHCJe/k2UXjjUYP/q5Y4MKHaUQfVKxMOOJ7Yi6fuxYEexBY6pslKNfD6Z4\nOwlWe3I/7TrCFO76t2hj6XkDkNgAv5ty1C9TGya7kq1G1AfXVDlt3ed27b9TkBms\nCHD7/BkBuO0B8zpnvYvpDb52KsfikPR/0BKK1F1X3F8x5N6nzxN8U+vfPluO0V+F\nFaCt/3Sxt2Nfd8kBl66jWBVUXLzdRZQIt+khbwIDAQABAoIBAADNmjIkk4wIZ2OD\nZ1dc6O/wKXhZ0WVhV3pwp0086FjCK4emROmshFDmLK7Y4/dqcx5zPjbyNTO6gfar\n/xcrfgQZmPnQwHy4aCLc9jLoCgM8/XPopVhSG+BwwOzGdnYM5TC/SwcNahfnMk1a\nwuODHF9r8RPweOqyFL6V8Hseemoq6M6/aiAFp9SaSb/bdKagf6FuZrh3It+qrV19\nMq5RhAAyuSU4q3c9R4kFfouC3zyIJLsyW/Kpm3tKmSjK52mHPjs03NOG9+Hvj1xX\n39HK1knuyMGDH0WZ4nKhSppnCk4vf7J8ZUyTTqZ7/AWx5OUkvdfNmoqKXFp+OsJI\nqp4k6YECgYEA+dWLon0fH0tSQUBtUkI5cdlyhIbNrvI+CxlB/EcLm+OcxMOxeCJx\nRCnmXHKtvb8LJWrAIC+mwVOI4nsN5coRk0x1TwtiBe8b22fMDVWnr7pXnh7hY022\naKobG3uXIHioSw2BbN03lUCfiqQHe/zBmXEFzZAADfg47kWEEk0dKIECgYEA0B64\nMF3DRj6ZQmLU3UXOY+svUzBnV1m/qqY0/ClwgY4aAtMCw7CtsQ0Il+GRtFMox8fs\nCEtkidcBpz7gfwoWysleOnhbxEFLnrRVNPXItwTU5O0YbpM8+Exoe4aSVXacrF9E\nyisu3u9pQcVIAK2svPtahYQ7XzTiEHsA1AQf0e8CgYABrWVamexzkVXkCkKxorAw\nC32xVhZbblTsTicbQn7ZdRXAXG/8ln6cLovVYw+3jmjMv4K6tJcyBRWOL7VQLaMg\nkgrXlQP7djeBqZi9Hi4aB+4+qYZp3EO1QC8eaB4Docu/dT/BM1sELYLks2U5d+D0\n3sVjM+xMK7Z2IxFX7hycAQKBgCs2tbgVP/7N8LTAIMLxQ7Grm+ACJPMWR53/dPEH\nCb1c7Dm55tELVoV011vyEncG7WjOMkxmmzGj20wG2kaGqcThmxc49pUBmdoSR77/\nafXWov4F3RTYrchA1VEQ2EG2p0GDZp0z6j+QJqLpe9HoPf3fkyQ2GL3kFSym3b0o\nPhMxAoGBAKDT3KzhrvWMr0eKLf82tctMmVx/S4PSxQv3c8VXtgtfLdGOF1JSCXS/\nScGX5KS5a2Rspa/Ja+dIfIqNK6/eAZcCf1YJLEgEbjWBoshMaqkula3He1bIWDHv\nPnzD622za4mxeNMUnB5FbCtkgLmuPs8YSE0KdD/1hbMs1NcjOSyP\n-----END RSA PRIVATE KEY-----\n	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyxt8OxKcEWmRre/WTnLO\nmq7n2bR8iAma8ZDrNvPNXrChIozAA4xU29c4BZzRPwhkGeGo2wae7Xb42TvuP+DQ\nD2yC8AusLcpM/6ElxLlJ7BXhn7BJye4DZkBHCJe/k2UXjjUYP/q5Y4MKHaUQfVKx\nMOOJ7Yi6fuxYEexBY6pslKNfD6Z4OwlWe3I/7TrCFO76t2hj6XkDkNgAv5ty1C9T\nGya7kq1G1AfXVDlt3ed27b9TkBmsCHD7/BkBuO0B8zpnvYvpDb52KsfikPR/0BKK\n1F1X3F8x5N6nzxN8U+vfPluO0V+FFaCt/3Sxt2Nfd8kBl66jWBVUXLzdRZQIt+kh\nbwIDAQAB\n-----END PUBLIC KEY-----\n	2025-10-20 15:48:51.721028	2025-10-20 15:48:51.721028				\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f		\N					0	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	{}
115407279554762986	jack	\N	-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEAs7dcfFqZ2cXLfUehtxB7aTntX6ofVJaIeIulV3EkQyxhXz4B\nEg51AUgbcqBZNdV3Xmj1/z0c2fg1gXrQvoWTNrphyCt1K1O2rHwhVpURPqzPuUvn\nibGPaUUC665UEPf/nz8sXaebJ/wB/KrhWjaRpqQfvpq/Si9A/chupOQmX+Txl6va\nTa9LErb9KgoCZHGIu0IdRMMHUz4DZMtVf0Z5lGyC0LvK7IKzt0kz9ew8vSstPvz9\nfip0FQNqw27aBHDNZ8zcQsewIJRlTt+RBztfwvN1wa5W5Xr+EEU4rY3arPMSxv6h\nH5ORZz+PMosMvzwb4K57UY09MrccaXf42NI8UwIDAQABAoIBABhPSEpl8wO7NrBm\nnSBnMVplhI95Mq29gw5TTXVLj60qdq1sdLadkAQxXc0elZKrom754bS57oopggtW\nsp/i76vqgEmUX1ASDda9H8FXfrKsq5iUBOjiRNTnieKZfTOiaEiBQh4VCu7Yrugf\nsUYDtaYF82lUA2YkiDUMBLN3TR2RX0ZcX9co8NIKOsUQD4VXTGy6azB0x/ZHpuw+\nRDp+0cjXlQd8/eVAFfK2QivQWh7Lz9j9qWJKrwTniPEISlsQcK38FfSEd3AjRf9D\n0oZTXclzbAQVfGGQOuOn6DvL/12i2LyqOfV/001AO5oSjkX3HFsdva2Cdz3IF6Hr\n/VLixvkCgYEA6QVzlAZD4mA2lBDI+3ZTliRSxEEH56BWNPEf1Uv1s+FOWB7EScSF\nqPn3UrxPI6eeuXab6hdpEhTqk7xjoQKit/62suWlUO5WGM/O7UMUYqjM0NsUnK2S\n5qCvQgzgFOf43H3Ztu1z7L9ghRy/iaGipx1IZpUxcSYYAjY6ArdxKwcCgYEAxXA9\nspzCXCo6CpLkMpTci+3NpmGc5+BtgQFPIvYmv0xyhaD1EVXJ86SuaDJodLzH5IbP\n9HmNgniAKyGw8KiM20SBYsiw8SBRlc0RkeL/Kcf1kU6hzLo+E3Q9sA8vzcAP42vM\nYw53St+Awh0Cg5dsSEGet0fVUjyFElhU8ODVtVUCgYB189J7fWhjcLxv2sdBsrXA\n7IYQ3bI4p0q75cptV9P5x/S2WmyVwqq9zDpLYRLWQ4Tu8IEfz9XZ10iem9/6orDn\nXkHw8JnsC5j9WkOuiiQJhNSYbC1U2e/gWjocvxO2wW2Rfwrzs+LYVk9vUgwKiQ0i\ndootkxvB4LyKchSPR3g7hQKBgQCzmcaGE9M5w6/Irpam7IMzRr8r+t+gjqcOEwLJ\n6uCUZBZJOIG1ozRyTfvZDQG4L4Imf/vriCcR6Euu8JbkVG7NhyOrmKRcs+mDO2gg\nLT2v5BWeeMj2UvTk/XigDzCNGYlad1UVRrN9iJK4AWuoCLaXhBm837tNc4AZkAC0\nndHJgQKBgDiFlrASns9axMgpxbWkZuHVm8sBwq1S22VloAQfe27T94HlDokTkWlb\nL3FXf2B2uuyI6kHPxTaQDuV+qfes9gZuxX5UKTlx9Xri4htISGxaeNrivbbsacK6\nvuVGYQU8bQBC2fLFV4ZoWOTWf+arX0keCixEZAoXhDXdEZKGW8kG\n-----END RSA PRIVATE KEY-----\n	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAs7dcfFqZ2cXLfUehtxB7\naTntX6ofVJaIeIulV3EkQyxhXz4BEg51AUgbcqBZNdV3Xmj1/z0c2fg1gXrQvoWT\nNrphyCt1K1O2rHwhVpURPqzPuUvnibGPaUUC665UEPf/nz8sXaebJ/wB/KrhWjaR\npqQfvpq/Si9A/chupOQmX+Txl6vaTa9LErb9KgoCZHGIu0IdRMMHUz4DZMtVf0Z5\nlGyC0LvK7IKzt0kz9ew8vSstPvz9fip0FQNqw27aBHDNZ8zcQsewIJRlTt+RBztf\nwvN1wa5W5Xr+EEU4rY3arPMSxv6hH5ORZz+PMosMvzwb4K57UY09MrccaXf42NI8\nUwIDAQAB\n-----END PUBLIC KEY-----\n	2025-10-20 15:48:55.036587	2025-10-20 15:48:55.036587				\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f		\N					0	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	{}
115407279720254077	rainbow123	\N	-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEAjx/jkHq1ONI9MTiWKK81Hjt7pTgTWY6mGqsWvi5RZQQIhwu+\nlNWg3IGcaQKtz2vCsWc3g3QHNPKYOILc+yA1baUUkWAmuEmLxsu9Fyx+lVle1d18\nm2wJAffUQrFhFcWKsSDAoIrpVC++Vqtj/mldb04eYr6k4zLx/EQRho1oG+p9ku3b\n3cOn2sB22ntAk0UAd4WirJ3da4D+jTH+R6qVosqVrcoTeyXTDIJttkfqpKkNLdAl\n7WKmWmGgA8FhCIlc8EMupLTYJlJcC6VkzMwMRAOwuwhXaNmInhQMwxzlKnwE44mG\nLFmvKWuJg8M9jCyxYXjlET+Kl6tB9ze1TaiOMQIDAQABAoIBABWZFJRmLAhD06ek\nmCZSEEQ8ajN7w5HBcMf39wHih/ZkNiw45bzcgv6bkYCYPqXdJ19xicNMxFSlYjqu\n5s1/pghif7jTZ2xqbs0kTCfd10lO1/yShJ4IntBc93tL/LBWI9CIdoETjVPes4yt\nJvUKreagxX2Vsti1RKaSmAlzt9j0X1AOQm7hFqWBDdlx4tzt5ZUVodaA/m8ntdH/\nMosv5aXVyeozcNJ85yDNcrcj1sdp+WYDjszrIJ0IftLfKTJe3nNbho+F62KLrNpk\njwYvipeko3oAC7r8zKjoNovLgpeB8ucqVaw1lz8LC9xQ0u0KQe4W50XTXRrbOzpW\n7Nzq3wUCgYEAwyZVGRQFE/9RH3U9XJmCW2viLXzaA9Zmr2LpY0ve6/Jis8NnwfXN\niOkwTCSFxHQ36UMadzIiAmWkuoU5bVlnsZMUga+CfpBdukeQ1nJx6tws+ZKXvqDD\nb22WoFZl8lshaJJ42k1sX2LI09gsrwtNoOurwWkx43Lmq0NSx58Oo+0CgYEAu8Cw\no/R5ZEit03bTJOhM5fQcD039lsFlOOEDutUCAcwDooXDy7VN/0Wpi62BkTZX/1xK\nGED8GFoaK/OFPRZ4g1U10nU+6B/iYqSFljWUhvZP+PLUo0pJ/qob911AzdUN3N2J\n+Xezw1nHq4Ux/6U99f1mVssoJ6VbmhKL8ttRktUCgYBu0jjnOfA8T/RgmfKTwHU/\nt39E967TGRFNLi19fxuEACy/CwvEIPNseYg85Uy1qI4LwFiqMeUQWWp3papcB7aU\nKAMwNlwzxYYEgBmnPmykxA4iWHYmAiOaBrDQMuBIBiptuSg6SFdvv6hubUfKy+90\noAD0n+l90cVeoqfCxvfIbQKBgB7ASq4v5ooEVWQjPCX5Xk7zknz3Oyer+VY9lIzP\nQorkzVubKRx+T44V7NURz/zmt7b9eK1MR339k/fK5PHCcm6gUDZuOaVvQ3cAl1io\n4fDQ+vw9WZJ9Im1xky8KuQh9cs3QAz822dyPIeL3596FRAa8QDzK/YKw1LYBf6aB\nQXUZAoGBAKeyO4RqdYDbevxF2zcpEKpfDhwnP2b6OptKxO3Eu2ghlYj1aGDStsXE\nRjAa+1JmsUEkE8m48IO7UT3xdxITUnuD1FMvdAo6oZznLzZbphMgsg11dOUjUZ25\nHMDLArzrHaOpmH4O3QIHFhu0DAVtfZ/KmIhKaxaLleFME+OyxAk8\n-----END RSA PRIVATE KEY-----\n	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjx/jkHq1ONI9MTiWKK81\nHjt7pTgTWY6mGqsWvi5RZQQIhwu+lNWg3IGcaQKtz2vCsWc3g3QHNPKYOILc+yA1\nbaUUkWAmuEmLxsu9Fyx+lVle1d18m2wJAffUQrFhFcWKsSDAoIrpVC++Vqtj/mld\nb04eYr6k4zLx/EQRho1oG+p9ku3b3cOn2sB22ntAk0UAd4WirJ3da4D+jTH+R6qV\nosqVrcoTeyXTDIJttkfqpKkNLdAl7WKmWmGgA8FhCIlc8EMupLTYJlJcC6VkzMwM\nRAOwuwhXaNmInhQMwxzlKnwE44mGLFmvKWuJg8M9jCyxYXjlET+Kl6tB9ze1TaiO\nMQIDAQAB\n-----END PUBLIC KEY-----\n	2025-10-20 15:48:57.558535	2025-10-20 15:48:57.558535				\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f		\N					0	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	{}
115338428522805842	test	\N	-----BEGIN RSA PRIVATE KEY-----\nMIIEogIBAAKCAQEArj12J1Z9FDN2OtzHpSKek7FFTRg7LEARzztvsZ99v9nLI2fh\nMrL+No53FHt6bxaysTYp5EGiDpF3NHJGGfAtBvvtWcomu9t8nalWjfAnZuxpD5r/\nEJRmXvC/wykag/uIHJ33m5KAby0ysvoj6HH8+1A6rStemyjOa5hFhSFst+ip5NWq\n9nl82HLMlYBbyjBT7fVbrq5LR7gsWsxcZE5UGHGf7o+QxEinGHpXyOKiXBA8PU4a\nYqhR0YF/lxtinturFOJIUOVGXn9wxGzEqHEWSMTRPVC2DHy7imvE/2JCKM8jcmUK\n2UewyU8vN0I9DRjOCilRWv4D7az4FPyUE7CpzwIDAQABAoIBAAFyQSjSbvdb9f9H\nFeEpCGfxcMHTEaqsXXl65NJ0oHaXODhzBEuHcNTDGfnxjHKfnZwa9v4ODWpRisvE\npxBQDg+gx7eXFfs5Ny+X2EAVXj5ceALJJpTcpnzjQrQ8AxxVWivio8uGy8ogdetG\naEXlrFPptpL5aS+ghxYdjXYtcNmV8VEsVm7Oe6U2Ib/jSfq+0OD3eBK5/juWunKX\nuX7XL3C+HCQEnUtb3PUsulK2nWzpm7aIM/TPS8TyA0EmCZk4XPMnZCi4MTGGMtlF\nmjBFPRdA9CZh5HOEVA8KB+iqWt1Y5/xHzkPS9Ta5+CUM/uCrAe5ergpe/g4RVrLb\nUeUDFwECgYEA2M9XP6wlrQDBl1PwHyCnJeyDX8OatH18NLlNymQnTuFa4cMyk0v/\nL7QNaU8L7FwkqgQv6xf5WBjlZsksPN3jQ3R3d8N6FGd9eg0LzFoPIOe3TQYHFN4T\niYA34KUE/78xQ4kLG/hlTWI/TzX9JmLAS444AUIZlc11SJpuPRLDeq0CgYEAzbw+\nmsB8Ed5io11PW7R0ppQa6A/AUGYEa7cPeFKn1E7Ucd+2ube+BfZ0soDtO95+Ga++\n5WdFSox6Htiey8AMFumrI1Lmh77SurruZnvUJDTL6izqLbHPCs7dzH7yL7qqbIeR\nNLMh5l/qwlk0LlpmWGyYpjDgdwnqJfmbKavB4esCgYAyqyIky0Jyz/5uMzumyqbF\ngiShuMDq9XiVicjYR9e344qtwESNj/EvYNDRj5ulvVMEOL5KHuwy3n6eKt2fy+tU\n1F8nKhPZuOXmJC5hr5phgkWgRoxZIB1IwSJN6cLlUfVdZyWlf8OM9iz9ggyLcACo\np7AG+z+ndsC2GwEwXLY6cQKBgH4NamYyrVHdaZ4iW68aX6Z4dAvfKruX5fmBTc8x\nBXdFXVDv+urLM3g/yrxb1f6qkaR3U4UGwyOr8l7X5mN8JWwceyjHcEuXlVGnms3b\n7NzKJG40Wr7ohKxglvDmjsjDnAum/EbHwmt+NT4inaAQ70gaMWUR6VXGE1p1FqZv\nf/lFAoGAWjMXrChb5TzHviu48Vxnkl2dEPRCwuOLg714AL0W94Od6qtL8sEzpQDc\n9k1SAffsf1oTPNFwj/V2Ec5On0GX5ieHqvmgY+qkeduWa4pKaCc2oqd07hQv3P+J\nv0f+2srmlwP8KjelCSwIsnnG19VQIhH7YmJMWUTx0R6BTzwYLZg=\n-----END RSA PRIVATE KEY-----\n	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArj12J1Z9FDN2OtzHpSKe\nk7FFTRg7LEARzztvsZ99v9nLI2fhMrL+No53FHt6bxaysTYp5EGiDpF3NHJGGfAt\nBvvtWcomu9t8nalWjfAnZuxpD5r/EJRmXvC/wykag/uIHJ33m5KAby0ysvoj6HH8\n+1A6rStemyjOa5hFhSFst+ip5NWq9nl82HLMlYBbyjBT7fVbrq5LR7gsWsxcZE5U\nGHGf7o+QxEinGHpXyOKiXBA8PU4aYqhR0YF/lxtinturFOJIUOVGXn9wxGzEqHEW\nSMTRPVC2DHy7imvE/2JCKM8jcmUK2UewyU8vN0I9DRjOCilRWv4D7az4FPyUE7Cp\nzwIDAQAB\n-----END PUBLIC KEY-----\n	2025-10-08 11:59:11.660453	2025-10-21 07:00:25.487622	This is MobileWorld test account!	TEST		\N	90706f1fe83887cd.jpg	image/jpeg	11183	2025-10-16 12:32:03.828884	055f1a0a8e88da1c.jpeg	image/jpeg	4829	2025-10-21 07:00:25.466439	\N	f		\N					0	f	\N	\N	[{"name": "student", "value": "Open University"}]	Person	t	\N	\N	\N	\N	1	1	\N	\N	\N	\N	\N	t	{}
115410778295457737	pupper	\N	-----BEGIN RSA PRIVATE KEY-----\nMIIEogIBAAKCAQEA7VQ2FeUMDmAB0eUApdQjzEok+EmimWgBby571eZ5XqCetmiW\nNBLhL80Ex8GD1W6WebKyj+RoTeFC6JBBSORuy874d2IM8XOorM0T11oLSqJh07y6\nMGe0jXvmhlr1kgO8f08LZwfkZ/Gc2ku8aVJz2EjKY74thyiDzkCeNCCgcHmgtSob\nKKEZlyiWflIPCQqiZkcA1CSOA4xE2Cu56h1rrEfQqlEtRiwPh9mjr5cS2ZTsVrRR\nNBh/ESKXNr4WFkQdpvwQi5VNGqWSOq3N3ctaiMkn0uKeshCkX+incV9M2UWpMibw\n0EHvvWhYEDkvxHVCiuStgZegiXrJYZi1Hv9UfwIDAQABAoIBAF96p5+7XFRUL6c/\n2Dje1eAUXDc/eJj7DMisDMoLRPza5b9A6Fze05Wlh6zNn7o4GXWwfMIDBCuA2qgx\nkPJAZIq+I5vz6H0jKNMMVlUnNq+6EF1c6hMbRbo+BIo9AdrSgf090bqLpEplG9N+\n8Lf2ogB7mGD0W+CqXgyWVo9mKOXWYmlsSy/HygiP0fa/wsOGnute6N3jvpRJMi9s\nO71W+2+v0WUU/v1lIHqCqDQCgcvjAP20R83cw+uHqwEjaVIEXEugQzmInmCfgkmc\nEUrkqw72TVkfDn6S04jxqFGMc32JQqIFYImv+FpTochwUzi2cnkA8OA6DpuAjPcU\n8c6Kj8ECgYEA/5CENTMw3Nz0934Xz9vQwtO8KOUuOrWDCi/zg1qTOsvnMm7nneou\nC3WLURHrojVnpuVtWybhIV9iXBvTgWZirJ2ZG0B+3j5Th6HGXfPtQ0WnqLvxyisI\nWoQa76x/9Vtzk/kqQb7xtgeVnyBJH1+CRgYrW19+N2ahu6WyVQnVY+8CgYEA7bu9\ncpIU5G0NNI9i/hJlImmb3yFPQnfi1VKxyKxK0cGHJ3n59WbxguZyamXLYtSjhi2q\n4Fv5WA9arxsqLGS2hcuv6D7p2Rbyh7jdO8OrvO3KcDNspi2TbJnxPgUaU5Go1d2U\n+zLxK1ZcF0sR4C+5nH9A4rwaFQ5tY/Uq0Yh9SHECgYBblrA63KizTqCgHdlszcto\nNzektFW4Bpr6yKqNtaU0GiU2RtbNGkL8KlkOacy3qkoGXwys8ScXrbZzaimHo2jT\nkftv79JH1bBb2FdeDnBGfq0SZKDHolpxDg0VPg3xoZ+vNUm2nDbF1LwDdi+ehb0L\nWWSqb3OtaSOnOz/JCCgokwKBgFvFdH2M3NnNKyLWEz3HNhlRsWUyQ5mCFCOLV6wC\nrqNIVPctRAuyoJqKgTKHdzsAoNuEN4mCl7+htb0Q/HfErRz7Iz3BQ56VGCzCdUzD\n3UECfnpPr6p6v4VV6+WoLKCEAywD7KYH5Ud4f/ZR+WWUps895HtiZ6MnPZ0voEbg\nrJRRAoGAcIYMjhGTgglZoD0o9xdjhRmogEcI7HSg+VpQP1pMq0Omm/M4Sy1zBdw5\nKLps8tVy6KPuJT9kCOtmtUvQL+T8j2/J+YFnPYFfecuAWaF99AwmCD5oj7bDEBzc\nOGCGtuK3TP1H0s5nN4OOA7znZNsh91TQ01L2kp40ON3ICirXyzE=\n-----END RSA PRIVATE KEY-----\n	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA7VQ2FeUMDmAB0eUApdQj\nzEok+EmimWgBby571eZ5XqCetmiWNBLhL80Ex8GD1W6WebKyj+RoTeFC6JBBSORu\ny874d2IM8XOorM0T11oLSqJh07y6MGe0jXvmhlr1kgO8f08LZwfkZ/Gc2ku8aVJz\n2EjKY74thyiDzkCeNCCgcHmgtSobKKEZlyiWflIPCQqiZkcA1CSOA4xE2Cu56h1r\nrEfQqlEtRiwPh9mjr5cS2ZTsVrRRNBh/ESKXNr4WFkQdpvwQi5VNGqWSOq3N3cta\niMkn0uKeshCkX+incV9M2UWpMibw0EHvvWhYEDkvxHVCiuStgZegiXrJYZi1Hv9U\nfwIDAQAB\n-----END PUBLIC KEY-----\n	2025-10-21 06:38:41.598428	2025-10-21 06:54:50.747614	We love puppies~	pupper		\N	52ad84bb4baa30cb.jpg	image/jpeg	35835	2025-10-21 06:45:59.758176	df87f7a04a7b3213.jpeg	image/jpeg	12786	2025-10-21 06:54:50.719334	\N	f		\N					0	f	\N	\N	[]	Person	\N	\N	\N	\N	\N	1	1	\N	\N	\N	\N	\N	f	{}
115445893227871976	alice	\N	-----BEGIN RSA PRIVATE KEY-----\nMIIEogIBAAKCAQEAtN4wNqD6SfQnoTAUkl4WPzHmmd1NXTH2jw8noK6He/vxYVek\nfsTNHlGAK2ZcIGJbe8+IsktRO9jY38AdINngVfGRyOEj0RF/1KbEb1fdyfziv1rs\nSeycFQL0+iVjCPSk7n7tJ9xiaqJZ/EG26FrtH//Qq1jJu/ZoYiLjU50X7sJw/jIa\nU7VnBgqjUcCZPK5cxVvIA6zkt5fcM1e+z41gw+qFAxgwTtxVKf8Uz+11+nTJCBAr\nLvGW+QtARotZ8MmUDlswk6/AUhRMLP9cjd5jc1tRckBjslkReijdjKm8+S1cR+54\n8lOj7NpXWYLrp502POtSq9Llt6wxC4zrFZl7jQIDAQABAoIBAAOPfC0XIV7BMUio\nXnKBDPzuSb+UEH4VtKRQlWR06Pbw7jZ1azkrGuUBoXTS3FxaCsuH02u76F4CkgJi\nZlKHO76GcUjI7lwadScWyeHUCpTiBQXChx7vj1hcrXka5GAz9PgHnga/p+Wn5Q+6\nNQvWddwEeGJWENoOqu9hf1+ZvOKbIVPHpZuYXR/TGeJpE3EU/8hxycHQMYEDP44b\n56ySqRCW3y1rsnsmeSjOlEnJBc21+CR9DDaiXn17+XGclKxmrWTWQ94fKabCMMcQ\npadlC2zYvNy4JlYWZLCOk38bc9E2/AG619dn/F8y06xQtHFNfz2wpb6seZDV8PtM\nsIAFdWECgYEA6phSh9XDTD5iTFSlr0H2LGWnV+uz5qFHGUHNeD97xFk8gSHgZyxP\n/O2f5CQpt5iZqYt2Erxi9uhD0pSvRRwlDGWKM+wzz5zGc7x976Q+RTk3cF4ePHCv\nm3pro0n8i5bMzXlbnU6V7vryYgW0pgJa+J4wGfBeWi3WTWyZgtbthZ8CgYEAxV7o\nL77MSWm+HnDS2O+gNLDhnP3Da3yOPcDOqFwRIJZLN5/8b2i8K7gII+YvxUz/9D6C\nQCS8mK/GKNsaA5js4M+QgM+FZ2/28jlnTULwTlJKKuwxogzeCTQchA89mR93cGXs\n7IyZSvXf+wAtynxXZ4fk+jddG//Tn6TqgSHeN1MCgYAXivvVV/WGhEg3ItOR2AvN\nftIhd60ROyQ4e6sUI0LXfKEe0HiFwiOw3WQLcDmjjDP3mOBblv5TixGrY3KHfACX\n0uTguxakAjbETKlS0GfTaJ+QrlFYfXKSJuIAfB9VHugkwsYX7lgLqLGEdtAfTOM2\nSiHHqKC/ahQ0pu5s/AbQPwKBgDd1Xoqj8yUhuFE3ZJeeZYbIuOxzBak7O4Cwn6EB\nFbLxaDs+EiF/7XffYzIrKPsokrcfpVu+ttu0cFrkjd+65byZtkHrjdGtzVbsuFEm\nYP2w87Qx4BRnxzAQ235kBevzwozrpvIk46IDiqcturAt1iV6MuX4DoqijOVL4rTc\nPmOPAoGARBzhFuZXpjScskHxkD70+ecELVwBw/tsxGru/uMPvczVkfqRC/+B9KRr\nVgSUQaQD3llbA7/5xZvRbu0r04dM0Otw1Nq2EKYvb9/oE7nwhT/RZ6PEvBcEAwEv\nCv8nX0YHenLjuNAJotp2MF8ILT9Ur6/iasGYQvEf5PyAjqVHh4I=\n-----END RSA PRIVATE KEY-----\n	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtN4wNqD6SfQnoTAUkl4W\nPzHmmd1NXTH2jw8noK6He/vxYVekfsTNHlGAK2ZcIGJbe8+IsktRO9jY38AdINng\nVfGRyOEj0RF/1KbEb1fdyfziv1rsSeycFQL0+iVjCPSk7n7tJ9xiaqJZ/EG26Frt\nH//Qq1jJu/ZoYiLjU50X7sJw/jIaU7VnBgqjUcCZPK5cxVvIA6zkt5fcM1e+z41g\nw+qFAxgwTtxVKf8Uz+11+nTJCBArLvGW+QtARotZ8MmUDlswk6/AUhRMLP9cjd5j\nc1tRckBjslkReijdjKm8+S1cR+548lOj7NpXWYLrp502POtSq9Llt6wxC4zrFZl7\njQIDAQAB\n-----END PUBLIC KEY-----\n	2025-10-27 11:28:52.924006	2025-10-11 04:02:14.199903		alice		\N	6a4cc84faea5be85.jpg	image/jpeg	9533	2025-10-11 04:02:13.512687	\N	\N	\N	\N	\N	f		\N					0	f	\N	\N	[]	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	f	{}
115347680385540244	olivia	\N	-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKCAQEArEBrY3qKmhfF0fHOYRHzlostty1WBfy4JqKfS4fVKoourkKp\nt+qH/DDFQySWAaF9PkAcmaUE5mpPTJWUAOxmT1gaUuNi3DoruTtVUvCucF9wgvbJ\ngmNM8Dt5xQ3uKNhArAmKZgUV6iPDdLrMe8pKaxDdhQz3C4xxsd+gPCTHnXuTa4GD\nP13RVi8b1ncBldlyeVDPn+6nC3aekwDdnqCGiiAomOnXP4LzKHDFToblsU5TKCqz\nXCbEXI0DgZKkez4GtTuuLBJBlQJL95fsOg11ymIwe8DCQCx6MzQ384lsoqjzu4M/\ndqLVTg9a9e4t3lZALinZ+2keupVtVNHmjqqM3QIDAQABAoIBACV3caRWsDUqPJYY\n4YoNrI0vQsdYLiDpQmjs8HcuWXiCS/sNdvsRIXkCZrXfDF3YcXSL32ywDyvLLep7\nkpDM2sghYsBqw0MhyAbnV/zNazP4HnHuGhCpZr/OQANTr1zlBNQm0xqzunuOQeJv\nCzFV4+/74CMjmczCRKyq9qB+Y4jmT91Tm1ly3NgZU4J18/aYGjHs90PtEw5nDZw+\nPO36JE/DMqkitEwSibMieDeA7qgLv85mLZy9kD9CKTCDzr6w/3pHgLKx5mzu+ZVs\n0b5OC8hSHCAnqXH2IneaKLpnWyzpjXiNDtu0A2ggkimGiUjq0iGU6tuzGqLwpADL\nAtM6I+ECgYEA15UXK3FX2AsNIQkAIEeqUsb/RHU6kKoSzgCzwm5C2QxMRAVK4rk3\nmwpcjzwBcvr60b279TlQWdPxe1FIXOb3DzZ2EURndTk6sLNDzQrAZBqXxUfiddyK\nJpWtng2+b3jSrkEC4Q+XQ4YJfaY3Spi5aK+rohkzn7kZ7qBf4btKulUCgYEAzIup\nx1OmSPn+H5XtlDMC8w0K5BmMAQ4T89rWuE4RdMeqE9+msAQ5GjO75wTevEVlKVgU\nRFw2ULr0xzqrl7gy9TWgeZOp/OvtIXbkj1WFUFsLwxryE/hSK22+oEfhn9PkWBTv\nnXEIUSVRe6aV608qLNgbCv51YwaGF29gViNToGkCgYEAuur67uDUUG6skIMUR+i7\nRhBiTgHyqHG94j17ns4pSbW+/o80McZz7wqZ3FsjyoTQKkD/Eg0CnRAF5W1Bd8OO\nXPNUhX4w0dOwDnswAz0aOPFRvGyqbpSsd+35Xfv+rPoueYXGsErrVVGHMxmGATjQ\nMXN3NhHxz8AXOu50k+znSw0CgYEAq843mdQaHLvWhqNA/bTnKk1vM2592TkA61eJ\n+R6hrOw0YCL/+GJjsC16C65cg9jqApMX2t91Q9P03A7cqEAwlSQpGVU9d9KWx//8\nNKSJqJgAxi0w3jM6mX3BmxElY0DwUEetiBmz+ayVx32B+TbyXt5ZwJ9A7B9DrBWB\n3ngnutkCgYAe0RQXf7wQRH0q+rodLC5bEbvDfyaVevmrIXWJQxeNsGIwDkQwyTLH\nQ3RNB+UlouXe+6riKpCX1OlbPXqp8H4taBzwPbMvf7JQNtnlabCtTtlLGnFE/mJ0\nPCYJ24qA+PqZ/B4mSLy3DC0L3yp9qZ4+eaEZuWTHFrBQ9zuqwkCA1g==\n-----END RSA PRIVATE KEY-----\n	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArEBrY3qKmhfF0fHOYRHz\nlostty1WBfy4JqKfS4fVKoourkKpt+qH/DDFQySWAaF9PkAcmaUE5mpPTJWUAOxm\nT1gaUuNi3DoruTtVUvCucF9wgvbJgmNM8Dt5xQ3uKNhArAmKZgUV6iPDdLrMe8pK\naxDdhQz3C4xxsd+gPCTHnXuTa4GDP13RVi8b1ncBldlyeVDPn+6nC3aekwDdnqCG\niiAomOnXP4LzKHDFToblsU5TKCqzXCbEXI0DgZKkez4GtTuuLBJBlQJL95fsOg11\nymIwe8DCQCx6MzQ384lsoqjzu4M/dqLVTg9a9e4t3lZALinZ+2keupVtVNHmjqqM\n3QIDAQAB\n-----END PUBLIC KEY-----\n	2025-10-10 03:12:03.878887	2025-10-03 03:07:17.566395		olivia		\N	0284af8f1fbe414e.jpg	image/jpeg	16778	2025-10-03 03:07:17.42971	\N	\N	\N	\N	\N	f		\N					0	f	\N	\N	[]	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	f	{}
115347680582977591	kitty	\N	-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEAs1MshtKyBq5C0tF32NvMxp6TqCY2Lp+Ti2x0a0zqQfOL8rA8\n2XbEBXu7ud1a2EXAM75Qdvlk+15DS4wMrGH8nKBcGmcgSQ23URy/wjoo+Mifi/CY\nSJaFhN/JuEnUuh18Gm8DszKp6eWiNj/kPwhHvD/xk8mtCl6irHByDWmANF+aDuuD\ncEZPriGWIgivFJ0dOBa66MrHU7rfBp++wCqauOOHl6q1X36K4CRz+Wmg2OReswZx\noY1CgDCt19nJN7AcEBIBA6NLbile1qnm54suKUCORY3wjrNn7trhhYaxmpv6Lxd6\nOMH3xTS1WgPqXtn0Sg5ZxwTo3HIBAWkWfP3dJwIDAQABAoIBAFfJaOvbq2FP39C6\n0LPt7lJxgRF5G185qY5AmsGIlsmQg7tcAX3oAVA54Y28ymNDyjLKgTOtJX1VCRar\nyex9z5+RdWVLhOeeelaP/2QC+tnHxStJrhMi9Nw2fdbk9eni00VRgXsxWzLwwrdS\nEde1owCKQSY7PaXs7DAEoCDmu+dm8AT2jIEESzjGmyOiYbcGudElHdnvcgWYXf/j\nRG3fyPiOVpubeGh7JPl9BHqeJHXxNCceVfF606dxvNeK39+OoQrFjD3EbMeqkwWi\nYPNR2Py4huu+jYJr6m+krSMwZj1aIMAGDEt2SjSLg8DhfUz6XZ8aPTweyOVfi+D3\nSy85/6ECgYEA2Q0rAYScEOlAjKIFgvnSajKdPuWX1ZoJxqBvCoNXyxFH//a1oy0t\nyTxE//oeJkUJIVYq5AE6r+GQocsHJMct0eXLbROXugSt5SYeWbPhhu9vHOpXoCTY\nygeALMOainyeFTykagt6F8GI/CE1QLTGM0yNAhrq1nDWi79IP4JU7dECgYEA04Dw\nAzZy2+OTqZhKDLX4QyslNwwFkPfOu9I+bQmBwjT1XAe+/sZ6jmyFP1IffwuYtR8c\nIRXT3kkDGZCWWvqD1TmpvpvFO+vKHSboK7BrtRr1Q8a+1oWYON+QzK43oCg+A+O8\nu8qq+QHAASj/kw4l9TYIIE0PaVZvRELkljsdgXcCgYBl37BXvg4iQdhyKXm8x9Ti\n027KnqhtMSd1esejf5ItVacdlIYcWJAs64TXQGX2QGDQrMjky07oTk68IbbwpCv1\nYI3iXFfSj2+vJf0IzU0FMExOng8SszitWmfmmshmR6dLAHOK8mgTzlqlPFDqVe7R\nFRT57/hZPgz0+orGhD2ogQKBgEDC0zr4mhTQSy97zPi1Y04V0PBZAv9PkYKbLrgu\nWAgCNTq3uHjEh1RC0E4CNFivUVPsMa3DxDrk+kkCp7c1y9YnMN2HTs45NYrVlfOC\nsogiuATHvzlqcKDBe9HganHkwJBqVCjgNpfGPGdeiVsa0u6RW82gKt7jM3CgVuPV\nOASjAoGBAKto155IOlt96sireZrkYGwwPkpu4p4oa+a9m7uqPNAhZ5JEa/e5Hf1w\nUhSLXhTBji9RqMCo9XDPrfevXqyQCGeHMIIotznSJ9qf2gcvAVgAXLobZIUOZyNo\nKDwvPPyY1drBRAe5dqqjhDj1vZfXxLA00/XdmC5p3AwROFjhSK4U\n-----END RSA PRIVATE KEY-----\n	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAs1MshtKyBq5C0tF32NvM\nxp6TqCY2Lp+Ti2x0a0zqQfOL8rA82XbEBXu7ud1a2EXAM75Qdvlk+15DS4wMrGH8\nnKBcGmcgSQ23URy/wjoo+Mifi/CYSJaFhN/JuEnUuh18Gm8DszKp6eWiNj/kPwhH\nvD/xk8mtCl6irHByDWmANF+aDuuDcEZPriGWIgivFJ0dOBa66MrHU7rfBp++wCqa\nuOOHl6q1X36K4CRz+Wmg2OReswZxoY1CgDCt19nJN7AcEBIBA6NLbile1qnm54su\nKUCORY3wjrNn7trhhYaxmpv6Lxd6OMH3xTS1WgPqXtn0Sg5ZxwTo3HIBAWkWfP3d\nJwIDAQAB\n-----END PUBLIC KEY-----\n	2025-10-10 03:12:06.892225	2025-10-03 03:12:44.06883	We love cute cats!	kitty		\N	90d082d33d14d7ec.jpg	image/jpeg	17954	2025-10-03 03:12:44.031631	\N	\N	\N	\N	\N	f		\N					0	f	\N	\N	[]	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	f	{}
115347680754305497	gourmet	\N	-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEA3G9P+LcaZlpm++j9QEBbJu5GVWmDaKnri29NuakM8TF1lfGK\ndeG7QFZXLX5Zx7Z1e3ZBK55WTHfmPPbAKb4i2PIf30/uBQjK//AI5kJQZp/PcEWH\n+71OscuPsZqhmV952KjGJo/1xrTkMRAJXfMfXdIwYiS03Mak7T26z49KNDyRspbi\ngCzuJn6rT/VG4rplQqK3GzV4nVV0R75plBymVqQQax6x2jrKaevb5dA+HF2cYCtT\nhlfQro5/1D+kYhEtlnI8BVZUbTQSFHzwBElYhsgxXa3+yAYQB9tdoXzb9k+8X7si\nlqRjEljhcAFoSIkCrEsJXete9rsUfq9q8V3v8wIDAQABAoIBAGJTYJevjR4UuxUo\n4zYyvrYJ2OOmchBQoxmKJ2BmcLhxeGLO4BUfAHh9StunHYMA9zyADifXs+TeIpwU\n8Lht8HtW3TKuI5ypRGuPdVjIQbbVGCGbUkHPOngCNfFh6S1RsjcbaW+wDVB6RcNA\nxPzcQqSF6kEM4IQOM2kDfP2yi8XqXkuomPlfhSWj6ozwxbD5jiwL1hkfzsagEC/+\ny6XXXBWOJJv02e5Rfn94gYPkmehH9QZ0hTRZ9QvEcm6+yenZ0nljw6MIo640iOWB\nnr/SkknxeuZe6YNvQWC+mBWjvTefaQ0M4RGJtPmayvx6w8UAXOJqmbdLQUoFTRgn\npyFem6kCgYEA+1hHs4wCuHkvxrO6J5+lUjzir0yih2a1InsFuWKzUtf7YPrq7zWE\nVAw2Iu7GjtxDAaviIy5zUKV/2+evRaXxzxFBki9POEuTsWh77BQYLKxJr4oH7Phb\nzgLYADZiuhK2Uap7pfGNzHWLWdj4QLu20yTMwjQ2QnJHANF3DEkdNR8CgYEA4IR5\n7j8zg5jt92MUFeuYcK86iLjvisJAvG1a+vTmIEQG/Y1H6WSEv8uzWXSHIjLj9N+w\n0Oq9uDugN/1VBD2nKiixta12PdkY5Mh13pxvZjCLcWQH3w0gFEoSqBJZYNmwejsD\n5tTTankuNEnytSFVbCYS2hez7s1g4UiX1qqDtq0CgYEA5Ts3caZBGPPVwfhK0DaG\n9cD30X8oQCtJCiB/MPu2pti6uFFAEViSzoCwox14U/TI2+5ieUm0/Blkyi+8p93X\n8s0/K08ghixPkB7F3qLZBW1AauuNnO9J81Keo1r2odPNGiBNUyRB+fY+WHxMteU9\nscY/ROOPlPxai4F+fOL102sCgYAsrfBd2zHzNFHW816h5hqWAikR4Eu7P2EGnnSG\nkInjTeZeOulepuRMDsuIN8pUoe//YSycxroumZ8OxVlP2L0VhLeowfZP5I4xqTrb\nrCH3Ih392LxARSpnHz6LN+uVfHzENk5Wd3ADNk5dlYG5TgLj3MfPovvpv/FRo9Kj\no5dGmQKBgH94jx+Y1liLOy0PKqFmLairb31W4PKRSw2mDw6BsddzBqNNtWgS7pAA\n0JFXbYf1AL59hVfgBvfbPyLcrJg1GZHpJzP/krv7AiQ+QWHKKmAcjmT78qtKAXe2\n9MFK5YJWjl5Odj1lPIsy3kmzeN9Ku4I8gNsumM1rjH7PfJ3Ll+dr\n-----END RSA PRIVATE KEY-----\n	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA3G9P+LcaZlpm++j9QEBb\nJu5GVWmDaKnri29NuakM8TF1lfGKdeG7QFZXLX5Zx7Z1e3ZBK55WTHfmPPbAKb4i\n2PIf30/uBQjK//AI5kJQZp/PcEWH+71OscuPsZqhmV952KjGJo/1xrTkMRAJXfMf\nXdIwYiS03Mak7T26z49KNDyRspbigCzuJn6rT/VG4rplQqK3GzV4nVV0R75plBym\nVqQQax6x2jrKaevb5dA+HF2cYCtThlfQro5/1D+kYhEtlnI8BVZUbTQSFHzwBElY\nhsgxXa3+yAYQB9tdoXzb9k+8X7silqRjEljhcAFoSIkCrEsJXete9rsUfq9q8V3v\n8wIDAQAB\n-----END PUBLIC KEY-----\n	2025-10-10 03:12:09.507822	2025-10-03 03:17:03.053153	I love different kinds of cuisine~	gourmet		\N	8a304de8174113ec.jpg	image/jpeg	23225	2025-10-03 03:17:03.021152	\N	\N	\N	\N	\N	f		\N					0	f	\N	\N	[]	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	f	{}
115378678396852544	openCompany	\N	-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKCAQEApa935sKXm5FYlHNj+ADwXKDIJvBs2t+7fjHXHkvPAdIHyDE1\nJJQIBaBkqoFXt/PhOjQiT+pDHGurrDB6kHUzn2nIfG9dahymhFqdtWYizDAJm8+S\nsXRUhSnGDPFudKQnVnjBOQ0GyD6pKMaBBW83HQR4jWjtgvCfU5fbtWzPQr0N0Cmj\nT1X6fTQSrLSJo0E4W3yHZ4fZIogqz0l9bZfT20kEk6BTOCFM9BH6r0b17oY0tVop\nfaQZrvU67hyStpP7J/sU0wuTIuP6BGjcgbvy2qRMjm8ApspOrveaB3tiVuHpuAtt\nNuJuFqratijQWB9jpyaKg6rjg3GWI/VYPM0cNwIDAQABAoIBAAhSq8KJ8VUmi0Zx\nypzM10YyM7u9l9Nq4OiyX/XjydxzsT09pdnor3p6BXSJhDquY71OCpBakT3nh+AG\nU2izKoFprjyzIbssJY5kyuwvto9+/kNuKvHeP/yse4hKoRKJf1M9sfFscRiiUuTE\nebHfMRBG0DgNuyrvtgXJ+vR1cdNXoaW/fn+eUeSdteV6bfyEb7OkacEq6yluc2Ud\ngIAteUrgoW75mGVfvoyJUpYrEMrr7OFIFSa8fA28AF6k+ByEUUJOFmpU1dTOLtC4\nXTz9sOwlOvCWdhdJPbK6TPGkfLDDi6+SY57TgL6iPQIKqLxHYQI758aH9bZzVKnA\nSeDGXkkCgYEA5HbWxZ2EqJgqTvnakyaJY2tihK4WH6xKj8mGeGV8oIeYo/ygIUb5\nOrZUJt/7/ehVofM87Y+PJ8/7EJeDeVLNjfEl2LGCcnnxs+ht5g3p9MP4vZyL9Ar9\nHTnEBGncKIkySsoUhkuN4IKN43NNC3hN+9OoMxhngR+FcS+KxfrGcy0CgYEAuaee\nL5+llvCzJLUUxP2t8GoqivjM4+GJUFEhmH3CruJGboGi8SiRIdlq75DHJRqyNHwf\nBbNHSJc4ycO5zMpxEtz4Tfjp8xCAJn2IuVw7HBsaDMxi1dzC+XM/GKtirgDP5qvo\nAzUdpI1FgdTf+W8zQDhsOPJ84Af46/BD8R8MO3MCgYEA3PSOXMsuHLwl1wHQQha4\nMz4NJxMS9Ij2B8A43EIS2VKq7paJ7AUvT3g9ROfFV9iW0S1lFMCODEwanf5bOkA5\n6vh5yOxMpBiKCZxWhXOZfI74B7HarSjfiZ9vk3Eqas3dpPVyCjwSODsrrPm7Xsd4\nbIBUoS4OFJR+w2vehAE4YvUCgYEAoidV0bC197zqKyCCMICFoNuJpvIiOtNtlJoY\nJtGI7iiybaiKwem1wYPdk7q3RaAokBDtI5RvqWZzcj6ilM0or9oSgj/rTqJV28h/\nV67H7gd53D3UAYkdPrU7Iffna6VH8Oiq78o/xs6hLAHbUkie0fO2CpM5II+2CZVE\nMmD01SMCgYAlHeYssobL0FwoQ4dWXYict0tgcFyw85/riD8zt/wtejAVuJCXgfct\nV1PBGZLeOoBcrddvIcf/SVaUwx2asFVrU4aiFitWg7iU7bPE2w6EdnAZ3AocfDwH\nQxGrIhvnBsLxYQK9ifVOFofaGf0XUjwFe+UmCkHeBLSHyhDSN+VhBQ==\n-----END RSA PRIVATE KEY-----\n	-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApa935sKXm5FYlHNj+ADw\nXKDIJvBs2t+7fjHXHkvPAdIHyDE1JJQIBaBkqoFXt/PhOjQiT+pDHGurrDB6kHUz\nn2nIfG9dahymhFqdtWYizDAJm8+SsXRUhSnGDPFudKQnVnjBOQ0GyD6pKMaBBW83\nHQR4jWjtgvCfU5fbtWzPQr0N0CmjT1X6fTQSrLSJo0E4W3yHZ4fZIogqz0l9bZfT\n20kEk6BTOCFM9BH6r0b17oY0tVopfaQZrvU67hyStpP7J/sU0wuTIuP6BGjcgbvy\n2qRMjm8ApspOrveaB3tiVuHpuAttNuJuFqratijQWB9jpyaKg6rjg3GWI/VYPM0c\nNwIDAQAB\n-----END PUBLIC KEY-----\n	2025-10-15 14:35:16.030459	2025-10-02 14:31:36.510148		openCompany		\N	d452c50c8093866a.jpg	image/jpeg	26391	2025-10-02 14:31:36.449621	\N	\N	\N	\N	\N	f		\N					0	f	\N	\N	[]	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	f	{}
\.


--
-- Data for Name: accounts_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts_tags (account_id, tag_id) FROM stdin;
\.


--
-- Data for Name: admin_action_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_action_logs (id, account_id, action, target_type, target_id, created_at, updated_at, human_identifier, route_param, permalink) FROM stdin;
\.


--
-- Data for Name: announcement_mutes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.announcement_mutes (id, account_id, announcement_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: announcement_reactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.announcement_reactions (id, account_id, announcement_id, name, custom_emoji_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.announcements (id, text, published, all_day, scheduled_at, starts_at, ends_at, created_at, updated_at, published_at, status_ids) FROM stdin;
\.


--
-- Data for Name: appeals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appeals (id, account_id, account_warning_id, text, approved_at, approved_by_account_id, rejected_at, rejected_by_account_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	production	2025-10-08 11:57:24.14443	2025-10-08 11:57:24.144438
schema_sha1	d03e3ba56d365d37ac099782d9d80efbce3abb8b	2025-10-08 11:57:24.185946	2025-10-08 11:57:24.185947
\.


--
-- Data for Name: backups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backups (id, user_id, dump_file_name, dump_content_type, dump_updated_at, processed, created_at, updated_at, dump_file_size) FROM stdin;
\.


--
-- Data for Name: blocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blocks (id, created_at, updated_at, account_id, target_account_id, uri) FROM stdin;
\.


--
-- Data for Name: bookmarks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bookmarks (id, account_id, status_id, created_at, updated_at) FROM stdin;
4	115338428522805842	115410818912936581	2025-10-12 06:11:06.685824	2025-10-12 06:11:06.685824
5	115338428522805842	115348102480027134	2025-10-12 06:11:09.73076	2025-10-12 06:11:09.73076
6	115338428522805842	115410836820181445	2025-10-12 06:11:13.632772	2025-10-12 06:11:13.632772
\.


--
-- Data for Name: bulk_import_rows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bulk_import_rows (id, bulk_import_id, data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bulk_imports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bulk_imports (id, type, state, total_items, imported_items, processed_items, finished_at, overwrite, likely_mismatched, original_filename, account_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: canonical_email_blocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.canonical_email_blocks (id, canonical_email_hash, reference_account_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: conversation_mutes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversation_mutes (id, conversation_id, account_id) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversations (id, uri, created_at, updated_at) FROM stdin;
1	\N	2025-10-08 11:59:15.246799	2025-10-08 11:59:15.246799
2	\N	2025-10-08 11:59:15.309926	2025-10-08 11:59:15.309926
3	\N	2025-10-08 11:59:15.355892	2025-10-08 11:59:15.355892
4	\N	2025-10-08 14:44:40.706793	2025-10-08 14:44:40.706793
5	\N	2025-10-08 14:46:42.961294	2025-10-08 14:46:42.961294
6	\N	2025-10-08 14:48:49.349032	2025-10-08 14:48:49.349032
7	\N	2025-10-08 16:01:17.379167	2025-10-08 16:01:17.379167
8	\N	2025-10-08 16:05:51.539225	2025-10-08 16:05:51.539225
9	\N	2025-10-09 15:03:41.014656	2025-10-09 15:03:41.014656
10	\N	2025-10-10 04:59:24.503467	2025-10-10 04:59:24.503467
11	\N	2025-10-10 05:00:16.240724	2025-10-10 05:00:16.240724
12	\N	2025-10-10 05:00:26.056959	2025-10-10 05:00:26.056959
13	\N	2025-10-10 05:05:29.748094	2025-10-10 05:05:29.748094
14	\N	2025-10-10 05:07:24.333089	2025-10-10 05:07:24.333089
15	\N	2025-10-10 05:07:26.438071	2025-10-10 05:07:26.438071
16	\N	2025-10-10 05:07:47.044001	2025-10-10 05:07:47.044001
17	\N	2025-10-10 10:35:00.8316	2025-10-10 10:35:00.8316
18	\N	2025-10-10 10:37:22.577281	2025-10-10 10:37:22.577281
19	\N	2025-10-10 11:03:42.722149	2025-10-10 11:03:42.722149
20	\N	2025-10-16 11:44:46.093816	2025-10-16 11:44:46.093816
21	\N	2025-10-16 11:48:50.781041	2025-10-16 11:48:50.781041
22	\N	2025-10-16 11:56:03.596677	2025-10-16 11:56:03.596677
23	\N	2025-10-16 12:02:21.869003	2025-10-16 12:02:21.869003
24	\N	2025-10-16 12:09:56.527186	2025-10-16 12:09:56.527186
25	\N	2025-10-16 12:18:17.578603	2025-10-16 12:18:17.578603
26	\N	2025-10-16 12:27:35.138647	2025-10-16 12:27:35.138647
27	\N	2025-10-16 12:30:24.049043	2025-10-16 12:30:24.049043
28	\N	2025-10-16 12:39:18.038573	2025-10-16 12:39:18.038573
29	\N	2025-10-16 13:04:07.30228	2025-10-16 13:04:07.30228
30	\N	2025-10-16 13:05:22.980058	2025-10-16 13:05:22.980058
31	\N	2025-10-16 13:06:30.669573	2025-10-16 13:06:30.669573
32	\N	2025-10-16 13:10:22.480662	2025-10-16 13:10:22.480662
33	\N	2025-10-16 13:12:24.790691	2025-10-16 13:12:24.790691
34	\N	2025-10-21 06:46:58.858099	2025-10-21 06:46:58.858099
35	\N	2025-10-21 06:47:44.916712	2025-10-21 06:47:44.916712
36	\N	2025-10-21 06:49:01.323079	2025-10-21 06:49:01.323079
37	\N	2025-10-21 06:53:34.565726	2025-10-21 06:53:34.565726
38	\N	2025-10-25 07:29:37.139298	2025-10-25 07:29:37.139298
39	\N	2025-10-01 02:31:22.8422	2025-10-01 02:31:22.8422
40	\N	2025-10-01 07:33:33.18225	2025-10-01 07:33:33.18225
41	\N	2025-10-02 02:30:22.444772	2025-10-02 02:30:22.444772
42	\N	2025-10-02 02:31:04.763481	2025-10-02 02:31:04.763481
43	\N	2025-10-03 02:30:44.311806	2025-10-03 02:30:44.311806
44	\N	2025-10-03 06:33:40.486206	2025-10-03 06:33:40.486206
45	\N	2025-10-04 06:30:04.537926	2025-10-04 06:30:04.537926
46	\N	2025-10-05 04:03:42.846669	2025-10-05 04:03:42.846669
47	\N	2025-10-07 04:00:17.570323	2025-10-07 04:00:17.570323
48	\N	2025-10-09 04:00:06.314676	2025-10-09 04:00:06.314676
49	\N	2025-10-11 04:00:03.659854	2025-10-11 04:00:03.659854
50	\N	2025-10-11 04:00:30.791482	2025-10-11 04:00:30.791482
51	\N	2025-10-03 03:07:40.346878	2025-10-03 03:07:40.346878
52	\N	2025-10-03 03:13:31.062682	2025-10-03 03:13:31.062682
53	\N	2025-10-03 03:14:04.543701	2025-10-03 03:14:04.543701
54	\N	2025-10-03 03:14:51.746777	2025-10-03 03:14:51.746777
55	\N	2025-10-03 03:19:37.404941	2025-10-03 03:19:37.404941
56	\N	2025-10-03 03:20:06.681501	2025-10-03 03:20:06.681501
57	\N	2025-10-03 03:20:28.660413	2025-10-03 03:20:28.660413
58	\N	2025-10-06 07:00:25.074567	2025-10-06 07:00:25.074567
59	\N	2025-10-06 07:00:51.638906	2025-10-06 07:00:51.638906
60	\N	2025-10-06 07:01:16.057791	2025-10-06 07:01:16.057791
61	\N	2025-10-06 07:01:57.508052	2025-10-06 07:01:57.508052
62	\N	2025-10-06 07:02:22.059533	2025-10-06 07:02:22.059533
63	\N	2025-10-06 07:02:53.135641	2025-10-06 07:02:53.135641
64	\N	2025-10-06 07:03:18.088355	2025-10-06 07:03:18.088355
65	\N	2025-10-09 06:00:11.569347	2025-10-09 06:00:11.569347
66	\N	2025-10-09 06:00:54.231935	2025-10-09 06:00:54.231935
67	\N	2025-10-09 06:01:22.724872	2025-10-09 06:01:22.724872
68	\N	2025-10-09 06:01:53.434627	2025-10-09 06:01:53.434627
69	\N	2025-10-09 06:02:31.233815	2025-10-09 06:02:31.233815
70	\N	2025-10-09 06:03:13.835029	2025-10-09 06:03:13.835029
71	\N	2025-10-09 06:03:37.252085	2025-10-09 06:03:37.252085
72	\N	2025-10-12 06:01:13.003338	2025-10-12 06:01:13.003338
73	\N	2025-10-12 06:02:14.795664	2025-10-12 06:02:14.795664
74	\N	2025-10-12 06:02:42.850719	2025-10-12 06:02:42.850719
84	\N	2025-10-15 14:31:07.616497	2025-10-15 14:31:07.616497
85	\N	2025-10-15 14:33:11.839797	2025-10-15 14:33:11.839797
86	\N	2025-10-02 14:31:55.281531	2025-10-02 14:31:55.281531
87	\N	2025-10-02 14:32:13.357416	2025-10-02 14:32:13.357416
88	\N	2025-10-04 14:30:09.432216	2025-10-04 14:30:09.432216
89	\N	2025-10-04 14:30:19.307741	2025-10-04 14:30:19.307741
90	\N	2025-10-06 14:30:07.903251	2025-10-06 14:30:07.903251
91	\N	2025-10-06 14:30:22.054377	2025-10-06 14:30:22.054377
92	\N	2025-10-09 14:30:11.457391	2025-10-09 14:30:11.457391
93	\N	2025-10-13 14:30:11.914853	2025-10-13 14:30:11.914853
94	\N	2025-10-15 14:30:49.370491	2025-10-15 14:30:49.370491
\.


--
-- Data for Name: custom_emoji_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_emoji_categories (id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: custom_emojis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_emojis (id, shortcode, domain, image_file_name, image_content_type, image_file_size, image_updated_at, created_at, updated_at, disabled, uri, image_remote_url, visible_in_picker, category_id, image_storage_schema_version) FROM stdin;
\.


--
-- Data for Name: custom_filter_keywords; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_filter_keywords (id, custom_filter_id, keyword, whole_word, created_at, updated_at) FROM stdin;
4	2	kill	t	2025-10-25 07:35:02.4917	2025-10-25 07:35:02.4917
5	2	fuck	t	2025-10-25 07:35:02.493605	2025-10-25 07:35:02.493605
6	2	blood	t	2025-10-25 07:35:02.493947	2025-10-25 07:35:02.493947
\.


--
-- Data for Name: custom_filter_statuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_filter_statuses (id, custom_filter_id, status_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: custom_filters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_filters (id, account_id, expires_at, phrase, context, created_at, updated_at, action) FROM stdin;
2	115338428522805842	\N	Violence	{home,notifications,public,thread,account}	2025-10-25 07:35:02.488919	2025-10-25 07:35:02.488919	0
\.


--
-- Data for Name: domain_allows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.domain_allows (id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: domain_blocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.domain_blocks (id, domain, created_at, updated_at, severity, reject_media, reject_reports, private_comment, public_comment, obfuscate) FROM stdin;
\.


--
-- Data for Name: email_domain_blocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_domain_blocks (id, domain, created_at, updated_at, parent_id, allow_with_approval) FROM stdin;
\.


--
-- Data for Name: favourites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.favourites (id, created_at, updated_at, account_id, status_id) FROM stdin;
\.


--
-- Data for Name: featured_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.featured_tags (id, account_id, tag_id, statuses_count, last_status_at, created_at, updated_at, name) FROM stdin;
\.


--
-- Data for Name: follow_recommendation_mutes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.follow_recommendation_mutes (id, account_id, target_account_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: follow_recommendation_suppressions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.follow_recommendation_suppressions (id, account_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: follow_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.follow_requests (id, created_at, updated_at, account_id, target_account_id, show_reblogs, uri, notify, languages) FROM stdin;
\.


--
-- Data for Name: follows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.follows (id, created_at, updated_at, account_id, target_account_id, show_reblogs, uri, notify, languages) FROM stdin;
5	2025-10-20 15:49:26.322086	2025-10-20 15:49:26.322086	115338428522805842	115407279078399620	t	https://10.0.2.2/7521f73d-4721-4f5b-a99d-e5f8410504fb	f	\N
6	2025-10-20 15:49:39.707757	2025-10-20 15:49:39.707757	115338428522805842	115407279337451464	t	https://10.0.2.2/fbc33c9d-f647-4f2c-8b75-9ef439f39e4b	f	\N
7	2025-10-20 15:49:47.426493	2025-10-20 15:49:47.426493	115338428522805842	115407279554762986	t	https://10.0.2.2/3e4335d7-16a8-4998-a191-24060ae81118	f	\N
8	2025-10-12 06:09:33.38921	2025-10-12 06:09:33.38921	115338428522805842	115383646696917550	t	https://10.0.2.2/74fe9715-9a8f-474c-a78b-b434116b86bd	f	\N
9	2025-10-12 06:09:43.156484	2025-10-12 06:09:43.156484	115338428522805842	115383709981264049	t	https://10.0.2.2/52291336-648e-41c9-8c93-c77ab6de9f08	f	\N
10	2025-10-12 06:09:56.980159	2025-10-12 06:09:56.980159	115338428522805842	115410778295457737	t	https://10.0.2.2/bcffece8-86a6-460a-bac8-fa24ff83cd6d	f	\N
11	2025-10-12 06:10:03.626615	2025-10-12 06:10:03.626615	115338428522805842	115445893227871976	t	https://10.0.2.2/2efdaa9c-555c-45b1-b54b-659a6ecbab8c	f	\N
12	2025-10-12 06:10:11.827971	2025-10-12 06:10:11.827971	115338428522805842	115347680385540244	t	https://10.0.2.2/f753f6ff-4703-49ae-abdd-e8ae2e962383	f	\N
13	2025-10-12 06:10:17.777097	2025-10-12 06:10:17.777097	115338428522805842	115347680582977591	t	https://10.0.2.2/bb7ada7a-7b6a-40ab-9177-c128f8523de6	f	\N
14	2025-10-12 06:10:26.429804	2025-10-12 06:10:26.429804	115338428522805842	115347680754305497	t	https://10.0.2.2/7e2d46de-5d9d-4a37-9ee2-b6e3e76c8f4f	f	\N
41	2025-10-15 14:32:13.178154	2025-10-15 14:32:13.178154	115338428522805842	115378678396852544	t	https://10.0.2.2/f6a9e263-ebf2-46f4-a7f6-a33feed36eda	f	\N
\.


--
-- Data for Name: generated_annual_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.generated_annual_reports (id, account_id, year, data, schema_version, viewed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.identities (id, provider, uid, created_at, updated_at, user_id) FROM stdin;
\.


--
-- Data for Name: imports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.imports (id, type, approved, created_at, updated_at, data_file_name, data_content_type, data_file_size, data_updated_at, account_id, overwrite) FROM stdin;
\.


--
-- Data for Name: invites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invites (id, user_id, code, expires_at, max_uses, uses, created_at, updated_at, autofollow, comment) FROM stdin;
1	1	Bvs3y58t	2025-10-17 04:31:56.681746	5	1	2025-10-10 04:31:56.693632	2025-10-10 04:31:56.693632	f	\N
2	3	GYn5hW9a	2025-10-13 12:32:04.942439	5	0	2025-10-13 12:02:04.949049	2025-10-13 12:02:04.949049	t	\N
3	3	ciu7pK2m	2025-10-13 12:34:33.731632	5	0	2025-10-13 12:04:33.732596	2025-10-13 12:04:33.732596	t	\N
4	3	kPA2DfcB	2025-10-14 12:13:23.712869	1	0	2025-10-13 12:13:23.715918	2025-10-13 12:13:23.715918	t	\N
\.


--
-- Data for Name: ip_blocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ip_blocks (id, ip, severity, expires_at, comment, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: list_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.list_accounts (id, list_id, account_id, follow_id, follow_request_id) FROM stdin;
\.


--
-- Data for Name: lists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lists (id, account_id, title, created_at, updated_at, replies_policy, exclusive) FROM stdin;
\.


--
-- Data for Name: login_activities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.login_activities (id, user_id, authentication_method, provider, success, failure_reason, ip, user_agent, created_at) FROM stdin;
1	2	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-08 14:19:03.0567
2	2	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-08 14:20:18.814905
3	3	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-08 14:50:35.870011
4	3	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-09 15:01:32.420496
5	3	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-09 15:01:42.322811
6	2	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-10 04:48:05.324001
7	3	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-10 05:06:41.640992
8	3	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-16 08:23:13.359052
9	5	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-16 11:41:51.360314
10	6	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-16 12:08:56.774163
11	3	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-16 12:31:09.711366
12	3	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-19 17:50:31.769626
13	11	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-21 06:40:03.310924
14	3	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-21 06:57:12.510299
15	3	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-25 07:35:54.543137
16	12	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-01 02:30:59.243703
17	3	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-11 04:03:35.394092
18	6	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-27 13:36:40.970573
19	3	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-11-07 05:05:54.710373
20	3	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-11-07 05:06:38.024678
21	13	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-03 03:03:01.958832
22	14	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-03 03:12:10.075296
23	15	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-03 03:15:53.837803
52	3	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-11-17 06:40:20.736712
53	9	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-15 14:32:35.210446
54	46	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-02 14:31:25.495313
55	1	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-10-15 14:31:53.940449
56	1	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-11-17 12:15:31.38999
57	3	password	\N	t	\N	172.18.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	2025-11-17 12:15:54.165562
\.


--
-- Data for Name: markers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.markers (id, user_id, timeline, last_read_id, lock_version, created_at, updated_at) FROM stdin;
1	2	home	115348126416869763	5	2025-10-08 14:39:31.877311	2025-10-10 05:06:14.539996
4	5	home	115384006900557641	8	2025-10-16 11:55:59.034143	2025-10-16 13:10:34.280893
6	11	home	115410836820181445	2	2025-10-21 06:53:44.168138	2025-10-21 06:54:13.504256
2	3	home	115433627788463436	10	2025-10-08 14:50:57.879524	2025-10-25 07:30:27.238693
7	12	home	115353533205151985	1	2025-10-11 04:02:38.631114	2025-10-11 04:02:38.634708
5	6	home	115384014916118822	8	2025-10-16 12:12:50.004542	2025-10-27 13:37:57.270983
8	13	home	115342679183802668	3	2025-10-03 03:07:51.094759	2025-10-09 06:00:15.641817
9	14	home	115359670141158913	7	2025-10-03 03:15:02.039515	2025-10-12 06:01:48.044523
10	15	home	115359674190777168	4	2025-10-06 07:00:08.187526	2025-10-12 06:02:20.345586
41	9	home	115378670262150858	1	2025-10-15 14:33:14.01301	2025-10-15 14:33:14.016419
42	46	home	115316372893382635	1	2025-10-15 14:31:16.026152	2025-10-15 14:31:16.029204
43	1	home	115338428759320819	1	2025-11-17 12:15:36.417842	2025-11-17 12:15:36.428546
3	3	notifications	25	2	2025-10-13 08:10:06.410421	2025-11-17 12:17:42.432575
\.


--
-- Data for Name: media_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media_attachments (id, status_id, file_file_name, file_content_type, file_file_size, file_updated_at, remote_url, created_at, updated_at, shortcode, type, file_meta, account_id, description, scheduled_status_id, blurhash, processing, file_storage_schema_version, thumbnail_file_name, thumbnail_content_type, thumbnail_file_size, thumbnail_updated_at, thumbnail_remote_url) FROM stdin;
115339075632389303	115339079234848283	bfebf04abff5497f.jpg	image/jpeg	63945	2025-10-08 14:43:45.582564		2025-10-08 14:43:45.73662	2025-10-08 14:44:40.747958	\N	0	{"original":{"width":657,"height":402,"size":"657x402","aspect":1.6343283582089552},"small":{"width":613,"height":375,"size":"613x375","aspect":1.6346666666666667}}	115338428325536028	beautiful Beijing!!!	\N	UXEyusxBxFWUX=WERlWC59R.R%oLVqt5oHoe	2	1	\N	\N	\N	\N	\N
115339086365608467	115339087247102887	fdda78f8804ab0b4.jpg	image/jpeg	14205	2025-10-08 14:46:29.431627		2025-10-08 14:46:29.51189	2025-10-08 14:46:42.9729	\N	0	{"original":{"width":304,"height":166,"size":"304x166","aspect":1.8313253012048192},"small":{"width":304,"height":166,"size":"304x166","aspect":1.8313253012048192}}	115338428325536028	\N	\N	UgHB3n9vt5s,~99wbHs+nhNdWVs.M|baWBoJ	2	1	\N	\N	\N	\N	\N
115339094836531384	115339095529918402	892cafe1c81652fa.jpg	image/jpeg	86643	2025-10-08 14:48:38.658402		2025-10-08 14:48:38.76901	2025-10-08 14:48:49.353483	\N	0	{"original":{"width":750,"height":500,"size":"750x500","aspect":1.5},"small":{"width":588,"height":392,"size":"588x392","aspect":1.5}}	115338428325536028	\N	\N	UQGS7Jxu9GE0_N%hE1IA?I%LbEIUx^aKs8R*	2	1	\N	\N	\N	\N	\N
115339094842664479	115339095529918402	ce743965c4e3a8a6.jpg	image/jpeg	11486	2025-10-08 14:48:38.814247		2025-10-08 14:48:38.862313	2025-10-08 14:48:49.355741	\N	0	{"original":{"width":275,"height":183,"size":"275x183","aspect":1.5027322404371584},"small":{"width":275,"height":183,"size":"275x183","aspect":1.5027322404371584}}	115338428325536028	\N	\N	UbJj#kJ80evz?bs;nNRiADw^r=TJjEf*f,xv	2	1	\N	\N	\N	\N	\N
115348093867186946	115348102480027134	33cf91f24f08abb5.jpg	image/jpeg	67281	2025-10-10 04:57:12.959621		2025-10-10 04:57:13.076795	2025-10-10 04:59:24.511848	\N	0	{"original":{"width":600,"height":489,"size":"600x489","aspect":1.2269938650306749},"small":{"width":531,"height":433,"size":"531x433","aspect":1.2263279445727482}}	115338428325536028	\N	\N	UFIzY2Mw15NF18ivTKIoNdM{^jV?=^RjWWxB	2	1	\N	\N	\N	\N	\N
115348093881333080	115348102480027134	8b9b300bc851fe99.jpg	image/jpeg	18228	2025-10-10 04:57:13.197066		2025-10-10 04:57:13.293924	2025-10-10 04:59:24.514856	\N	0	{"original":{"width":500,"height":333,"size":"500x333","aspect":1.5015015015015014},"small":{"width":500,"height":333,"size":"500x333","aspect":1.5015015015015014}}	115338428325536028	\N	\N	U~J[9dn%R-X8?wWVj[ofkroLjYWBRjoeWBWB	2	1	\N	\N	\N	\N	\N
115348093888400356	115348102480027134	0845ea2022765713.jpg	image/jpeg	48199	2025-10-10 04:57:13.346501		2025-10-10 04:57:13.403934	2025-10-10 04:59:24.515511	\N	0	{"original":{"width":700,"height":415,"size":"700x415","aspect":1.6867469879518073},"small":{"width":623,"height":369,"size":"623x369","aspect":1.6883468834688347}}	115338428325536028	\N	\N	UAECOGR:4qRR?[xuD*Rk1JxaVtRkb:xuIWxa	2	1	\N	\N	\N	\N	\N
115383981873060857	115383982312877318	4af55675dedc8acd.png	image/png	1318819	2025-10-16 13:04:00.354695		2025-10-16 13:04:00.590539	2025-10-16 13:04:07.31041	\N	0	{"original":{"width":800,"height":600,"size":"800x600","aspect":1.3333333333333333},"small":{"width":554,"height":416,"size":"554x416","aspect":1.3317307692307692}}	115383646696917550	\N	\N	UMF;.n~V-ot60fM{NHWC58RjWCofI=kCjYNG	2	1	\N	\N	\N	\N	\N
115410808524757931	115410810887077411	df745e86810aa31d.jpg	image/jpeg	43583	2025-10-21 06:46:22.650014		2025-10-21 06:46:22.809174	2025-10-21 06:46:58.865867	\N	0	{"original":{"width":560,"height":350,"size":"560x350","aspect":1.6},"small":{"width":560,"height":350,"size":"560x350","aspect":1.6}}	115410778295457737	\N	\N	UIG+mDrs0dozOlbaxtk9YWSg-qjZN3aMMyn,	2	1	\N	\N	\N	\N	\N
115410813763931783	115410813905484454	2a4e5daed3ea3b96.jpg	image/jpeg	52563	2025-10-21 06:47:42.631589		2025-10-21 06:47:42.753869	2025-10-21 06:47:44.924158	\N	0	{"original":{"width":790,"height":458,"size":"790x458","aspect":1.724890829694323},"small":{"width":630,"height":365,"size":"630x365","aspect":1.726027397260274}}	115410778295457737	\N	\N	UKCZ,ksm9aR:8:R*t1%2O-M}Vbxt-VxaSwR*	2	1	\N	\N	\N	\N	\N
115410818800106320	115410818912936581	e4bd6279a41d81a4.jpg	image/jpeg	8314	2025-10-21 06:48:59.496465		2025-10-21 06:48:59.599745	2025-10-21 06:49:01.335309	\N	0	{"original":{"width":275,"height":183,"size":"275x183","aspect":1.5027322404371584},"small":{"width":275,"height":183,"size":"275x183","aspect":1.5027322404371584}}	115410778295457737	\N	\N	UTGlL%aI4.Sz.AadM_ozIof-ads;%NWCjZjY	2	1	\N	\N	\N	\N	\N
115410836631400287	115410836820181445	ac07cf0fdcd872de.jpg	image/jpeg	12786	2025-10-21 06:53:31.630351		2025-10-21 06:53:31.683335	2025-10-21 06:53:34.56731	\N	0	{"original":{"width":275,"height":183,"size":"275x183","aspect":1.5027322404371584},"small":{"width":275,"height":183,"size":"275x183","aspect":1.5027322404371584}}	115410778295457737	\N	\N	UHH_uMXPE0%09qadIXxt4,NGIZbb^+t7%2WC	2	1	\N	\N	\N	\N	\N
115410818807091709	115410818912936581	4288989a0a463b7e.jpg	image/jpeg	14254	2025-10-21 06:48:59.65315		2025-10-21 06:48:59.706787	2025-10-21 06:49:01.337736	\N	0	{"original":{"width":275,"height":183,"size":"275x183","aspect":1.5027322404371584},"small":{"width":275,"height":183,"size":"275x183","aspect":1.5027322404371584}}	115410778295457737	\N	\N	U8Dv#*R65$OX_Jx?RQxZ30pG$lRPIBMzg2X9	2	1	\N	\N	\N	\N	\N
115410836622615596	115410836820181445	c8669ee64c02e691.jpg	image/jpeg	10022	2025-10-21 06:53:31.482666		2025-10-21 06:53:31.549722	2025-10-21 06:53:34.567864	\N	0	{"original":{"width":264,"height":191,"size":"264x191","aspect":1.382198952879581},"small":{"width":264,"height":191,"size":"264x191","aspect":1.382198952879581}}	115410778295457737	\N	\N	UKJQ[hRfI8N$4_E29bxt9#N2E2t1~S-.V=NL	2	1	\N	\N	\N	\N	\N
115410836640130215	115410836820181445	21aed410464ce63b.jpg	image/jpeg	11267	2025-10-21 06:53:31.777105		2025-10-21 06:53:31.81716	2025-10-21 06:53:34.568231	\N	0	{"original":{"width":225,"height":225,"size":"225x225","aspect":1.0},"small":{"width":225,"height":225,"size":"225x225","aspect":1.0}}	115410778295457737	\N	\N	UeK1sc%f-zW8~Sf,xs%0R$IpN3%LxEW-R+Rl	2	1	\N	\N	\N	\N	\N
115297788590177428	115297747807930559	5ff8249c812048f7.jpg	image/jpeg	528332	2025-10-01 07:43:55.353482		2025-10-01 07:43:55.468864	2025-10-01 07:43:55.468864	\N	0	{"original":{"width":2048,"height":2730,"size":"2048x2730","aspect":0.7501831501831502},"small":{"width":416,"height":554,"size":"416x554","aspect":0.7509025270758123}}	115445893227871976	\N	\N	UOK,jF_4T0RPBo%LrWMw.A?ax[NGxTShRQR:	2	1	\N	\N	\N	\N	\N
115308832804318672	115308836977807389	78e8c1aff6889494.jpg	image/jpeg	956422	2025-10-03 06:32:36.597286		2025-10-03 06:32:36.80206	2025-10-03 06:33:40.490781	\N	0	{"original":{"width":3731,"height":1587,"size":"3731x1587","aspect":2.3509766855702585},"small":{"width":736,"height":313,"size":"736x313","aspect":2.351437699680511}}	115445893227871976	delish!	\N	UJKnI_-qAM.9.9?v-;?a%%9a-UM{_2ofWFRk	2	1	\N	\N	\N	\N	\N
115319571613720632	115319571928036858	9233a784e5525d0c.jpg	image/jpeg	16293	2025-10-05 04:03:37.949537		2025-10-05 04:03:38.029492	2025-10-05 04:03:42.857359	\N	0	{"original":{"width":540,"height":360,"size":"540x360","aspect":1.5},"small":{"width":540,"height":360,"size":"540x360","aspect":1.5}}	115445893227871976	\N	\N	UHDHKi$*0}Rk]ijYJ8n+E%W=$%smNIWCoIoJ	2	1	\N	\N	\N	\N	\N
115319571636093130	115319571928036858	3a0cba7a548347d5.jpg	image/jpeg	665423	2025-10-05 04:03:38.280798		2025-10-05 04:03:38.372662	2025-10-05 04:03:42.860905	\N	0	{"original":{"width":2048,"height":2730,"size":"2048x2730","aspect":0.7501831501831502},"small":{"width":416,"height":554,"size":"416x554","aspect":0.7509025270758123}}	115445893227871976	\N	\N	UDF=Be?wyrSOzmMvITWBGIkWr?wbr;ozW@t8	2	1	\N	\N	\N	\N	\N
115319571655011162	115319571928036858	0a03609b5e81fa09.jpg	image/jpeg	13017	2025-10-05 04:03:38.621244		2025-10-05 04:03:38.660238	2025-10-05 04:03:42.86334	\N	0	{"original":{"width":300,"height":300,"size":"300x300","aspect":1.0},"small":{"width":300,"height":300,"size":"300x300","aspect":1.0}}	115445893227871976	\N	\N	UJR{oZxu?wx]s.kCtSof?waeDhWB%hWAROfR	2	1	\N	\N	\N	\N	\N
115308049647805210	115308049928142735	8117487e81ce9f5d.jpg	image/jpeg	6152	2025-10-03 03:13:26.572179		2025-10-03 03:13:26.782791	2025-10-03 03:13:31.067777	\N	0	{"original":{"width":225,"height":225,"size":"225x225","aspect":1.0},"small":{"width":225,"height":225,"size":"225x225","aspect":1.0}}	115347680582977591	\N	\N	UDMt5K#O-WRjQRIUVqkWDOS%Dh%g-7aeMx-;	2	1	\N	\N	\N	\N	\N
115308052044984137	115308052122327485	eb7202aa28e96cad.jpg	image/jpeg	9103	2025-10-03 03:14:03.28111		2025-10-03 03:14:03.359824	2025-10-03 03:14:04.549289	\N	0	{"original":{"width":275,"height":183,"size":"275x183","aspect":1.5027322404371584},"small":{"width":275,"height":183,"size":"275x183","aspect":1.5027322404371584}}	115347680582977591	\N	\N	UKJQ.qOXX.0L0$Q,xu%2D%ROtRR*M{S5aKV?	2	1	\N	\N	\N	\N	\N
115308055136052802	115308055215904871	c32de13124b42066.jpg	image/jpeg	6925	2025-10-03 03:14:50.428412		2025-10-03 03:14:50.526719	2025-10-03 03:14:51.751371	\N	0	{"original":{"width":259,"height":194,"size":"259x194","aspect":1.3350515463917525},"small":{"width":259,"height":194,"size":"259x194","aspect":1.3350515463917525}}	115347680582977591	\N	\N	UWCsmgt701RjM{ofxvWBM{WBxut7xuayWBja	2	1	\N	\N	\N	\N	\N
115325930719635226	115325930808153244	61cecd53f7124f1d.jpg	image/jpeg	15276	2025-10-06 07:00:50.192778		2025-10-06 07:00:50.285681	2025-10-06 07:00:51.641325	\N	0	{"original":{"width":248,"height":203,"size":"248x203","aspect":1.2216748768472907},"small":{"width":248,"height":203,"size":"248x203","aspect":1.2216748768472907}}	115347680754305497	\N	\N	UKJ%%V0MBDrq~oxsnkr?EjS1-7My^NRjS4r?	2	1	\N	\N	\N	\N	\N
115308073851626368	115308073936777032	6fb5278c03c7a903.jpg	image/jpeg	15333	2025-10-03 03:19:36.00578		2025-10-03 03:19:36.104038	2025-10-03 03:19:37.407949	\N	0	{"original":{"width":259,"height":194,"size":"259x194","aspect":1.3350515463917525},"small":{"width":259,"height":194,"size":"259x194","aspect":1.3350515463917525}}	115347680754305497	\N	\N	ULP5JrK,WHo#~p?H%Mbc.mo~OFRja}IojYxD	2	1	\N	\N	\N	\N	\N
115308075481948251	115308075855485062	14e7fe465d7fa679.jpg	image/jpeg	101406	2025-10-03 03:20:00.876249		2025-10-03 03:20:00.979995	2025-10-03 03:20:06.68511	\N	0	{"original":{"width":1024,"height":717,"size":"1024x717","aspect":1.4281729428172942},"small":{"width":574,"height":402,"size":"574x402","aspect":1.427860696517413}}	115347680754305497	\N	\N	UDI;@kOsES%3=qkXn$t7KS%h-;kr~qNGbJRP	2	1	\N	\N	\N	\N	\N
115308077121034110	115308077295869622	fd9ddf7212dc40fc.jpg	image/jpeg	16320	2025-10-03 03:20:25.91349		2025-10-03 03:20:25.991168	2025-10-03 03:20:28.662189	\N	0	{"original":{"width":259,"height":194,"size":"259x194","aspect":1.3350515463917525},"small":{"width":259,"height":194,"size":"259x194","aspect":1.3350515463917525}}	115347680754305497	\N	\N	UaLy[NW?-Qbd~okXn$ozt.ozNbt6xwxuR*sp	2	1	\N	\N	\N	\N	\N
115325932212881428	115325932408442041	68eab3b0ec40ced2.jpg	image/jpeg	10067	2025-10-06 07:01:13.009213		2025-10-06 07:01:13.070615	2025-10-06 07:01:16.062842	\N	0	{"original":{"width":300,"height":168,"size":"300x168","aspect":1.7857142857142858},"small":{"width":300,"height":168,"size":"300x168","aspect":1.7857142857142858}}	115347680754305497	\N	\N	UXM$*v^iuPI;t,I9xBt5x]ozV@t7x^o#n$aJ	2	1	\N	\N	\N	\N	\N
115325935043482800	115325935124985356	d37a52a32def0af8.jpg	image/jpeg	6030	2025-10-06 07:01:56.188918		2025-10-06 07:01:56.263744	2025-10-06 07:01:57.516164	\N	0	{"original":{"width":347,"height":145,"size":"347x145","aspect":2.393103448275862},"small":{"width":347,"height":145,"size":"347x145","aspect":2.393103448275862}}	115347680582977591	\N	\N	UHNdE%4TyFo#?c_3xuIBtmxvMxMxxaDiIB%M	2	1	\N	\N	\N	\N	\N
115325936633561364	115325936733960590	6b3f10542d6ef6b6.jpg	image/jpeg	10726	2025-10-06 07:02:20.459451		2025-10-06 07:02:20.524709	2025-10-06 07:02:22.061954	\N	0	{"original":{"width":284,"height":177,"size":"284x177","aspect":1.6045197740112995},"small":{"width":284,"height":177,"size":"284x177","aspect":1.6045197740112995}}	115347680582977591	\N	\N	UIG8J#k=0LRj~UNfIARjOEM{IBNHShnhIVWB	2	1	\N	\N	\N	\N	\N
115325938618326427	115325938770523080	e27c21a25dc66009.jpg	image/jpeg	5406	2025-10-06 07:02:50.760097		2025-10-06 07:02:50.810154	2025-10-06 07:02:53.138042	\N	0	{"original":{"width":275,"height":183,"size":"275x183","aspect":1.5027322404371584},"small":{"width":275,"height":183,"size":"275x183","aspect":1.5027322404371584}}	115347680582977591	\N	\N	UDFPW:o#~qx].8WXIBt6ayt7M{M{xujtRjaf	2	1	\N	\N	\N	\N	\N
115342681848384912	115342681979737543	2451e0c584baa267.jpg	image/jpeg	15786	2025-10-09 06:00:52.170307		2025-10-09 06:00:52.226151	2025-10-09 06:00:54.233497	\N	0	{"original":{"width":259,"height":194,"size":"259x194","aspect":1.3350515463917525},"small":{"width":259,"height":194,"size":"259x194","aspect":1.3350515463917525}}	115347680754305497	\N	\N	UJHn7+4np0IV~RxbE3t7M_kXIVtkE3M|xuNF	2	1	\N	\N	\N	\N	\N
115342683753382629	115342683847008004	155c663ceaa2154c.jpg	image/jpeg	10519	2025-10-09 06:01:21.235796		2025-10-09 06:01:21.294411	2025-10-09 06:01:22.729755	\N	0	{"original":{"width":300,"height":168,"size":"300x168","aspect":1.7857142857142858},"small":{"width":300,"height":168,"size":"300x168","aspect":1.7857142857142858}}	115347680754305497	\N	\N	UWQIU|DiyGVrR+kWxZbIn+oMN2tRxaWBWUj?	2	1	\N	\N	\N	\N	\N
115342685782967789	115342685859632441	2bd1ad2d5b61acae.jpg	image/jpeg	18810	2025-10-09 06:01:52.190672		2025-10-09 06:01:52.262969	2025-10-09 06:01:53.437376	\N	0	{"original":{"width":310,"height":162,"size":"310x162","aspect":1.9135802469135803},"small":{"width":310,"height":162,"size":"310x162","aspect":1.9135802469135803}}	115347680754305497	\N	\N	UKKmLI_NBs?bv|MxM{nhERog%2f+%1xDNKIq	2	1	\N	\N	\N	\N	\N
115342688241294115	115342688336777048	179fc5b362be835b.jpg	image/jpeg	115351	2025-10-09 06:02:29.661176		2025-10-09 06:02:29.773247	2025-10-09 06:02:31.237695	\N	0	{"original":{"width":1278,"height":1457,"size":"1278x1457","aspect":0.8771448181194235},"small":{"width":450,"height":513,"size":"450x513","aspect":0.8771929824561403}}	115347680582977591	\N	\N	UaD]JJt60KIoM{oft7RkIUWCxuoft8fQRjj[	2	1	\N	\N	\N	\N	\N
115342691058981547	115342691128783945	ccea22ea83f482cc.jpg	image/jpeg	8479	2025-10-09 06:03:12.678953		2025-10-09 06:03:12.768654	2025-10-09 06:03:13.837054	\N	0	{"original":{"width":225,"height":225,"size":"225x225","aspect":1.0},"small":{"width":225,"height":225,"size":"225x225","aspect":1.0}}	115347680582977591	\N	\N	UcLf~:R--n%L~WkDs-S1o}W=M{WBs.WDRij=	2	1	\N	\N	\N	\N	\N
115342692590126513	115342692663348018	b7b85f282b1cab00.jpg	image/jpeg	5649	2025-10-09 06:03:36.076713		2025-10-09 06:03:36.132245	2025-10-09 06:03:37.256027	\N	0	{"original":{"width":275,"height":183,"size":"275x183","aspect":1.5027322404371584},"small":{"width":275,"height":183,"size":"275x183","aspect":1.5027322404371584}}	115347680582977591	\N	\N	U8B3+j%z0MZ$E2M{niX89]sAxGXSv~S2S#sm	2	1	\N	\N	\N	\N	\N
115359673243901586	115359674190777168	d08767ab8b2202cc.jpg	image/jpeg	133231	2025-10-12 06:02:00.227576		2025-10-12 06:02:00.346312	2025-10-12 06:02:14.799297	\N	0	{"original":{"width":1200,"height":1200,"size":"1200x1200","aspect":1.0},"small":{"width":480,"height":480,"size":"480x480","aspect":1.0}}	115347680754305497	\N	\N	UMGbbf~q%#Vx%y-pxGMyK7bXDPM{IBM{RokW	2	1	\N	\N	\N	\N	\N
115359673257944538	115359674190777168	acc40b8993505a06.jpg	image/jpeg	14488	2025-10-12 06:02:00.521055		2025-10-12 06:02:00.560731	2025-10-12 06:02:14.800042	\N	0	{"original":{"width":275,"height":183,"size":"275x183","aspect":1.5027322404371584},"small":{"width":275,"height":183,"size":"275x183","aspect":1.5027322404371584}}	115347680754305497	\N	\N	UIJZ#h]~?^9[}-t39ttQXnWUVsxBR:RjM|tR	2	1	\N	\N	\N	\N	\N
115378670173986245	115378670262150858	a298a37a4a692e65.jpg	image/jpeg	113280	2025-10-15 14:33:10.21816		2025-10-15 14:33:10.493633	2025-10-15 14:33:11.850805	\N	0	{"original":{"width":1080,"height":675,"size":"1080x675","aspect":1.6},"small":{"width":606,"height":379,"size":"606x379","aspect":1.5989445910290236}}	115407279554762986	\N	\N	UIIC_yS##j=tnNt6kWxCw[w[NdOY};t6R*Rj	2	1	\N	\N	\N	\N	\N
115378658256750739	115378662120962265	786b345a13692592.jpg	image/jpeg	12459	2025-10-15 14:30:08.484169		2025-10-15 14:30:08.652632	2025-10-15 14:31:07.627056	\N	0	{"original":{"width":256,"height":197,"size":"256x197","aspect":1.299492385786802},"small":{"width":256,"height":197,"size":"256x197","aspect":1.299492385786802}}	115338428522805842	Impression, Sunrise presents a peaceful harbor scene at dawn, with the sea gently illuminated by the soft glow of the rising sun. The warm light filters through a layer of mist, creating an almost magical atmosphere. This early morning scene exudes calm, as the entire composition is bathed in gentle, golden hues.\n\nIn the distance, the faint outlines of several ships can be seen. The mist obscures their details, making them appear as mere shadows blending into the surrounding fog. This soft focus adds a sense of mystery to the painting, as if the world is just beginning to wake up.\n\nThe water itself is smooth, reflecting the sunlight in shimmering ripples. These subtle movements in the water enhance the feeling of stillness, as if time has momentarily slowed down. The colors of the sea are quiet and muted, allowing the light to be the focal point of the composition.\n\nAbove, the sky transitions from deep blue to light orange, illustrating the changing moments of dawn. The color gradient captures the fleeting nature of time, symbolizing the shift from night to day. This transition in the sky adds depth and dimension to the painting, making it feel both vast and intimate.	\N	ULHo2YIC.7-T+uxuemxY}PX8t7s:=rV@pIxD	2	1	\N	\N	\N	\N	\N
\.


--
-- Data for Name: mentions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mentions (id, status_id, created_at, updated_at, account_id, silent) FROM stdin;
\.


--
-- Data for Name: mutes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mutes (id, created_at, updated_at, hide_notifications, account_id, target_account_id, expires_at) FROM stdin;
\.


--
-- Data for Name: notification_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_permissions (id, account_id, from_account_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_policies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_policies (id, account_id, created_at, updated_at, for_not_following, for_not_followers, for_new_accounts, for_private_mentions, for_limited_accounts) FROM stdin;
1	115338428522805842	2025-10-13 19:43:57.078236	2025-10-13 19:43:57.078236	0	0	0	1	1
\.


--
-- Data for Name: notification_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_requests (id, account_id, from_account_id, last_status_id, notifications_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, activity_id, activity_type, created_at, updated_at, account_id, from_account_id, type, filtered, group_key) FROM stdin;
1	115338428325536028	Account	2025-10-08 11:59:15.353608	2025-10-08 11:59:15.353608	115338428152261473	115338428325536028	admin.sign_up	f	\N
2	115338428522805842	Account	2025-10-08 11:59:15.348238	2025-10-08 11:59:15.348238	115338428152261473	115338428522805842	admin.sign_up	f	\N
12	1	Report	2025-10-13 20:05:08.481553	2025-10-13 20:05:08.481553	115338428152261473	115338428522805842	admin.report	f	\N
13	115383646696917550	Account	2025-10-16 11:38:48.352748	2025-10-16 11:38:48.352748	115338428152261473	115383646696917550	admin.sign_up	f	\N
14	115383709981264049	Account	2025-10-16 11:54:52.360396	2025-10-16 11:54:52.360396	115338428152261473	115383709981264049	admin.sign_up	f	\N
16	115407279078399620	Account	2025-10-20 15:48:49.600076	2025-10-20 15:48:49.600076	115338428152261473	115407279078399620	admin.sign_up	f	\N
17	115407279337451464	Account	2025-10-20 15:48:52.785143	2025-10-20 15:48:52.785143	115338428152261473	115407279337451464	admin.sign_up	f	\N
18	115407279554762986	Account	2025-10-20 15:48:55.313976	2025-10-20 15:48:55.313976	115338428152261473	115407279554762986	admin.sign_up	f	\N
19	115407279720254077	Account	2025-10-20 15:48:58.251744	2025-10-20 15:48:58.251744	115338428152261473	115407279720254077	admin.sign_up	f	\N
20	5	Follow	2025-10-20 15:49:27.265148	2025-10-20 15:49:27.265148	115407279078399620	115338428522805842	follow	f	follow-489159
21	6	Follow	2025-10-20 15:49:39.790153	2025-10-20 15:49:39.790153	115407279337451464	115338428522805842	follow	f	follow-489159
22	7	Follow	2025-10-20 15:49:47.454145	2025-10-20 15:49:47.454145	115407279554762986	115338428522805842	follow	f	follow-489159
23	115410778295457737	Account	2025-10-21 06:38:42.834014	2025-10-21 06:38:42.834014	115338428152261473	115410778295457737	admin.sign_up	f	\N
24	115445893227871976	Account	2025-10-27 11:28:53.275188	2025-10-27 11:28:53.275188	115338428152261473	115445893227871976	admin.sign_up	f	\N
25	2	Poll	2025-11-07 05:05:42.387238	2025-11-07 05:05:42.387238	115338428522805842	115338428522805842	poll	f	\N
26	115347680385540244	Account	2025-10-10 03:12:04.664967	2025-10-10 03:12:04.664967	115338428152261473	115347680385540244	admin.sign_up	f	\N
27	115347680582977591	Account	2025-10-10 03:12:07.258515	2025-10-10 03:12:07.258515	115338428152261473	115347680582977591	admin.sign_up	f	\N
28	115347680754305497	Account	2025-10-10 03:12:10.020291	2025-10-10 03:12:10.020291	115338428152261473	115347680754305497	admin.sign_up	f	\N
29	8	Follow	2025-10-12 06:09:33.444023	2025-10-12 06:09:33.444023	115383646696917550	115338428522805842	follow	f	follow-488958
30	9	Follow	2025-10-12 06:09:43.190987	2025-10-12 06:09:43.190987	115383709981264049	115338428522805842	follow	f	follow-488958
31	10	Follow	2025-10-12 06:09:57.251836	2025-10-12 06:09:57.251836	115410778295457737	115338428522805842	follow	f	follow-488958
32	11	Follow	2025-10-12 06:10:04.282252	2025-10-12 06:10:04.282252	115445893227871976	115338428522805842	follow	f	follow-488958
33	12	Follow	2025-10-12 06:10:11.858343	2025-10-12 06:10:11.858343	115347680385540244	115338428522805842	follow	f	follow-488958
34	13	Follow	2025-10-12 06:10:17.808502	2025-10-12 06:10:17.808502	115347680582977591	115338428522805842	follow	f	follow-488958
35	14	Follow	2025-10-12 06:10:26.454691	2025-10-12 06:10:26.454691	115347680754305497	115338428522805842	follow	f	follow-488958
58	115378678396852544	Account	2025-10-15 14:35:16.551689	2025-10-15 14:35:16.551689	115338428152261473	115378678396852544	admin.sign_up	f	\N
59	41	Follow	2025-10-15 14:32:13.270947	2025-10-15 14:32:13.270947	115378678396852544	115338428522805842	follow	f	follow-489038
\.


--
-- Data for Name: oauth_access_grants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_access_grants (id, token, expires_in, redirect_uri, created_at, revoked_at, scopes, application_id, resource_owner_id, code_challenge, code_challenge_method) FROM stdin;
18	-07uUpH4ZVow_l_cH00yGcjdb4X9W1AFAJIDYScjrjI	600	mastodon-android-auth://callback	2025-10-11 04:03:36.424901	\N	read write follow push	25	3		
19	CGkYrfwlOQEoWlbE_EYoLf6PyDEgALg8GNz5kVIYI6g	600	mastodon-android-auth://callback	2025-10-11 04:03:37.171709	2025-10-11 04:03:37.764258	read write follow push	25	3		
20	_wvhk0_r1VSFiVg72QctpaPeutleqGTj10FJL1Z0_II	600	mastodon-android-auth://callback	2025-10-27 13:36:42.301055	2025-10-27 13:36:42.627116	read write follow push	26	6		
21	1jQyJqUlg9KMYPS24n1qph26KHC73CSdrX2oNA_c_1o	600	mastodon-android-auth://callback	2025-11-07 05:06:48.786534	2025-11-07 05:06:49.199064	read write follow push	27	3		
22	wJr3GA5y4OLm12Vh795g5MmakaJw4Cbp1C1SQ7Hq-FM	600	mastodon-android-auth://callback	2025-10-10 03:01:35.110758	2025-10-10 03:01:35.231835	read write follow push	28	3		
23	BVt7bKYhyNAy6PFUwfaXeaovHSwzos3IXs-M3SgDs-0	600	mastodon-android-auth://callback	2025-10-03 03:03:03.427386	2025-10-03 03:03:03.700727	read write follow push	29	13		
24	Ccddng-vWk-O9AclkaGGlRm3ia4APDaAIV7fI3IKzU4	600	mastodon-android-auth://callback	2025-10-03 03:12:11.363051	2025-10-03 03:12:11.728359	read write follow push	30	14		
25	O2FupAYarGYqL2dtjsqMHgVQT_lD_eRbg85d7Uusao4	600	mastodon-android-auth://callback	2025-10-03 03:15:20.754073	2025-10-03 03:15:21.048183	read write follow push	31	14		
26	Gohf7EsA1OLTnxy_TnB_dDYLPHHs-1X5gsjFKqrjXLE	600	mastodon-android-auth://callback	2025-10-03 03:15:54.942572	2025-10-03 03:15:55.331174	read write follow push	32	15		
54	wPaKwN0JkO2DPOVS47r0zimN4J_9Wk_xCaiIeQb-C5c	600	mastodon-android-auth://callback	2025-11-17 06:40:22.390493	\N	read write follow push	60	3		
55	h9wy9Njf3zWl1veaWaUFLCGG1Jpww2VVd7irFcZcSsM	600	mastodon-android-auth://callback	2025-11-17 06:40:24.106176	\N	read write follow push	60	3		
56	8CNB8Q9c6J35df2TBDja2Ty7sJEmGzce2rXsiR6rwKc	600	mastodon-android-auth://callback	2025-11-17 06:40:25.546211	\N	read write follow push	60	3		
57	4rmmHXAU6MbZuAbn8XafbJKwhkPRjYrxd3uttDYvorY	600	mastodon-android-auth://callback	2025-11-17 06:40:27.770873	\N	read write follow push	60	3		
58	NZk2nsOT43DEK4iNXAiefXQsA1B7pslbsVNGNSNS8Tw	600	mastodon-android-auth://callback	2025-11-17 06:40:50.530544	2025-11-17 06:40:50.691714	read write follow push	61	3		
59	UKwOL4Y3ipYrZ7MpkeNZatYDDnwtWg-b2K9beahnz0g	600	mastodon-android-auth://callback	2025-10-15 14:32:01.062131	2025-10-15 14:32:01.867436	read write follow push	62	3		
60	NDAzzrOgaml-stbjqtMiisB_NVQWNPK7E2XqH3HN3P4	600	mastodon-android-auth://callback	2025-10-15 14:32:36.59703	2025-10-15 14:32:37.069538	read write follow push	63	9		
61	4vfelb0qrZvLb4jUaZ6pfopC9vCeN5adtiSwautFgrQ	600	mastodon-android-auth://callback	2025-10-02 14:30:27.592618	2025-10-02 14:30:27.863255	read write follow push	64	9		
62	SOSLYkY8ilcyc4K33SjBhzKptUDwnafDqsPoafhNPLs	600	mastodon-android-auth://callback	2025-10-02 14:31:26.551222	2025-10-02 14:31:26.812277	read write follow push	65	46		
63	epKw1qZo1_A9PqUrNtrAEGIy-dFzB3Fz7Jvo3jJWG44	600	mastodon-android-auth://callback	2025-10-15 14:31:54.920844	2025-10-15 14:31:55.249232	read write follow push	66	1		
64	1l_XPDlAIqh-ib37TkcLwHUHrJgpvbcZnFl8pTCT2DA	600	mastodon-android-auth://callback	2025-11-17 12:15:33.845249	2025-11-17 12:15:34.057047	read write follow push	67	1		
65	aFSVVlh8J9NKiXh9eu2jSeXyd0zn5X1PDP-WrlzzywU	600	mastodon-android-auth://callback	2025-11-17 12:16:44.161531	2025-11-17 12:16:45.136304	read write follow push	68	3		
\.


--
-- Data for Name: oauth_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_access_tokens (id, token, refresh_token, expires_in, revoked_at, created_at, scopes, application_id, resource_owner_id, last_used_at, last_used_ip) FROM stdin;
4	XdnMBAMdIq_o3LnCHgiDea2guz9eKbFnlFXQTcQs3Q4	\N	\N	\N	2025-10-08 14:50:34.977176	read write follow	1	3	\N	\N
5	KfyRrOVgHCmgaekNB4rf3vmZSGbvPE0MiT66XCHr_Yg	\N	\N	\N	2025-10-08 14:50:38.039068	read write follow push	3	3	2025-10-08 14:50:38.110345	172.18.0.1
8	KUd5rjEj-uxJB-aJqahel9iDAnulXJ9xPBRMDsozsqk	\N	\N	\N	2025-10-09 15:02:16.570667	read write follow push	4	3	2025-10-09 15:02:16.611298	172.18.0.1
10	dyfCKqqzYp6qHgP_xcwVjrdGGVw_iXA6B8uk_4J2IxI	\N	\N	\N	2025-10-10 04:33:44.994755	read write follow push	6	\N	2025-10-10 04:34:52.88592	172.18.0.1
16	zt2BIE8ER6GIqszfknXfGR6PBH_inrga3DlnYaAxKKM	\N	\N	\N	2025-10-10 05:06:43.036096	read write follow push	9	3	2025-10-10 05:06:43.112939	172.18.0.1
17	dZo0FzIhr7N90b822GQQAOqkqGcyRm2lThH1Ko3nOk0	\N	\N	\N	2025-10-13 07:22:42.415013	read write follow push	10	3	2025-10-13 07:22:42.46539	172.18.0.1
15	yQcVED-wjJL_gmFC5dEkItSxyoAP7hgSTtW8KqjGavY	\N	\N	\N	2025-10-10 05:06:41.597105	read write follow	1	3	2025-10-13 08:31:38.839778	172.18.0.1
21	8n0SMHurnOh_AZLDepa1MvJFLKy15Mi3xswaqb6UuXc	\N	\N	\N	2025-10-16 11:41:53.778382	read write follow push	17	5	2025-10-16 11:41:53.8276	172.18.0.1
23	1VZVmtcJLsB0XYAxQkHxDIU3PlXrBfMoaRCAJCq33H0	\N	\N	\N	2025-10-16 12:08:59.095815	read write follow push	18	6	2025-10-16 12:08:59.168103	172.18.0.1
24	eUNPCvxKPCC4llj1kj6Ikp7iNCE33uWsRkXZDKiWJWY	\N	\N	\N	2025-10-16 12:31:09.552014	read write follow	1	3	\N	\N
25	jN8y14Wgl1FqhV4p_d9ND09PjclN2LMRmAeD6ziLBKw	\N	\N	\N	2025-10-16 12:31:11.14231	read write follow push	19	3	2025-10-16 12:31:11.220647	172.18.0.1
27	sSWqi3JADawLxPuPFxeeBY0G1-P_xjZlQzbfhHLwZ_k	\N	\N	\N	2025-10-19 17:50:38.03795	read write follow push	20	3	2025-10-19 17:50:38.097902	172.18.0.1
31	BBE1EfHts53joL1lpAB7ZNM94sD8pE8PBTToM1la5xI	\N	\N	\N	2025-10-21 06:57:12.462875	read write follow	1	3	2025-10-21 06:57:30.286028	172.18.0.1
35	pACTjyAznW5FSQS50_usKZffeEho7pYq54TrszvLXco	\N	\N	2025-10-11 04:03:12.208986	2025-10-01 02:31:00.953141	read write follow push	24	12	2025-10-11 04:00:01.754849	172.18.0.1
37	Trkpb8Gf2iLOzYgQE3n53uqOIkk6rOiNP_ZhuXYZV08	\N	\N	\N	2025-10-11 04:03:37.773637	read write follow push	25	3	2025-10-27 13:35:08.622924	172.18.0.1
38	d0H-kvTcuZztYrOB4XRJmS6kDUrghnayz9lT5mBeNSI	\N	\N	\N	2025-10-27 13:36:40.213817	read write follow	1	6	\N	\N
43	u4_JEWDtgWDOnxPfpMqOJjc69_tMe6FW5FVmSw5Fnfw	\N	\N	\N	2025-10-10 03:01:35.235071	read write follow push	28	3	2025-10-12 06:03:15.871445	172.18.0.1
39	qXzlCGRG0sW1BqR4ihrjrezPjDs-23Yh_Ek5rrV9EjU	\N	\N	2025-10-27 13:38:07.002188	2025-10-27 13:36:42.666093	read write follow push	26	6	2025-10-27 13:36:42.90489	172.18.0.1
45	askGcH8I9cmZgz2DYvPkw-1eqk3FhiapI7jvdH8IRFk	\N	\N	2025-10-12 06:11:55.958069	2025-10-03 03:03:03.710135	read write follow push	29	13	2025-10-12 06:00:08.574163	172.18.0.1
42	_4E3P59f9sSVtpw_9BHnGAoRjwPqNddT4g5_-CEsukI	\N	\N	2025-10-10 03:01:00.749512	2025-11-07 05:06:49.209278	read write follow push	27	3	2025-11-07 05:06:49.279951	172.18.0.1
50	OQJEyBOAK4TaNEiTglI7H9xZuI_XttJ9uwCAtilNp0s	\N	\N	2025-10-12 06:12:00.44295	2025-10-03 03:15:55.332792	read write follow push	32	15	2025-10-12 06:01:51.665084	172.18.0.1
47	Gu-F8YmHiKSksRHfJ67WQRLmRs9A29xJNuCouyzd5pY	\N	\N	\N	2025-10-03 03:12:11.731517	read write follow push	30	14	2025-10-03 03:12:12.090264	172.18.0.1
48	F9koKqE7fcJfOPr3nrpkNwf0Z2zHDgIDzEJolLc4QAI	\N	\N	2025-10-12 06:12:04.520493	2025-10-03 03:15:21.050511	read write follow push	31	14	2025-10-12 06:00:06.567403	172.18.0.1
49	mDF6396zY7U5BAW96qZNzxM_EuJVCZRCcs85U96R5ts	\N	\N	\N	2025-10-03 03:15:53.434234	read write follow	1	15	\N	\N
74	RLL1pO3S1mH3Rme6ET3Pfa1vxdQ3wBOs-w96FAdTA_s	\N	\N	\N	2025-11-17 06:40:50.760821	read write follow push	61	3	2025-11-17 06:40:50.816239	172.18.0.1
75	6hEc-TIQyIQ9OyEqhLk1EucInfoY-yIUbCPzRtvW6FY	\N	\N	\N	2025-10-15 14:32:01.876113	read write follow push	62	3	2025-10-15 14:32:01.927328	172.18.0.1
80	vcljf5MyMy_Peri7dWRyTjNP9FkvCtQvq1luXiLypqY	\N	\N	2025-10-15 14:31:18.89071	2025-10-02 14:31:26.816348	read write follow push	65	46	2025-10-15 14:30:04.648191	172.18.0.1
77	lNKiqawjhwK-BS5cgf6TFlJmpY6cv09QwgDrrVT_HEI	\N	\N	2025-10-02 14:30:11.317284	2025-10-15 14:32:37.076044	read write follow push	63	9	2025-10-15 14:32:37.132745	172.18.0.1
78	lsVCfecu1cT6Wa4CPwN2NL8inCP5vJ5WKRpXFBKJ88A	\N	\N	2025-10-15 14:31:30.655058	2025-10-02 14:30:27.872986	read write follow push	64	9	2025-10-02 14:30:27.960966	172.18.0.1
81	gD01EcQf1nze0WKkUyfKW6UOW4Wl_QvtXfRkfapQmsw	\N	\N	\N	2025-10-15 14:31:53.85966	read write follow	1	1	\N	\N
82	onhN8bHZDuXbyJ6PrY15Q64KWaY53PAQocPna5jtM2E	\N	\N	\N	2025-10-15 14:31:55.252404	read write follow push	66	1	2025-10-15 14:31:55.329927	172.18.0.1
84	wAID43o7DkVPso1z92AotURMulBFC18zb2AeeHln8jI	\N	\N	\N	2025-11-17 12:15:34.076391	read write follow push	67	1	2025-11-17 12:15:34.136464	172.18.0.1
85	oZtxP-ji3yXNXAH4J7l2NGJm_RKEhwPeofIvj2Eqi-I	\N	\N	\N	2025-11-17 12:15:53.929212	read write follow	1	3	\N	\N
86	N9sMiKlgDZfeVAEzli1nGafXV2miMYqRHAzDfFgdD_w	\N	\N	\N	2025-11-17 12:16:45.142598	read write follow push	68	3	2025-11-17 12:16:45.197469	172.18.0.1
\.


--
-- Data for Name: oauth_applications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_applications (id, name, uid, secret, redirect_uri, scopes, created_at, updated_at, superapp, website, owner_type, owner_id, confidential) FROM stdin;
1	Web	JQKHMYAO0J0-dmQYj3d7v40pIOwRlVPsbwOE1X-yeW0	AcabQTRCPyrdECQmx9OFJkSgDKyb1UBpP2FxU9NkjdI	urn:ietf:wg:oauth:2.0:oob	read write follow push	2025-10-08 11:57:24.623088	2025-10-08 11:57:24.623088	t	\N	\N	\N	t
2	Mastodon for Android	R-RFR7UR6w_Uf0UguyRg2TQYsIAQlRNetzsTErSY3CY	T_44TJGIshHKDNNmJQnKJJqSyzEh5F6sU5V2cM1AQws	mastodon-android-auth://callback	read write follow push	2025-10-08 14:19:55.69729	2025-10-08 14:19:55.69729	f	https://app.joinmastodon.org/android	\N	\N	t
3	Mastodon for Android	u0nvU7mLmg7f4FwC77fSm-7kH2g4t8Ms8Ya_W11gw34	AQ3jgfx4iWSNcgSCCQyxvvjxUImeg8G7B5bf33ALswk	mastodon-android-auth://callback	read write follow push	2025-10-08 14:50:12.993094	2025-10-08 14:50:12.993094	f	https://app.joinmastodon.org/android	\N	\N	t
4	Mastodon for Android	kToJNu1fh48fRA5_OBw6PCcx0FFJIJD9p26MDqx6uGo	NVJn_vBFIfIHsRbmqRnpF5xdARd4XFHgzAwQjq2oUY0	mastodon-android-auth://callback	read write follow push	2025-10-09 15:02:13.397761	2025-10-09 15:02:13.397761	f	https://app.joinmastodon.org/android	\N	\N	t
5	Mastodon for Android	4Lzq0nwroWCgsm-HRHbpB5aZcdIQm1A8McZPDRU03zU	q4O2BhsPFh2SYo7jmEuD6toq3q_JV8kyycTycP1sA14	mastodon-android-auth://callback	read write follow push	2025-10-10 03:46:18.574418	2025-10-10 03:46:18.574418	f	https://app.joinmastodon.org/android	\N	\N	t
6	Mastodon for Android	04myrOo_h6WLO9rVrqjELGXtpc1LPAOKB2cUphEqmb8	lSzKU42Q1X0UG0z87C6ARpzSsfRtoG8aVVkhCHmO_Ko	mastodon-android-auth://callback	read write follow push	2025-10-10 04:33:44.914823	2025-10-10 04:33:44.914823	f	https://app.joinmastodon.org/android	\N	\N	t
7	Mastodon for Android	d0cNqSRnKGmbn3sN6kuoSIkyFSDFhXeBcsay__1-7fw	3sng5HKOtCIkWBfPp_5QpMDU6o4AKfLDJihLK_cMQLI	mastodon-android-auth://callback	read write follow push	2025-10-10 04:45:00.542319	2025-10-10 04:45:00.542319	f	https://app.joinmastodon.org/android	\N	\N	t
8	Mastodon for Android	h2cAcFI5YCdyle9eSiBLGECRRi7J4DUADJsEMox9S0I	rXnwAHFGq_CVTH5yWAbUcQNTUgHsiIXN4GQHsmQdHrQ	mastodon-android-auth://callback	read write follow push	2025-10-10 04:47:52.825788	2025-10-10 04:47:52.825788	f	https://app.joinmastodon.org/android	\N	\N	t
9	Mastodon for Android	wh6Uh8mb97eSu7yiE2eiI7iJcBTS7Z8OohUkbwKfOAw	YUMWgJGITkPdFupTpkZ4khUH14AFVZP2I76tWd8dkCw	mastodon-android-auth://callback	read write follow push	2025-10-10 05:06:32.736935	2025-10-10 05:06:32.736935	f	https://app.joinmastodon.org/android	\N	\N	t
10	Mastodon for Android	WwSQDRuIph14IFWh3hss-4OlyNIBh-slMkZqSO3bTUc	hqYHBoTR8dILMqHZUA_VBXBiv1kS-B_RSC50UZlUe74	mastodon-android-auth://callback	read write follow push	2025-10-13 07:22:37.874731	2025-10-13 07:22:37.874731	f	https://app.joinmastodon.org/android	\N	\N	t
11	Mastodon for Android	dBWQg7_2UPG948ww1uK9Gt7lGATt0m6H3H5Q2fEnY0s	Sgm5ZwEQsUETVIRBxhQhfrHCKPx3lS8WSHIAxLNMluM	mastodon-android-auth://callback	read write follow push	2025-10-16 08:11:27.222165	2025-10-16 08:11:27.222165	f	https://app.joinmastodon.org/android	\N	\N	t
12	Mastodon for Android	5JH_qSB0QZnTySQto16-utZ9b8Uk3H1bItkLYBjyoNw	CG833O8W7Au_-h8wZ1VQIkM6gKSMu15IesVTq7HATW4	mastodon-android-auth://callback	read write follow push	2025-10-16 08:11:40.412004	2025-10-16 08:11:40.412004	f	https://app.joinmastodon.org/android	\N	\N	t
13	Mastodon for Android	TCaLeygGzQ0_gQrmrV5ya4u2LqiXTHqBEEa42fjO1CE	RxNux3ZHbF7p90FcRKAAlrZq00miNh75dKB5FKxp0tc	mastodon-android-auth://callback	read write follow push	2025-10-16 08:11:49.628593	2025-10-16 08:11:49.628593	f	https://app.joinmastodon.org/android	\N	\N	t
14	Mastodon for Android	J3-CHh6AKnIZNEbt5Hz5XFLNeTGeW_cgTIpwMztj7k8	A38KUslaSD42C_s76hsKpOQ-WkIgPcXMyl-OqVzp5-M	mastodon-android-auth://callback	read write follow push	2025-10-16 08:12:04.901685	2025-10-16 08:12:04.901685	f	https://app.joinmastodon.org/android	\N	\N	t
15	Mastodon for Android	_QPnigQn6Y5dVwujJv2Qj9-O2qH-mW1Cz6C4DOq_g44	iKA5VU3zuGSijCdnfKzUtF92Klb0rTM2KfyiYbZkRgg	mastodon-android-auth://callback	read write follow push	2025-10-16 08:12:20.256833	2025-10-16 08:12:20.256833	f	https://app.joinmastodon.org/android	\N	\N	t
16	Mastodon for Android	hvlu3Acebqe_I5ZbO1MPE8ZNAqtKeaaNVYUraPM4ZWA	wH1xPGtI5MN3pwTxH8MNg4UUgLWj-FL-Q06aGhJofrk	mastodon-android-auth://callback	read write follow push	2025-10-16 08:22:41.267951	2025-10-16 08:22:41.267951	f	https://app.joinmastodon.org/android	\N	\N	t
17	Mastodon for Android	-RmybjWaBz8w4kOyGObgT4DZYkDyLfyP2KsagCObPv0	VtK6UuMgGZwTOFAKDcKoJUVvvWKLv_bRPMHJLsf49s8	mastodon-android-auth://callback	read write follow push	2025-10-16 11:40:49.751595	2025-10-16 11:40:49.751595	f	https://app.joinmastodon.org/android	\N	\N	t
18	Mastodon for Android	aQnxFLo6g_lkdLBV5QwRe2_5CGMqeCA-zRpBWvkzSAQ	Ajn2qMcTPPiB09vAFci1QU4tLqCb0wbHfl9v_Raxvp0	mastodon-android-auth://callback	read write follow push	2025-10-16 12:08:37.941544	2025-10-16 12:08:37.941544	f	https://app.joinmastodon.org/android	\N	\N	t
19	Mastodon for Android	89kEQSKJU5A6X23YFZyVUG0rHTae1aEd8rtj6scTcBY	hInOHMd5clYAKrBAGH0r2i2L8PbLOBgttccyrCPUWng	mastodon-android-auth://callback	read write follow push	2025-10-16 12:30:55.287102	2025-10-16 12:30:55.287102	f	https://app.joinmastodon.org/android	\N	\N	t
20	Mastodon for Android	qw5DYyhULcgi7iEM8ap5cx-LqjWOQ3srpLywyFeo0E8	W99cRmiwUiEqTOqhIBvgsWY4OCNsnxs4hcDysfxQ55E	mastodon-android-auth://callback	read write follow push	2025-10-19 17:50:22.030467	2025-10-19 17:50:22.030467	f	https://app.joinmastodon.org/android	\N	\N	t
21	Mastodon for Android	mm4rmwG2L_xUDSf3iWhd52fxSqrTENZmJjOBS5qzBqw	ObAAmG5jVs515jQoHeOvVvZ-m5NgasKM6vluDReT_zo	mastodon-android-auth://callback	read write follow push	2025-10-20 08:18:24.912506	2025-10-20 08:18:24.912506	f	https://app.joinmastodon.org/android	\N	\N	t
22	Mastodon for Android	rAqf8gQdP7JMPjr1BVVLk6x-5oiA2FWEykNhktyFLtc	be_h0filiLzYru5f6dLD7jIyGyPAOjeYpY0QLRiqQgs	mastodon-android-auth://callback	read write follow push	2025-10-21 06:39:46.443179	2025-10-21 06:39:46.443179	f	https://app.joinmastodon.org/android	\N	\N	t
23	Mastodon for Android	0OnZmb-hJ4H9nX5IqIh0VeyJCXGIMz_4QpwxOcRjm04	QBTWxTpiPSTC2FWC3k9KgqdT5fyYYNo0HTyKszRE_b4	mastodon-android-auth://callback	read write follow push	2025-10-21 06:57:02.808682	2025-10-21 06:57:02.808682	f	https://app.joinmastodon.org/android	\N	\N	t
24	Mastodon for Android	slH3SPgQ_saeUeLzuakRz754bQYA1erxQXiI05-nsEA	NgpEUzNRQQ1OXL3ufDzzZZMQJhIQtBnmVtTaXosGLHU	mastodon-android-auth://callback	read write follow push	2025-10-01 02:30:39.159635	2025-10-01 02:30:39.159635	f	https://app.joinmastodon.org/android	\N	\N	t
25	Mastodon for Android	_wozojv7YxnTlCP4KM7P3yzxMDx3V4nlQ9hnwBYvsz8	PzVe8658tgzCOwR0ofmoCObWw3gFCLDEHG0oFxV5VMc	mastodon-android-auth://callback	read write follow push	2025-10-11 04:03:24.838831	2025-10-11 04:03:24.838831	f	https://app.joinmastodon.org/android	\N	\N	t
26	Mastodon for Android	jt95KZcM9O5WyU2cQPRImL15qF8gwWqRvAsWzJjco88	RJp4k8BjYXFc5tJANVOz-FuJz1-C_bpsprLEgsb0yeQ	mastodon-android-auth://callback	read write follow push	2025-10-27 13:35:30.76794	2025-10-27 13:35:30.76794	f	https://app.joinmastodon.org/android	\N	\N	t
27	Mastodon for Android	2lS-86HGQKq6GBhbJ9Dc6IYHwfulhXNgmPuig7oj6bw	o6FafO7tiehBb3ghZlMb26DF0ndlBlAVaaaifyK7k-w	mastodon-android-auth://callback	read write follow push	2025-11-07 05:06:30.247397	2025-11-07 05:06:30.247397	f	https://app.joinmastodon.org/android	\N	\N	t
28	Mastodon for Android	CiVj48JCkueDllycw8JrYZeYLB56eQdDNiYb-_HTFq0	FnLZS-6Ibbah_HzyTo16gGFKy8lgIm3x-4871mxDE9I	mastodon-android-auth://callback	read write follow push	2025-10-10 03:01:32.961869	2025-10-10 03:01:32.961869	f	https://app.joinmastodon.org/android	\N	\N	t
29	Mastodon for Android	hewwKOJ-AQyw2lnxaqOf2PeGCgbeonzPPKCWSfGQQTE	WHV1enYrXC9QxOnp4KK8qS8oY4tN8trZmZ5982G55YE	mastodon-android-auth://callback	read write follow push	2025-10-03 03:00:31.973345	2025-10-03 03:00:31.973345	f	https://app.joinmastodon.org/android	\N	\N	t
30	Mastodon for Android	m88fcYqSn7r2p1mdIdmXBxzWcqmhodkF9NhLyqOR2X8	VsVStJyldkj7YalCqhE2EdcoWgVvIj2i3QZHZQnGalM	mastodon-android-auth://callback	read write follow push	2025-10-03 03:08:09.64899	2025-10-03 03:08:09.64899	f	https://app.joinmastodon.org/android	\N	\N	t
31	Mastodon for Android	Mkkm-kaoeKEqer54zjN1zdmD-RkXIoddllU8zno6oVY	lygVM-v48KR_12UwXo6z284VUfiB-xhLyagSqsCyBRI	mastodon-android-auth://callback	read write follow push	2025-10-03 03:15:18.107435	2025-10-03 03:15:18.107435	f	https://app.joinmastodon.org/android	\N	\N	t
32	Mastodon for Android	1C_cs7tsL9UAmLkSRIlaLu6THPYiNKp88RF2MIAlfhE	CoxrXObsIqbUr-WHxzpxkDH0pBXVBwXhPa4UYOWTyqw	mastodon-android-auth://callback	read write follow push	2025-10-03 03:15:35.516958	2025-10-03 03:15:35.516958	f	https://app.joinmastodon.org/android	\N	\N	t
60	Mastodon for Android	kWOgJLYVvgpqBxe2xGvBOX-eScf8uZer81kiI_eKREw	X8-PyfTjvt0LUCnLTADlbl1gUv2oyueU8dPIzCRvJNw	mastodon-android-auth://callback	read write follow push	2025-11-17 06:40:08.275668	2025-11-17 06:40:08.275668	f	https://app.joinmastodon.org/android	\N	\N	t
61	Mastodon for Android	TQngfNemU-qPogrbrXBOeEgLCGMBjgw3HH2_Ebd4XYw	tcBf2eTERDXQQdwIu3d00sm7FhqVFtSehDzUhGZGIW0	mastodon-android-auth://callback	read write follow push	2025-11-17 06:40:47.563886	2025-11-17 06:40:47.563886	f	https://app.joinmastodon.org/android	\N	\N	t
62	Mastodon for Android	rIzZ21u7DtEFI0A003HpjBbxwrw6oUkcJ6d1PF1cANE	It0ZVqnBM6XA19kMKjzuycELTlHeMPJy2zj_cjC2MMU	mastodon-android-auth://callback	read write follow push	2025-10-15 14:31:57.619904	2025-10-15 14:31:57.619904	f	https://app.joinmastodon.org/android	\N	\N	t
63	Mastodon for Android	7kQ8d6z7W2bqq18Y_NWpUFreXg8a36An3CRuq7bTN8g	OI60AmTikte5X9Q95R0INt8wL8Hr3eULBMMXj8IAECA	mastodon-android-auth://callback	read write follow push	2025-10-15 14:32:19.231796	2025-10-15 14:32:19.231796	f	https://app.joinmastodon.org/android	\N	\N	t
64	Mastodon for Android	2T-4CDCgszOdL3D0LroT6H9M9Gl7J0sasgsGb_HqoXY	1HlkQR26kY-W1Hl-adqmBjHH_1vMAsS79Zf494k4zEY	mastodon-android-auth://callback	read write follow push	2025-10-02 14:30:25.342618	2025-10-02 14:30:25.342618	f	https://app.joinmastodon.org/android	\N	\N	t
65	Mastodon for Android	iXormGhy8sdLZj6YVPRYZRdfWk3g32FTf9MMlxyRuj4	8wXOfTa14CK9sYf3dhGC-B2dk6mv7BU-Z1ZhGrBfXWw	mastodon-android-auth://callback	read write follow push	2025-10-02 14:30:41.610162	2025-10-02 14:30:41.610162	f	https://app.joinmastodon.org/android	\N	\N	t
66	Mastodon for Android	rp1eyTWRND98BbxvDKdOnGAFUhEWDjE12PoWS4goIjM	L30pWqKMpsTMRx3cMLn3AdHM_13GDO9-hfN7AFa-dXc	mastodon-android-auth://callback	read write follow push	2025-10-15 14:31:42.486175	2025-10-15 14:31:42.486175	f	https://app.joinmastodon.org/android	\N	\N	t
67	Mastodon for Android	qBm8S4TyS7PWwSU-ChjLnx-pL_EwXl1ga3PRpVmTNlI	Qw7xoiLioX1gBfDrBobY6RRMke3vfAYyIi21BszSNPI	mastodon-android-auth://callback	read write follow push	2025-11-17 12:15:15.750926	2025-11-17 12:15:15.750926	f	https://app.joinmastodon.org/android	\N	\N	t
68	Mastodon for Android	54kb68obVIMKqI9rUlCkgjoHcMFzyT7PJs8_GFuIwJ8	IeprythIhFGO19JPTFumQsDsIIdOj50ZY5W545m72Vo	mastodon-android-auth://callback	read write follow push	2025-11-17 12:16:40.64452	2025-11-17 12:16:40.64452	f	https://app.joinmastodon.org/android	\N	\N	t
\.


--
-- Data for Name: pghero_space_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pghero_space_stats (id, database, schema, relation, size, captured_at) FROM stdin;
1	primary	public	accounts	65536	2025-10-14 00:00:00.3147
2	primary	public	schema_migrations	57344	2025-10-14 00:00:00.3147
3	primary	public	schema_migrations_pkey	32768	2025-10-14 00:00:00.3147
4	primary	public	search_index	24576	2025-10-14 00:00:00.3147
5	primary	public	account_stats_pkey	16384	2025-10-14 00:00:00.3147
6	primary	public	accounts_pkey	16384	2025-10-14 00:00:00.3147
7	primary	public	ar_internal_metadata	16384	2025-10-14 00:00:00.3147
8	primary	public	ar_internal_metadata_pkey	16384	2025-10-14 00:00:00.3147
9	primary	public	blocks	16384	2025-10-14 00:00:00.3147
10	primary	public	blocks_pkey	16384	2025-10-14 00:00:00.3147
11	primary	public	bookmarks_pkey	16384	2025-10-14 00:00:00.3147
12	primary	public	conversations	16384	2025-10-14 00:00:00.3147
13	primary	public	conversations_pkey	16384	2025-10-14 00:00:00.3147
14	primary	public	custom_filter_keywords	16384	2025-10-14 00:00:00.3147
15	primary	public	custom_filter_keywords_pkey	16384	2025-10-14 00:00:00.3147
16	primary	public	custom_filters	16384	2025-10-14 00:00:00.3147
17	primary	public	custom_filters_pkey	16384	2025-10-14 00:00:00.3147
18	primary	public	favourites_pkey	16384	2025-10-14 00:00:00.3147
19	primary	public	follows	16384	2025-10-14 00:00:00.3147
20	primary	public	follows_pkey	16384	2025-10-14 00:00:00.3147
21	primary	public	index_account_stats_on_account_id	16384	2025-10-14 00:00:00.3147
22	primary	public	index_account_stats_on_last_status_at_and_account_id	16384	2025-10-14 00:00:00.3147
23	primary	public	index_accounts_on_domain_and_id	16384	2025-10-14 00:00:00.3147
24	primary	public	index_accounts_on_uri	16384	2025-10-14 00:00:00.3147
25	primary	public	index_accounts_on_username_and_domain_lower	16384	2025-10-14 00:00:00.3147
26	primary	public	index_blocks_on_account_id_and_target_account_id	16384	2025-10-14 00:00:00.3147
27	primary	public	index_blocks_on_target_account_id	16384	2025-10-14 00:00:00.3147
28	primary	public	index_bookmarks_on_account_id_and_status_id	16384	2025-10-14 00:00:00.3147
29	primary	public	index_bookmarks_on_status_id	16384	2025-10-14 00:00:00.3147
30	primary	public	index_custom_filter_keywords_on_custom_filter_id	16384	2025-10-14 00:00:00.3147
31	primary	public	index_custom_filters_on_account_id	16384	2025-10-14 00:00:00.3147
32	primary	public	index_favourites_on_account_id_and_id	16384	2025-10-14 00:00:00.3147
33	primary	public	index_favourites_on_account_id_and_status_id	16384	2025-10-14 00:00:00.3147
34	primary	public	index_favourites_on_status_id	16384	2025-10-14 00:00:00.3147
35	primary	public	index_follows_on_account_id_and_target_account_id	16384	2025-10-14 00:00:00.3147
36	primary	public	index_follows_on_target_account_id	16384	2025-10-14 00:00:00.3147
37	primary	public	index_invites_on_code	16384	2025-10-14 00:00:00.3147
38	primary	public	index_invites_on_user_id	16384	2025-10-14 00:00:00.3147
39	primary	public	index_list_accounts_on_account_id_and_list_id	16384	2025-10-14 00:00:00.3147
40	primary	public	index_list_accounts_on_follow_id	16384	2025-10-14 00:00:00.3147
41	primary	public	index_list_accounts_on_list_id_and_account_id	16384	2025-10-14 00:00:00.3147
42	primary	public	index_lists_on_account_id	16384	2025-10-14 00:00:00.3147
43	primary	public	index_login_activities_on_user_id	16384	2025-10-14 00:00:00.3147
44	primary	public	index_markers_on_user_id_and_timeline	16384	2025-10-14 00:00:00.3147
45	primary	public	index_media_attachments_on_account_id_and_status_id	16384	2025-10-14 00:00:00.3147
46	primary	public	index_media_attachments_on_status_id	16384	2025-10-14 00:00:00.3147
47	primary	public	index_mentions_on_account_id_and_status_id	16384	2025-10-14 00:00:00.3147
48	primary	public	index_mentions_on_status_id	16384	2025-10-14 00:00:00.3147
49	primary	public	index_mutes_on_account_id_and_target_account_id	16384	2025-10-14 00:00:00.3147
50	primary	public	index_mutes_on_target_account_id	16384	2025-10-14 00:00:00.3147
51	primary	public	index_notification_policies_on_account_id	16384	2025-10-14 00:00:00.3147
52	primary	public	index_notifications_on_account_id_and_group_key	16384	2025-10-14 00:00:00.3147
53	primary	public	index_notifications_on_account_id_and_id_and_type	16384	2025-10-14 00:00:00.3147
54	primary	public	index_notifications_on_activity_id_and_activity_type	16384	2025-10-14 00:00:00.3147
55	primary	public	index_notifications_on_filtered	16384	2025-10-14 00:00:00.3147
56	primary	public	index_notifications_on_from_account_id	16384	2025-10-14 00:00:00.3147
57	primary	public	index_oauth_access_grants_on_resource_owner_id	16384	2025-10-14 00:00:00.3147
58	primary	public	index_oauth_access_grants_on_token	16384	2025-10-14 00:00:00.3147
59	primary	public	index_oauth_access_tokens_on_resource_owner_id	16384	2025-10-14 00:00:00.3147
60	primary	public	index_oauth_access_tokens_on_token	16384	2025-10-14 00:00:00.3147
61	primary	public	index_oauth_applications_on_owner_id_and_owner_type	16384	2025-10-14 00:00:00.3147
62	primary	public	index_oauth_applications_on_superapp	16384	2025-10-14 00:00:00.3147
63	primary	public	index_oauth_applications_on_uid	16384	2025-10-14 00:00:00.3147
64	primary	public	index_poll_votes_on_account_id	16384	2025-10-14 00:00:00.3147
65	primary	public	index_poll_votes_on_poll_id	16384	2025-10-14 00:00:00.3147
66	primary	public	index_polls_on_account_id	16384	2025-10-14 00:00:00.3147
67	primary	public	index_polls_on_status_id	16384	2025-10-14 00:00:00.3147
68	primary	public	index_reports_on_account_id	16384	2025-10-14 00:00:00.3147
69	primary	public	index_reports_on_target_account_id	16384	2025-10-14 00:00:00.3147
70	primary	public	index_session_activations_on_access_token_id	16384	2025-10-14 00:00:00.3147
71	primary	public	index_session_activations_on_session_id	16384	2025-10-14 00:00:00.3147
72	primary	public	index_session_activations_on_user_id	16384	2025-10-14 00:00:00.3147
73	primary	public	index_status_stats_on_status_id	16384	2025-10-14 00:00:00.3147
74	primary	public	index_statuses_20190820	16384	2025-10-14 00:00:00.3147
75	primary	public	index_statuses_local_20190824	16384	2025-10-14 00:00:00.3147
76	primary	public	index_statuses_on_account_id	16384	2025-10-14 00:00:00.3147
77	primary	public	index_statuses_on_deleted_at	16384	2025-10-14 00:00:00.3147
78	primary	public	index_statuses_on_in_reply_to_account_id	16384	2025-10-14 00:00:00.3147
79	primary	public	index_statuses_on_in_reply_to_id	16384	2025-10-14 00:00:00.3147
80	primary	public	index_statuses_on_reblog_of_id_and_account_id	16384	2025-10-14 00:00:00.3147
81	primary	public	index_statuses_on_uri	16384	2025-10-14 00:00:00.3147
82	primary	public	index_statuses_public_20200119	16384	2025-10-14 00:00:00.3147
83	primary	public	index_statuses_tags_on_status_id	16384	2025-10-14 00:00:00.3147
84	primary	public	index_tag_follows_on_account_id_and_tag_id	16384	2025-10-14 00:00:00.3147
85	primary	public	index_tag_follows_on_tag_id	16384	2025-10-14 00:00:00.3147
86	primary	public	index_tags_on_name_lower_btree	16384	2025-10-14 00:00:00.3147
87	primary	public	index_users_on_account_id	16384	2025-10-14 00:00:00.3147
88	primary	public	index_users_on_confirmation_token	16384	2025-10-14 00:00:00.3147
89	primary	public	index_users_on_created_by_application_id	16384	2025-10-14 00:00:00.3147
90	primary	public	index_users_on_email	16384	2025-10-14 00:00:00.3147
91	primary	public	index_users_on_role_id	16384	2025-10-14 00:00:00.3147
92	primary	public	index_web_settings_on_user_id	16384	2025-10-14 00:00:00.3147
93	primary	public	invites	16384	2025-10-14 00:00:00.3147
94	primary	public	invites_pkey	16384	2025-10-14 00:00:00.3147
95	primary	public	list_accounts_pkey	16384	2025-10-14 00:00:00.3147
96	primary	public	lists	16384	2025-10-14 00:00:00.3147
97	primary	public	lists_pkey	16384	2025-10-14 00:00:00.3147
98	primary	public	login_activities	16384	2025-10-14 00:00:00.3147
99	primary	public	login_activities_pkey	16384	2025-10-14 00:00:00.3147
100	primary	public	markers	16384	2025-10-14 00:00:00.3147
101	primary	public	markers_pkey	16384	2025-10-14 00:00:00.3147
102	primary	public	media_attachments	16384	2025-10-14 00:00:00.3147
103	primary	public	media_attachments_pkey	16384	2025-10-14 00:00:00.3147
104	primary	public	mentions_pkey	16384	2025-10-14 00:00:00.3147
105	primary	public	mutes_pkey	16384	2025-10-14 00:00:00.3147
106	primary	public	notification_policies_pkey	16384	2025-10-14 00:00:00.3147
107	primary	public	notifications	16384	2025-10-14 00:00:00.3147
108	primary	public	notifications_pkey	16384	2025-10-14 00:00:00.3147
109	primary	public	oauth_access_grants	16384	2025-10-14 00:00:00.3147
110	primary	public	oauth_access_grants_pkey	16384	2025-10-14 00:00:00.3147
111	primary	public	oauth_access_tokens	16384	2025-10-14 00:00:00.3147
112	primary	public	oauth_access_tokens_pkey	16384	2025-10-14 00:00:00.3147
113	primary	public	oauth_applications	16384	2025-10-14 00:00:00.3147
114	primary	public	oauth_applications_pkey	16384	2025-10-14 00:00:00.3147
115	primary	public	poll_votes	16384	2025-10-14 00:00:00.3147
116	primary	public	poll_votes_pkey	16384	2025-10-14 00:00:00.3147
117	primary	public	polls	16384	2025-10-14 00:00:00.3147
118	primary	public	polls_pkey	16384	2025-10-14 00:00:00.3147
119	primary	public	reports	16384	2025-10-14 00:00:00.3147
120	primary	public	reports_pkey	16384	2025-10-14 00:00:00.3147
121	primary	public	session_activations	16384	2025-10-14 00:00:00.3147
122	primary	public	session_activations_pkey	16384	2025-10-14 00:00:00.3147
123	primary	public	status_stats_pkey	16384	2025-10-14 00:00:00.3147
124	primary	public	statuses	16384	2025-10-14 00:00:00.3147
125	primary	public	statuses_pkey	16384	2025-10-14 00:00:00.3147
126	primary	public	statuses_tags_pkey	16384	2025-10-14 00:00:00.3147
127	primary	public	tag_follows_pkey	16384	2025-10-14 00:00:00.3147
128	primary	public	tags	16384	2025-10-14 00:00:00.3147
129	primary	public	tags_pkey	16384	2025-10-14 00:00:00.3147
130	primary	public	user_roles	16384	2025-10-14 00:00:00.3147
131	primary	public	user_roles_pkey	16384	2025-10-14 00:00:00.3147
132	primary	public	users	16384	2025-10-14 00:00:00.3147
133	primary	public	users_pkey	16384	2025-10-14 00:00:00.3147
134	primary	public	web_settings	16384	2025-10-14 00:00:00.3147
135	primary	public	web_settings_pkey	16384	2025-10-14 00:00:00.3147
136	primary	public	account_aliases	8192	2025-10-14 00:00:00.3147
137	primary	public	account_aliases_pkey	8192	2025-10-14 00:00:00.3147
138	primary	public	account_conversations	8192	2025-10-14 00:00:00.3147
139	primary	public	account_conversations_pkey	8192	2025-10-14 00:00:00.3147
140	primary	public	account_deletion_requests_pkey	8192	2025-10-14 00:00:00.3147
141	primary	public	account_domain_blocks	8192	2025-10-14 00:00:00.3147
142	primary	public	account_domain_blocks_pkey	8192	2025-10-14 00:00:00.3147
143	primary	public	account_migrations	8192	2025-10-14 00:00:00.3147
144	primary	public	account_migrations_pkey	8192	2025-10-14 00:00:00.3147
145	primary	public	account_moderation_notes	8192	2025-10-14 00:00:00.3147
146	primary	public	account_moderation_notes_pkey	8192	2025-10-14 00:00:00.3147
147	primary	public	account_notes	8192	2025-10-14 00:00:00.3147
148	primary	public	account_notes_pkey	8192	2025-10-14 00:00:00.3147
149	primary	public	account_pins_pkey	8192	2025-10-14 00:00:00.3147
150	primary	public	account_relationship_severance_events_pkey	8192	2025-10-14 00:00:00.3147
151	primary	public	account_stats	8192	2025-10-14 00:00:00.3147
152	primary	public	account_statuses_cleanup_policies_pkey	8192	2025-10-14 00:00:00.3147
153	primary	public	account_summaries	8192	2025-10-14 00:00:00.3147
154	primary	public	account_warning_presets	8192	2025-10-14 00:00:00.3147
155	primary	public	account_warning_presets_pkey	8192	2025-10-14 00:00:00.3147
156	primary	public	account_warnings	8192	2025-10-14 00:00:00.3147
157	primary	public	account_warnings_pkey	8192	2025-10-14 00:00:00.3147
158	primary	public	accounts_tags_pkey	8192	2025-10-14 00:00:00.3147
159	primary	public	admin_action_logs	8192	2025-10-14 00:00:00.3147
160	primary	public	admin_action_logs_pkey	8192	2025-10-14 00:00:00.3147
161	primary	public	announcement_mutes_pkey	8192	2025-10-14 00:00:00.3147
162	primary	public	announcement_reactions	8192	2025-10-14 00:00:00.3147
163	primary	public	announcement_reactions_pkey	8192	2025-10-14 00:00:00.3147
164	primary	public	announcements	8192	2025-10-14 00:00:00.3147
165	primary	public	announcements_pkey	8192	2025-10-14 00:00:00.3147
166	primary	public	appeals	8192	2025-10-14 00:00:00.3147
167	primary	public	appeals_pkey	8192	2025-10-14 00:00:00.3147
168	primary	public	backups	8192	2025-10-14 00:00:00.3147
169	primary	public	backups_pkey	8192	2025-10-14 00:00:00.3147
170	primary	public	bookmarks	8192	2025-10-14 00:00:00.3147
171	primary	public	bulk_import_rows	8192	2025-10-14 00:00:00.3147
172	primary	public	bulk_import_rows_pkey	8192	2025-10-14 00:00:00.3147
173	primary	public	bulk_imports	8192	2025-10-14 00:00:00.3147
174	primary	public	bulk_imports_pkey	8192	2025-10-14 00:00:00.3147
175	primary	public	canonical_email_blocks	8192	2025-10-14 00:00:00.3147
176	primary	public	canonical_email_blocks_pkey	8192	2025-10-14 00:00:00.3147
177	primary	public	conversation_mutes_pkey	8192	2025-10-14 00:00:00.3147
178	primary	public	custom_emoji_categories	8192	2025-10-14 00:00:00.3147
179	primary	public	custom_emoji_categories_pkey	8192	2025-10-14 00:00:00.3147
180	primary	public	custom_emojis	8192	2025-10-14 00:00:00.3147
181	primary	public	custom_emojis_pkey	8192	2025-10-14 00:00:00.3147
182	primary	public	custom_filter_statuses_pkey	8192	2025-10-14 00:00:00.3147
183	primary	public	domain_allows	8192	2025-10-14 00:00:00.3147
184	primary	public	domain_allows_pkey	8192	2025-10-14 00:00:00.3147
185	primary	public	domain_blocks	8192	2025-10-14 00:00:00.3147
186	primary	public	domain_blocks_pkey	8192	2025-10-14 00:00:00.3147
187	primary	public	email_domain_blocks	8192	2025-10-14 00:00:00.3147
188	primary	public	email_domain_blocks_pkey	8192	2025-10-14 00:00:00.3147
189	primary	public	favourites	8192	2025-10-14 00:00:00.3147
190	primary	public	featured_tags	8192	2025-10-14 00:00:00.3147
191	primary	public	featured_tags_pkey	8192	2025-10-14 00:00:00.3147
192	primary	public	follow_recommendation_mutes_pkey	8192	2025-10-14 00:00:00.3147
193	primary	public	follow_recommendation_suppressions_pkey	8192	2025-10-14 00:00:00.3147
194	primary	public	follow_requests	8192	2025-10-14 00:00:00.3147
195	primary	public	follow_requests_pkey	8192	2025-10-14 00:00:00.3147
196	primary	public	generated_annual_reports	8192	2025-10-14 00:00:00.3147
197	primary	public	generated_annual_reports_pkey	8192	2025-10-14 00:00:00.3147
198	primary	public	global_follow_recommendations	8192	2025-10-14 00:00:00.3147
199	primary	public	identities	8192	2025-10-14 00:00:00.3147
200	primary	public	identities_pkey	8192	2025-10-14 00:00:00.3147
201	primary	public	idx_on_account_id_language_sensitive_250461e1eb	8192	2025-10-14 00:00:00.3147
202	primary	public	idx_on_account_id_relationship_severance_event_id_7bd82bf20e	8192	2025-10-14 00:00:00.3147
203	primary	public	idx_on_account_id_target_account_id_a8c8ddf44e	8192	2025-10-14 00:00:00.3147
204	primary	public	idx_on_relationship_severance_event_id_403f53e707	8192	2025-10-14 00:00:00.3147
205	primary	public	imports	8192	2025-10-14 00:00:00.3147
206	primary	public	imports_pkey	8192	2025-10-14 00:00:00.3147
207	primary	public	index_account_aliases_on_account_id	8192	2025-10-14 00:00:00.3147
208	primary	public	index_account_aliases_on_account_id_and_uri	8192	2025-10-14 00:00:00.3147
209	primary	public	index_account_conversations_on_conversation_id	8192	2025-10-14 00:00:00.3147
210	primary	public	index_account_deletion_requests_on_account_id	8192	2025-10-14 00:00:00.3147
211	primary	public	index_account_domain_blocks_on_account_id_and_domain	8192	2025-10-14 00:00:00.3147
212	primary	public	index_account_migrations_on_account_id	8192	2025-10-14 00:00:00.3147
213	primary	public	index_account_migrations_on_target_account_id	8192	2025-10-14 00:00:00.3147
214	primary	public	index_account_moderation_notes_on_account_id	8192	2025-10-14 00:00:00.3147
215	primary	public	index_account_moderation_notes_on_target_account_id	8192	2025-10-14 00:00:00.3147
216	primary	public	index_account_notes_on_account_id_and_target_account_id	8192	2025-10-14 00:00:00.3147
217	primary	public	index_account_notes_on_target_account_id	8192	2025-10-14 00:00:00.3147
218	primary	public	index_account_pins_on_account_id_and_target_account_id	8192	2025-10-14 00:00:00.3147
219	primary	public	index_account_pins_on_target_account_id	8192	2025-10-14 00:00:00.3147
220	primary	public	index_account_relationship_severance_events_on_account_id	8192	2025-10-14 00:00:00.3147
221	primary	public	index_account_statuses_cleanup_policies_on_account_id	8192	2025-10-14 00:00:00.3147
222	primary	public	index_account_summaries_on_account_id	8192	2025-10-14 00:00:00.3147
223	primary	public	index_account_warnings_on_account_id	8192	2025-10-14 00:00:00.3147
224	primary	public	index_account_warnings_on_target_account_id	8192	2025-10-14 00:00:00.3147
225	primary	public	index_accounts_on_moved_to_account_id	8192	2025-10-14 00:00:00.3147
226	primary	public	index_accounts_on_url	8192	2025-10-14 00:00:00.3147
227	primary	public	index_accounts_tags_on_account_id_and_tag_id	8192	2025-10-14 00:00:00.3147
228	primary	public	index_admin_action_logs_on_account_id	8192	2025-10-14 00:00:00.3147
229	primary	public	index_admin_action_logs_on_target_type_and_target_id	8192	2025-10-14 00:00:00.3147
230	primary	public	index_announcement_mutes_on_account_id_and_announcement_id	8192	2025-10-14 00:00:00.3147
231	primary	public	index_announcement_mutes_on_announcement_id	8192	2025-10-14 00:00:00.3147
232	primary	public	index_announcement_reactions_on_account_id_and_announcement_id	8192	2025-10-14 00:00:00.3147
233	primary	public	index_announcement_reactions_on_announcement_id	8192	2025-10-14 00:00:00.3147
234	primary	public	index_announcement_reactions_on_custom_emoji_id	8192	2025-10-14 00:00:00.3147
235	primary	public	index_appeals_on_account_id	8192	2025-10-14 00:00:00.3147
236	primary	public	index_appeals_on_account_warning_id	8192	2025-10-14 00:00:00.3147
237	primary	public	index_appeals_on_approved_by_account_id	8192	2025-10-14 00:00:00.3147
238	primary	public	index_appeals_on_rejected_by_account_id	8192	2025-10-14 00:00:00.3147
239	primary	public	index_backups_on_user_id	8192	2025-10-14 00:00:00.3147
240	primary	public	index_bulk_import_rows_on_bulk_import_id	8192	2025-10-14 00:00:00.3147
241	primary	public	index_bulk_imports_on_account_id	8192	2025-10-14 00:00:00.3147
242	primary	public	index_bulk_imports_unconfirmed	8192	2025-10-14 00:00:00.3147
243	primary	public	index_canonical_email_blocks_on_canonical_email_hash	8192	2025-10-14 00:00:00.3147
244	primary	public	index_canonical_email_blocks_on_reference_account_id	8192	2025-10-14 00:00:00.3147
245	primary	public	index_conversation_mutes_on_account_id_and_conversation_id	8192	2025-10-14 00:00:00.3147
246	primary	public	index_conversations_on_uri	8192	2025-10-14 00:00:00.3147
247	primary	public	index_custom_emoji_categories_on_name	8192	2025-10-14 00:00:00.3147
248	primary	public	index_custom_emojis_on_shortcode_and_domain	8192	2025-10-14 00:00:00.3147
249	primary	public	index_custom_filter_statuses_on_custom_filter_id	8192	2025-10-14 00:00:00.3147
250	primary	public	index_custom_filter_statuses_on_status_id	8192	2025-10-14 00:00:00.3147
251	primary	public	index_custom_filter_statuses_on_status_id_and_custom_filter_id	8192	2025-10-14 00:00:00.3147
252	primary	public	index_domain_allows_on_domain	8192	2025-10-14 00:00:00.3147
253	primary	public	index_domain_blocks_on_domain	8192	2025-10-14 00:00:00.3147
254	primary	public	index_email_domain_blocks_on_domain	8192	2025-10-14 00:00:00.3147
255	primary	public	index_featured_tags_on_account_id_and_tag_id	8192	2025-10-14 00:00:00.3147
256	primary	public	index_featured_tags_on_tag_id	8192	2025-10-14 00:00:00.3147
257	primary	public	index_follow_recommendation_mutes_on_target_account_id	8192	2025-10-14 00:00:00.3147
258	primary	public	index_follow_recommendation_suppressions_on_account_id	8192	2025-10-14 00:00:00.3147
259	primary	public	index_follow_requests_on_account_id_and_target_account_id	8192	2025-10-14 00:00:00.3147
260	primary	public	index_generated_annual_reports_on_account_id_and_year	8192	2025-10-14 00:00:00.3147
261	primary	public	index_global_follow_recommendations_on_account_id	8192	2025-10-14 00:00:00.3147
262	primary	public	index_identities_on_uid_and_provider	8192	2025-10-14 00:00:00.3147
263	primary	public	index_identities_on_user_id	8192	2025-10-14 00:00:00.3147
264	primary	public	index_instances_on_domain	8192	2025-10-14 00:00:00.3147
265	primary	public	index_instances_on_reverse_domain	8192	2025-10-14 00:00:00.3147
266	primary	public	index_ip_blocks_on_ip	8192	2025-10-14 00:00:00.3147
267	primary	public	index_list_accounts_on_follow_request_id	8192	2025-10-14 00:00:00.3147
268	primary	public	index_media_attachments_on_scheduled_status_id	8192	2025-10-14 00:00:00.3147
269	primary	public	index_media_attachments_on_shortcode	8192	2025-10-14 00:00:00.3147
270	primary	public	index_notification_permissions_on_account_id	8192	2025-10-14 00:00:00.3147
271	primary	public	index_notification_permissions_on_from_account_id	8192	2025-10-14 00:00:00.3147
272	primary	public	index_notification_requests_on_account_id_and_from_account_id	8192	2025-10-14 00:00:00.3147
273	primary	public	index_notification_requests_on_from_account_id	8192	2025-10-14 00:00:00.3147
274	primary	public	index_notification_requests_on_last_status_id	8192	2025-10-14 00:00:00.3147
275	primary	public	index_oauth_access_tokens_on_refresh_token	8192	2025-10-14 00:00:00.3147
276	primary	public	index_pghero_space_stats_on_database_and_captured_at	8192	2025-10-14 00:00:00.3147
277	primary	public	index_preview_card_providers_on_domain	8192	2025-10-14 00:00:00.3147
278	primary	public	index_preview_card_trends_on_preview_card_id	8192	2025-10-14 00:00:00.3147
279	primary	public	index_preview_cards_on_author_account_id	8192	2025-10-14 00:00:00.3147
280	primary	public	index_preview_cards_on_url	8192	2025-10-14 00:00:00.3147
281	primary	public	index_relationship_severance_events_on_type_and_target_name	8192	2025-10-14 00:00:00.3147
282	primary	public	index_report_notes_on_account_id	8192	2025-10-14 00:00:00.3147
283	primary	public	index_report_notes_on_report_id	8192	2025-10-14 00:00:00.3147
284	primary	public	index_reports_on_action_taken_by_account_id	8192	2025-10-14 00:00:00.3147
285	primary	public	index_reports_on_assigned_account_id	8192	2025-10-14 00:00:00.3147
286	primary	public	index_scheduled_statuses_on_account_id	8192	2025-10-14 00:00:00.3147
287	primary	public	index_scheduled_statuses_on_scheduled_at	8192	2025-10-14 00:00:00.3147
288	primary	public	index_settings_on_thing_type_and_thing_id_and_var	8192	2025-10-14 00:00:00.3147
289	primary	public	index_severed_relationships_on_local_account_and_event	8192	2025-10-14 00:00:00.3147
290	primary	public	index_severed_relationships_on_remote_account_id	8192	2025-10-14 00:00:00.3147
291	primary	public	index_severed_relationships_on_unique_tuples	8192	2025-10-14 00:00:00.3147
292	primary	public	index_site_uploads_on_var	8192	2025-10-14 00:00:00.3147
293	primary	public	index_software_updates_on_version	8192	2025-10-14 00:00:00.3147
294	primary	public	index_status_edits_on_account_id	8192	2025-10-14 00:00:00.3147
295	primary	public	index_status_edits_on_status_id	8192	2025-10-14 00:00:00.3147
296	primary	public	index_status_pins_on_account_id_and_status_id	8192	2025-10-14 00:00:00.3147
297	primary	public	index_status_pins_on_status_id	8192	2025-10-14 00:00:00.3147
298	primary	public	index_status_trends_on_account_id	8192	2025-10-14 00:00:00.3147
299	primary	public	index_status_trends_on_status_id	8192	2025-10-14 00:00:00.3147
300	primary	public	index_tombstones_on_account_id	8192	2025-10-14 00:00:00.3147
301	primary	public	index_tombstones_on_uri	8192	2025-10-14 00:00:00.3147
302	primary	public	index_unavailable_domains_on_domain	8192	2025-10-14 00:00:00.3147
303	primary	public	index_unique_conversations	8192	2025-10-14 00:00:00.3147
304	primary	public	index_user_invite_requests_on_user_id	8192	2025-10-14 00:00:00.3147
305	primary	public	index_users_on_reset_password_token	8192	2025-10-14 00:00:00.3147
306	primary	public	index_users_on_unconfirmed_email	8192	2025-10-14 00:00:00.3147
307	primary	public	index_web_push_subscriptions_on_access_token_id	8192	2025-10-14 00:00:00.3147
308	primary	public	index_web_push_subscriptions_on_user_id	8192	2025-10-14 00:00:00.3147
309	primary	public	index_webauthn_credentials_on_external_id	8192	2025-10-14 00:00:00.3147
310	primary	public	index_webauthn_credentials_on_user_id	8192	2025-10-14 00:00:00.3147
311	primary	public	index_webauthn_credentials_on_user_id_and_nickname	8192	2025-10-14 00:00:00.3147
312	primary	public	index_webhooks_on_url	8192	2025-10-14 00:00:00.3147
313	primary	public	instances	8192	2025-10-14 00:00:00.3147
314	primary	public	ip_blocks	8192	2025-10-14 00:00:00.3147
315	primary	public	ip_blocks_pkey	8192	2025-10-14 00:00:00.3147
316	primary	public	list_accounts	8192	2025-10-14 00:00:00.3147
317	primary	public	mentions	8192	2025-10-14 00:00:00.3147
318	primary	public	mutes	8192	2025-10-14 00:00:00.3147
319	primary	public	notification_permissions_pkey	8192	2025-10-14 00:00:00.3147
320	primary	public	notification_policies	8192	2025-10-14 00:00:00.3147
321	primary	public	notification_requests_pkey	8192	2025-10-14 00:00:00.3147
322	primary	public	pghero_space_stats	8192	2025-10-14 00:00:00.3147
323	primary	public	pghero_space_stats_pkey	8192	2025-10-14 00:00:00.3147
324	primary	public	preview_card_providers	8192	2025-10-14 00:00:00.3147
325	primary	public	preview_card_providers_pkey	8192	2025-10-14 00:00:00.3147
326	primary	public	preview_card_trends	8192	2025-10-14 00:00:00.3147
327	primary	public	preview_card_trends_pkey	8192	2025-10-14 00:00:00.3147
328	primary	public	preview_cards	8192	2025-10-14 00:00:00.3147
329	primary	public	preview_cards_pkey	8192	2025-10-14 00:00:00.3147
330	primary	public	preview_cards_statuses	8192	2025-10-14 00:00:00.3147
331	primary	public	preview_cards_statuses_pkey	8192	2025-10-14 00:00:00.3147
332	primary	public	relationship_severance_events	8192	2025-10-14 00:00:00.3147
333	primary	public	relationship_severance_events_pkey	8192	2025-10-14 00:00:00.3147
334	primary	public	relays	8192	2025-10-14 00:00:00.3147
335	primary	public	relays_pkey	8192	2025-10-14 00:00:00.3147
336	primary	public	report_notes	8192	2025-10-14 00:00:00.3147
337	primary	public	report_notes_pkey	8192	2025-10-14 00:00:00.3147
338	primary	public	rules	8192	2025-10-14 00:00:00.3147
339	primary	public	rules_pkey	8192	2025-10-14 00:00:00.3147
340	primary	public	scheduled_statuses	8192	2025-10-14 00:00:00.3147
341	primary	public	scheduled_statuses_pkey	8192	2025-10-14 00:00:00.3147
342	primary	public	settings	8192	2025-10-14 00:00:00.3147
343	primary	public	settings_pkey	8192	2025-10-14 00:00:00.3147
344	primary	public	severed_relationships	8192	2025-10-14 00:00:00.3147
345	primary	public	severed_relationships_pkey	8192	2025-10-14 00:00:00.3147
346	primary	public	site_uploads	8192	2025-10-14 00:00:00.3147
347	primary	public	site_uploads_pkey	8192	2025-10-14 00:00:00.3147
348	primary	public	software_updates	8192	2025-10-14 00:00:00.3147
349	primary	public	software_updates_pkey	8192	2025-10-14 00:00:00.3147
350	primary	public	status_edits	8192	2025-10-14 00:00:00.3147
351	primary	public	status_edits_pkey	8192	2025-10-14 00:00:00.3147
352	primary	public	status_pins_pkey	8192	2025-10-14 00:00:00.3147
353	primary	public	status_stats	8192	2025-10-14 00:00:00.3147
354	primary	public	status_trends	8192	2025-10-14 00:00:00.3147
355	primary	public	status_trends_pkey	8192	2025-10-14 00:00:00.3147
356	primary	public	statuses_tags	8192	2025-10-14 00:00:00.3147
357	primary	public	tag_follows	8192	2025-10-14 00:00:00.3147
358	primary	public	tombstones	8192	2025-10-14 00:00:00.3147
359	primary	public	tombstones_pkey	8192	2025-10-14 00:00:00.3147
360	primary	public	unavailable_domains	8192	2025-10-14 00:00:00.3147
361	primary	public	unavailable_domains_pkey	8192	2025-10-14 00:00:00.3147
362	primary	public	user_invite_requests	8192	2025-10-14 00:00:00.3147
363	primary	public	user_invite_requests_pkey	8192	2025-10-14 00:00:00.3147
364	primary	public	web_push_subscriptions	8192	2025-10-14 00:00:00.3147
365	primary	public	web_push_subscriptions_pkey	8192	2025-10-14 00:00:00.3147
366	primary	public	webauthn_credentials	8192	2025-10-14 00:00:00.3147
367	primary	public	webauthn_credentials_pkey	8192	2025-10-14 00:00:00.3147
368	primary	public	webhooks	8192	2025-10-14 00:00:00.3147
369	primary	public	webhooks_pkey	8192	2025-10-14 00:00:00.3147
370	primary	public	account_deletion_requests	0	2025-10-14 00:00:00.3147
371	primary	public	account_pins	0	2025-10-14 00:00:00.3147
372	primary	public	account_relationship_severance_events	0	2025-10-14 00:00:00.3147
373	primary	public	account_statuses_cleanup_policies	0	2025-10-14 00:00:00.3147
374	primary	public	accounts_tags	0	2025-10-14 00:00:00.3147
375	primary	public	announcement_mutes	0	2025-10-14 00:00:00.3147
376	primary	public	conversation_mutes	0	2025-10-14 00:00:00.3147
377	primary	public	custom_filter_statuses	0	2025-10-14 00:00:00.3147
378	primary	public	follow_recommendation_mutes	0	2025-10-14 00:00:00.3147
379	primary	public	follow_recommendation_suppressions	0	2025-10-14 00:00:00.3147
380	primary	public	notification_permissions	0	2025-10-14 00:00:00.3147
381	primary	public	notification_requests	0	2025-10-14 00:00:00.3147
382	primary	public	status_pins	0	2025-10-14 00:00:00.3147
383	primary	public	accounts	114688	2025-10-02 02:30:00.207612
384	primary	public	pghero_space_stats	73728	2025-10-02 02:30:00.207612
385	primary	public	media_attachments	57344	2025-10-02 02:30:00.207612
386	primary	public	schema_migrations	57344	2025-10-02 02:30:00.207612
387	primary	public	statuses	49152	2025-10-02 02:30:00.207612
388	primary	public	pghero_space_stats_pkey	32768	2025-10-02 02:30:00.207612
389	primary	public	schema_migrations_pkey	32768	2025-10-02 02:30:00.207612
390	primary	public	account_summaries	24576	2025-10-02 02:30:00.207612
391	primary	public	search_index	24576	2025-10-02 02:30:00.207612
392	primary	public	account_stats_pkey	16384	2025-10-02 02:30:00.207612
393	primary	public	accounts_pkey	16384	2025-10-02 02:30:00.207612
394	primary	public	ar_internal_metadata	16384	2025-10-02 02:30:00.207612
395	primary	public	ar_internal_metadata_pkey	16384	2025-10-02 02:30:00.207612
396	primary	public	conversations	16384	2025-10-02 02:30:00.207612
397	primary	public	conversations_pkey	16384	2025-10-02 02:30:00.207612
398	primary	public	custom_filter_keywords	16384	2025-10-02 02:30:00.207612
399	primary	public	custom_filter_keywords_pkey	16384	2025-10-02 02:30:00.207612
400	primary	public	custom_filters	16384	2025-10-02 02:30:00.207612
401	primary	public	custom_filters_pkey	16384	2025-10-02 02:30:00.207612
402	primary	public	follows	16384	2025-10-02 02:30:00.207612
403	primary	public	follows_pkey	16384	2025-10-02 02:30:00.207612
404	primary	public	idx_on_account_id_language_sensitive_250461e1eb	16384	2025-10-02 02:30:00.207612
405	primary	public	index_account_stats_on_account_id	16384	2025-10-02 02:30:00.207612
406	primary	public	index_account_stats_on_last_status_at_and_account_id	16384	2025-10-02 02:30:00.207612
407	primary	public	index_account_summaries_on_account_id	16384	2025-10-02 02:30:00.207612
408	primary	public	index_accounts_on_domain_and_id	16384	2025-10-02 02:30:00.207612
409	primary	public	index_accounts_on_uri	16384	2025-10-02 02:30:00.207612
410	primary	public	index_accounts_on_username_and_domain_lower	16384	2025-10-02 02:30:00.207612
493	primary	public	statuses_tags_pkey	16384	2025-10-02 02:30:00.207612
411	primary	public	index_custom_filter_keywords_on_custom_filter_id	16384	2025-10-02 02:30:00.207612
412	primary	public	index_custom_filters_on_account_id	16384	2025-10-02 02:30:00.207612
413	primary	public	index_follows_on_account_id_and_target_account_id	16384	2025-10-02 02:30:00.207612
414	primary	public	index_follows_on_target_account_id	16384	2025-10-02 02:30:00.207612
415	primary	public	index_invites_on_code	16384	2025-10-02 02:30:00.207612
416	primary	public	index_invites_on_user_id	16384	2025-10-02 02:30:00.207612
417	primary	public	index_login_activities_on_user_id	16384	2025-10-02 02:30:00.207612
418	primary	public	index_markers_on_user_id_and_timeline	16384	2025-10-02 02:30:00.207612
419	primary	public	index_media_attachments_on_account_id_and_status_id	16384	2025-10-02 02:30:00.207612
420	primary	public	index_media_attachments_on_status_id	16384	2025-10-02 02:30:00.207612
421	primary	public	index_notification_policies_on_account_id	16384	2025-10-02 02:30:00.207612
422	primary	public	index_notifications_on_account_id_and_group_key	16384	2025-10-02 02:30:00.207612
423	primary	public	index_notifications_on_account_id_and_id_and_type	16384	2025-10-02 02:30:00.207612
424	primary	public	index_notifications_on_activity_id_and_activity_type	16384	2025-10-02 02:30:00.207612
425	primary	public	index_notifications_on_filtered	16384	2025-10-02 02:30:00.207612
426	primary	public	index_notifications_on_from_account_id	16384	2025-10-02 02:30:00.207612
427	primary	public	index_oauth_access_grants_on_resource_owner_id	16384	2025-10-02 02:30:00.207612
428	primary	public	index_oauth_access_grants_on_token	16384	2025-10-02 02:30:00.207612
429	primary	public	index_oauth_access_tokens_on_resource_owner_id	16384	2025-10-02 02:30:00.207612
430	primary	public	index_oauth_access_tokens_on_token	16384	2025-10-02 02:30:00.207612
431	primary	public	index_oauth_applications_on_owner_id_and_owner_type	16384	2025-10-02 02:30:00.207612
432	primary	public	index_oauth_applications_on_superapp	16384	2025-10-02 02:30:00.207612
433	primary	public	index_oauth_applications_on_uid	16384	2025-10-02 02:30:00.207612
434	primary	public	index_pghero_space_stats_on_database_and_captured_at	16384	2025-10-02 02:30:00.207612
435	primary	public	index_poll_votes_on_account_id	16384	2025-10-02 02:30:00.207612
436	primary	public	index_poll_votes_on_poll_id	16384	2025-10-02 02:30:00.207612
437	primary	public	index_polls_on_account_id	16384	2025-10-02 02:30:00.207612
438	primary	public	index_polls_on_status_id	16384	2025-10-02 02:30:00.207612
439	primary	public	index_reports_on_account_id	16384	2025-10-02 02:30:00.207612
440	primary	public	index_reports_on_target_account_id	16384	2025-10-02 02:30:00.207612
441	primary	public	index_session_activations_on_access_token_id	16384	2025-10-02 02:30:00.207612
442	primary	public	index_session_activations_on_session_id	16384	2025-10-02 02:30:00.207612
443	primary	public	index_session_activations_on_user_id	16384	2025-10-02 02:30:00.207612
444	primary	public	index_software_updates_on_version	16384	2025-10-02 02:30:00.207612
445	primary	public	index_status_edits_on_account_id	16384	2025-10-02 02:30:00.207612
446	primary	public	index_status_edits_on_status_id	16384	2025-10-02 02:30:00.207612
447	primary	public	index_status_stats_on_status_id	16384	2025-10-02 02:30:00.207612
448	primary	public	index_statuses_20190820	16384	2025-10-02 02:30:00.207612
449	primary	public	index_statuses_local_20190824	16384	2025-10-02 02:30:00.207612
450	primary	public	index_statuses_on_account_id	16384	2025-10-02 02:30:00.207612
451	primary	public	index_statuses_on_deleted_at	16384	2025-10-02 02:30:00.207612
452	primary	public	index_statuses_on_reblog_of_id_and_account_id	16384	2025-10-02 02:30:00.207612
453	primary	public	index_statuses_on_uri	16384	2025-10-02 02:30:00.207612
454	primary	public	index_statuses_public_20200119	16384	2025-10-02 02:30:00.207612
455	primary	public	index_statuses_tags_on_status_id	16384	2025-10-02 02:30:00.207612
456	primary	public	index_tags_on_name_lower_btree	16384	2025-10-02 02:30:00.207612
457	primary	public	index_users_on_account_id	16384	2025-10-02 02:30:00.207612
458	primary	public	index_users_on_confirmation_token	16384	2025-10-02 02:30:00.207612
459	primary	public	index_users_on_created_by_application_id	16384	2025-10-02 02:30:00.207612
460	primary	public	index_users_on_email	16384	2025-10-02 02:30:00.207612
461	primary	public	index_users_on_role_id	16384	2025-10-02 02:30:00.207612
462	primary	public	index_web_settings_on_user_id	16384	2025-10-02 02:30:00.207612
463	primary	public	invites	16384	2025-10-02 02:30:00.207612
464	primary	public	invites_pkey	16384	2025-10-02 02:30:00.207612
465	primary	public	login_activities	16384	2025-10-02 02:30:00.207612
466	primary	public	login_activities_pkey	16384	2025-10-02 02:30:00.207612
467	primary	public	markers	16384	2025-10-02 02:30:00.207612
468	primary	public	markers_pkey	16384	2025-10-02 02:30:00.207612
469	primary	public	media_attachments_pkey	16384	2025-10-02 02:30:00.207612
470	primary	public	notification_policies_pkey	16384	2025-10-02 02:30:00.207612
471	primary	public	notifications	16384	2025-10-02 02:30:00.207612
472	primary	public	notifications_pkey	16384	2025-10-02 02:30:00.207612
473	primary	public	oauth_access_grants	16384	2025-10-02 02:30:00.207612
474	primary	public	oauth_access_grants_pkey	16384	2025-10-02 02:30:00.207612
475	primary	public	oauth_access_tokens	16384	2025-10-02 02:30:00.207612
476	primary	public	oauth_access_tokens_pkey	16384	2025-10-02 02:30:00.207612
477	primary	public	oauth_applications	16384	2025-10-02 02:30:00.207612
478	primary	public	oauth_applications_pkey	16384	2025-10-02 02:30:00.207612
479	primary	public	poll_votes	16384	2025-10-02 02:30:00.207612
480	primary	public	poll_votes_pkey	16384	2025-10-02 02:30:00.207612
481	primary	public	polls	16384	2025-10-02 02:30:00.207612
482	primary	public	polls_pkey	16384	2025-10-02 02:30:00.207612
483	primary	public	reports	16384	2025-10-02 02:30:00.207612
484	primary	public	reports_pkey	16384	2025-10-02 02:30:00.207612
485	primary	public	session_activations	16384	2025-10-02 02:30:00.207612
486	primary	public	session_activations_pkey	16384	2025-10-02 02:30:00.207612
487	primary	public	software_updates	16384	2025-10-02 02:30:00.207612
488	primary	public	software_updates_pkey	16384	2025-10-02 02:30:00.207612
489	primary	public	status_edits	16384	2025-10-02 02:30:00.207612
490	primary	public	status_edits_pkey	16384	2025-10-02 02:30:00.207612
491	primary	public	status_stats_pkey	16384	2025-10-02 02:30:00.207612
492	primary	public	statuses_pkey	16384	2025-10-02 02:30:00.207612
494	primary	public	tags	16384	2025-10-02 02:30:00.207612
495	primary	public	tags_pkey	16384	2025-10-02 02:30:00.207612
496	primary	public	user_roles	16384	2025-10-02 02:30:00.207612
497	primary	public	user_roles_pkey	16384	2025-10-02 02:30:00.207612
498	primary	public	users	16384	2025-10-02 02:30:00.207612
499	primary	public	users_pkey	16384	2025-10-02 02:30:00.207612
500	primary	public	web_settings	16384	2025-10-02 02:30:00.207612
501	primary	public	web_settings_pkey	16384	2025-10-02 02:30:00.207612
502	primary	public	account_aliases	8192	2025-10-02 02:30:00.207612
503	primary	public	account_aliases_pkey	8192	2025-10-02 02:30:00.207612
504	primary	public	account_conversations	8192	2025-10-02 02:30:00.207612
505	primary	public	account_conversations_pkey	8192	2025-10-02 02:30:00.207612
506	primary	public	account_deletion_requests_pkey	8192	2025-10-02 02:30:00.207612
507	primary	public	account_domain_blocks	8192	2025-10-02 02:30:00.207612
508	primary	public	account_domain_blocks_pkey	8192	2025-10-02 02:30:00.207612
509	primary	public	account_migrations	8192	2025-10-02 02:30:00.207612
510	primary	public	account_migrations_pkey	8192	2025-10-02 02:30:00.207612
511	primary	public	account_moderation_notes	8192	2025-10-02 02:30:00.207612
512	primary	public	account_moderation_notes_pkey	8192	2025-10-02 02:30:00.207612
513	primary	public	account_notes	8192	2025-10-02 02:30:00.207612
514	primary	public	account_notes_pkey	8192	2025-10-02 02:30:00.207612
515	primary	public	account_pins_pkey	8192	2025-10-02 02:30:00.207612
516	primary	public	account_relationship_severance_events_pkey	8192	2025-10-02 02:30:00.207612
517	primary	public	account_stats	8192	2025-10-02 02:30:00.207612
518	primary	public	account_statuses_cleanup_policies_pkey	8192	2025-10-02 02:30:00.207612
519	primary	public	account_warning_presets	8192	2025-10-02 02:30:00.207612
520	primary	public	account_warning_presets_pkey	8192	2025-10-02 02:30:00.207612
521	primary	public	account_warnings	8192	2025-10-02 02:30:00.207612
522	primary	public	account_warnings_pkey	8192	2025-10-02 02:30:00.207612
523	primary	public	accounts_tags_pkey	8192	2025-10-02 02:30:00.207612
524	primary	public	admin_action_logs	8192	2025-10-02 02:30:00.207612
525	primary	public	admin_action_logs_pkey	8192	2025-10-02 02:30:00.207612
526	primary	public	announcement_mutes_pkey	8192	2025-10-02 02:30:00.207612
527	primary	public	announcement_reactions	8192	2025-10-02 02:30:00.207612
528	primary	public	announcement_reactions_pkey	8192	2025-10-02 02:30:00.207612
529	primary	public	announcements	8192	2025-10-02 02:30:00.207612
530	primary	public	announcements_pkey	8192	2025-10-02 02:30:00.207612
531	primary	public	appeals	8192	2025-10-02 02:30:00.207612
532	primary	public	appeals_pkey	8192	2025-10-02 02:30:00.207612
533	primary	public	backups	8192	2025-10-02 02:30:00.207612
534	primary	public	backups_pkey	8192	2025-10-02 02:30:00.207612
535	primary	public	blocks	8192	2025-10-02 02:30:00.207612
536	primary	public	blocks_pkey	8192	2025-10-02 02:30:00.207612
537	primary	public	bookmarks_pkey	8192	2025-10-02 02:30:00.207612
538	primary	public	bulk_import_rows	8192	2025-10-02 02:30:00.207612
539	primary	public	bulk_import_rows_pkey	8192	2025-10-02 02:30:00.207612
540	primary	public	bulk_imports	8192	2025-10-02 02:30:00.207612
541	primary	public	bulk_imports_pkey	8192	2025-10-02 02:30:00.207612
542	primary	public	canonical_email_blocks	8192	2025-10-02 02:30:00.207612
543	primary	public	canonical_email_blocks_pkey	8192	2025-10-02 02:30:00.207612
544	primary	public	conversation_mutes_pkey	8192	2025-10-02 02:30:00.207612
545	primary	public	custom_emoji_categories	8192	2025-10-02 02:30:00.207612
546	primary	public	custom_emoji_categories_pkey	8192	2025-10-02 02:30:00.207612
547	primary	public	custom_emojis	8192	2025-10-02 02:30:00.207612
548	primary	public	custom_emojis_pkey	8192	2025-10-02 02:30:00.207612
549	primary	public	custom_filter_statuses_pkey	8192	2025-10-02 02:30:00.207612
550	primary	public	domain_allows	8192	2025-10-02 02:30:00.207612
551	primary	public	domain_allows_pkey	8192	2025-10-02 02:30:00.207612
552	primary	public	domain_blocks	8192	2025-10-02 02:30:00.207612
553	primary	public	domain_blocks_pkey	8192	2025-10-02 02:30:00.207612
554	primary	public	email_domain_blocks	8192	2025-10-02 02:30:00.207612
555	primary	public	email_domain_blocks_pkey	8192	2025-10-02 02:30:00.207612
556	primary	public	favourites_pkey	8192	2025-10-02 02:30:00.207612
557	primary	public	featured_tags	8192	2025-10-02 02:30:00.207612
558	primary	public	featured_tags_pkey	8192	2025-10-02 02:30:00.207612
559	primary	public	follow_recommendation_mutes_pkey	8192	2025-10-02 02:30:00.207612
560	primary	public	follow_recommendation_suppressions_pkey	8192	2025-10-02 02:30:00.207612
561	primary	public	follow_requests	8192	2025-10-02 02:30:00.207612
562	primary	public	follow_requests_pkey	8192	2025-10-02 02:30:00.207612
563	primary	public	generated_annual_reports	8192	2025-10-02 02:30:00.207612
564	primary	public	generated_annual_reports_pkey	8192	2025-10-02 02:30:00.207612
565	primary	public	global_follow_recommendations	8192	2025-10-02 02:30:00.207612
566	primary	public	identities	8192	2025-10-02 02:30:00.207612
567	primary	public	identities_pkey	8192	2025-10-02 02:30:00.207612
568	primary	public	idx_on_account_id_relationship_severance_event_id_7bd82bf20e	8192	2025-10-02 02:30:00.207612
569	primary	public	idx_on_account_id_target_account_id_a8c8ddf44e	8192	2025-10-02 02:30:00.207612
570	primary	public	idx_on_relationship_severance_event_id_403f53e707	8192	2025-10-02 02:30:00.207612
571	primary	public	imports	8192	2025-10-02 02:30:00.207612
572	primary	public	imports_pkey	8192	2025-10-02 02:30:00.207612
573	primary	public	index_account_aliases_on_account_id	8192	2025-10-02 02:30:00.207612
574	primary	public	index_account_aliases_on_account_id_and_uri	8192	2025-10-02 02:30:00.207612
575	primary	public	index_account_conversations_on_conversation_id	8192	2025-10-02 02:30:00.207612
576	primary	public	index_account_deletion_requests_on_account_id	8192	2025-10-02 02:30:00.207612
577	primary	public	index_account_domain_blocks_on_account_id_and_domain	8192	2025-10-02 02:30:00.207612
578	primary	public	index_account_migrations_on_account_id	8192	2025-10-02 02:30:00.207612
579	primary	public	index_account_migrations_on_target_account_id	8192	2025-10-02 02:30:00.207612
580	primary	public	index_account_moderation_notes_on_account_id	8192	2025-10-02 02:30:00.207612
581	primary	public	index_account_moderation_notes_on_target_account_id	8192	2025-10-02 02:30:00.207612
582	primary	public	index_account_notes_on_account_id_and_target_account_id	8192	2025-10-02 02:30:00.207612
583	primary	public	index_account_notes_on_target_account_id	8192	2025-10-02 02:30:00.207612
584	primary	public	index_account_pins_on_account_id_and_target_account_id	8192	2025-10-02 02:30:00.207612
585	primary	public	index_account_pins_on_target_account_id	8192	2025-10-02 02:30:00.207612
586	primary	public	index_account_relationship_severance_events_on_account_id	8192	2025-10-02 02:30:00.207612
587	primary	public	index_account_statuses_cleanup_policies_on_account_id	8192	2025-10-02 02:30:00.207612
588	primary	public	index_account_warnings_on_account_id	8192	2025-10-02 02:30:00.207612
589	primary	public	index_account_warnings_on_target_account_id	8192	2025-10-02 02:30:00.207612
590	primary	public	index_accounts_on_moved_to_account_id	8192	2025-10-02 02:30:00.207612
591	primary	public	index_accounts_on_url	8192	2025-10-02 02:30:00.207612
592	primary	public	index_accounts_tags_on_account_id_and_tag_id	8192	2025-10-02 02:30:00.207612
593	primary	public	index_admin_action_logs_on_account_id	8192	2025-10-02 02:30:00.207612
594	primary	public	index_admin_action_logs_on_target_type_and_target_id	8192	2025-10-02 02:30:00.207612
595	primary	public	index_announcement_mutes_on_account_id_and_announcement_id	8192	2025-10-02 02:30:00.207612
596	primary	public	index_announcement_mutes_on_announcement_id	8192	2025-10-02 02:30:00.207612
597	primary	public	index_announcement_reactions_on_account_id_and_announcement_id	8192	2025-10-02 02:30:00.207612
598	primary	public	index_announcement_reactions_on_announcement_id	8192	2025-10-02 02:30:00.207612
599	primary	public	index_announcement_reactions_on_custom_emoji_id	8192	2025-10-02 02:30:00.207612
600	primary	public	index_appeals_on_account_id	8192	2025-10-02 02:30:00.207612
601	primary	public	index_appeals_on_account_warning_id	8192	2025-10-02 02:30:00.207612
602	primary	public	index_appeals_on_approved_by_account_id	8192	2025-10-02 02:30:00.207612
603	primary	public	index_appeals_on_rejected_by_account_id	8192	2025-10-02 02:30:00.207612
604	primary	public	index_backups_on_user_id	8192	2025-10-02 02:30:00.207612
605	primary	public	index_blocks_on_account_id_and_target_account_id	8192	2025-10-02 02:30:00.207612
606	primary	public	index_blocks_on_target_account_id	8192	2025-10-02 02:30:00.207612
607	primary	public	index_bookmarks_on_account_id_and_status_id	8192	2025-10-02 02:30:00.207612
608	primary	public	index_bookmarks_on_status_id	8192	2025-10-02 02:30:00.207612
609	primary	public	index_bulk_import_rows_on_bulk_import_id	8192	2025-10-02 02:30:00.207612
610	primary	public	index_bulk_imports_on_account_id	8192	2025-10-02 02:30:00.207612
611	primary	public	index_bulk_imports_unconfirmed	8192	2025-10-02 02:30:00.207612
612	primary	public	index_canonical_email_blocks_on_canonical_email_hash	8192	2025-10-02 02:30:00.207612
613	primary	public	index_canonical_email_blocks_on_reference_account_id	8192	2025-10-02 02:30:00.207612
614	primary	public	index_conversation_mutes_on_account_id_and_conversation_id	8192	2025-10-02 02:30:00.207612
615	primary	public	index_conversations_on_uri	8192	2025-10-02 02:30:00.207612
616	primary	public	index_custom_emoji_categories_on_name	8192	2025-10-02 02:30:00.207612
617	primary	public	index_custom_emojis_on_shortcode_and_domain	8192	2025-10-02 02:30:00.207612
618	primary	public	index_custom_filter_statuses_on_custom_filter_id	8192	2025-10-02 02:30:00.207612
619	primary	public	index_custom_filter_statuses_on_status_id	8192	2025-10-02 02:30:00.207612
620	primary	public	index_custom_filter_statuses_on_status_id_and_custom_filter_id	8192	2025-10-02 02:30:00.207612
621	primary	public	index_domain_allows_on_domain	8192	2025-10-02 02:30:00.207612
622	primary	public	index_domain_blocks_on_domain	8192	2025-10-02 02:30:00.207612
623	primary	public	index_email_domain_blocks_on_domain	8192	2025-10-02 02:30:00.207612
624	primary	public	index_favourites_on_account_id_and_id	8192	2025-10-02 02:30:00.207612
625	primary	public	index_favourites_on_account_id_and_status_id	8192	2025-10-02 02:30:00.207612
626	primary	public	index_favourites_on_status_id	8192	2025-10-02 02:30:00.207612
627	primary	public	index_featured_tags_on_account_id_and_tag_id	8192	2025-10-02 02:30:00.207612
628	primary	public	index_featured_tags_on_tag_id	8192	2025-10-02 02:30:00.207612
629	primary	public	index_follow_recommendation_mutes_on_target_account_id	8192	2025-10-02 02:30:00.207612
630	primary	public	index_follow_recommendation_suppressions_on_account_id	8192	2025-10-02 02:30:00.207612
631	primary	public	index_follow_requests_on_account_id_and_target_account_id	8192	2025-10-02 02:30:00.207612
632	primary	public	index_generated_annual_reports_on_account_id_and_year	8192	2025-10-02 02:30:00.207612
633	primary	public	index_global_follow_recommendations_on_account_id	8192	2025-10-02 02:30:00.207612
634	primary	public	index_identities_on_uid_and_provider	8192	2025-10-02 02:30:00.207612
635	primary	public	index_identities_on_user_id	8192	2025-10-02 02:30:00.207612
636	primary	public	index_instances_on_domain	8192	2025-10-02 02:30:00.207612
637	primary	public	index_instances_on_reverse_domain	8192	2025-10-02 02:30:00.207612
638	primary	public	index_ip_blocks_on_ip	8192	2025-10-02 02:30:00.207612
639	primary	public	index_list_accounts_on_account_id_and_list_id	8192	2025-10-02 02:30:00.207612
640	primary	public	index_list_accounts_on_follow_id	8192	2025-10-02 02:30:00.207612
641	primary	public	index_list_accounts_on_follow_request_id	8192	2025-10-02 02:30:00.207612
642	primary	public	index_list_accounts_on_list_id_and_account_id	8192	2025-10-02 02:30:00.207612
643	primary	public	index_lists_on_account_id	8192	2025-10-02 02:30:00.207612
644	primary	public	index_media_attachments_on_scheduled_status_id	8192	2025-10-02 02:30:00.207612
645	primary	public	index_media_attachments_on_shortcode	8192	2025-10-02 02:30:00.207612
646	primary	public	index_mentions_on_account_id_and_status_id	8192	2025-10-02 02:30:00.207612
647	primary	public	index_mentions_on_status_id	8192	2025-10-02 02:30:00.207612
648	primary	public	index_mutes_on_account_id_and_target_account_id	8192	2025-10-02 02:30:00.207612
649	primary	public	index_mutes_on_target_account_id	8192	2025-10-02 02:30:00.207612
650	primary	public	index_notification_permissions_on_account_id	8192	2025-10-02 02:30:00.207612
651	primary	public	index_notification_permissions_on_from_account_id	8192	2025-10-02 02:30:00.207612
652	primary	public	index_notification_requests_on_account_id_and_from_account_id	8192	2025-10-02 02:30:00.207612
653	primary	public	index_notification_requests_on_from_account_id	8192	2025-10-02 02:30:00.207612
654	primary	public	index_notification_requests_on_last_status_id	8192	2025-10-02 02:30:00.207612
655	primary	public	index_oauth_access_tokens_on_refresh_token	8192	2025-10-02 02:30:00.207612
656	primary	public	index_preview_card_providers_on_domain	8192	2025-10-02 02:30:00.207612
657	primary	public	index_preview_card_trends_on_preview_card_id	8192	2025-10-02 02:30:00.207612
658	primary	public	index_preview_cards_on_author_account_id	8192	2025-10-02 02:30:00.207612
659	primary	public	index_preview_cards_on_url	8192	2025-10-02 02:30:00.207612
660	primary	public	index_relationship_severance_events_on_type_and_target_name	8192	2025-10-02 02:30:00.207612
661	primary	public	index_report_notes_on_account_id	8192	2025-10-02 02:30:00.207612
662	primary	public	index_report_notes_on_report_id	8192	2025-10-02 02:30:00.207612
663	primary	public	index_reports_on_action_taken_by_account_id	8192	2025-10-02 02:30:00.207612
664	primary	public	index_reports_on_assigned_account_id	8192	2025-10-02 02:30:00.207612
665	primary	public	index_scheduled_statuses_on_account_id	8192	2025-10-02 02:30:00.207612
666	primary	public	index_scheduled_statuses_on_scheduled_at	8192	2025-10-02 02:30:00.207612
667	primary	public	index_settings_on_thing_type_and_thing_id_and_var	8192	2025-10-02 02:30:00.207612
668	primary	public	index_severed_relationships_on_local_account_and_event	8192	2025-10-02 02:30:00.207612
669	primary	public	index_severed_relationships_on_remote_account_id	8192	2025-10-02 02:30:00.207612
670	primary	public	index_severed_relationships_on_unique_tuples	8192	2025-10-02 02:30:00.207612
671	primary	public	index_site_uploads_on_var	8192	2025-10-02 02:30:00.207612
672	primary	public	index_status_pins_on_account_id_and_status_id	8192	2025-10-02 02:30:00.207612
673	primary	public	index_status_pins_on_status_id	8192	2025-10-02 02:30:00.207612
674	primary	public	index_status_trends_on_account_id	8192	2025-10-02 02:30:00.207612
675	primary	public	index_status_trends_on_status_id	8192	2025-10-02 02:30:00.207612
676	primary	public	index_statuses_on_in_reply_to_account_id	8192	2025-10-02 02:30:00.207612
677	primary	public	index_statuses_on_in_reply_to_id	8192	2025-10-02 02:30:00.207612
678	primary	public	index_tag_follows_on_account_id_and_tag_id	8192	2025-10-02 02:30:00.207612
679	primary	public	index_tag_follows_on_tag_id	8192	2025-10-02 02:30:00.207612
680	primary	public	index_tombstones_on_account_id	8192	2025-10-02 02:30:00.207612
681	primary	public	index_tombstones_on_uri	8192	2025-10-02 02:30:00.207612
682	primary	public	index_unavailable_domains_on_domain	8192	2025-10-02 02:30:00.207612
683	primary	public	index_unique_conversations	8192	2025-10-02 02:30:00.207612
684	primary	public	index_user_invite_requests_on_user_id	8192	2025-10-02 02:30:00.207612
685	primary	public	index_users_on_reset_password_token	8192	2025-10-02 02:30:00.207612
686	primary	public	index_users_on_unconfirmed_email	8192	2025-10-02 02:30:00.207612
687	primary	public	index_web_push_subscriptions_on_access_token_id	8192	2025-10-02 02:30:00.207612
688	primary	public	index_web_push_subscriptions_on_user_id	8192	2025-10-02 02:30:00.207612
689	primary	public	index_webauthn_credentials_on_external_id	8192	2025-10-02 02:30:00.207612
690	primary	public	index_webauthn_credentials_on_user_id	8192	2025-10-02 02:30:00.207612
691	primary	public	index_webauthn_credentials_on_user_id_and_nickname	8192	2025-10-02 02:30:00.207612
692	primary	public	index_webhooks_on_url	8192	2025-10-02 02:30:00.207612
693	primary	public	instances	8192	2025-10-02 02:30:00.207612
694	primary	public	ip_blocks	8192	2025-10-02 02:30:00.207612
695	primary	public	ip_blocks_pkey	8192	2025-10-02 02:30:00.207612
696	primary	public	list_accounts_pkey	8192	2025-10-02 02:30:00.207612
697	primary	public	lists	8192	2025-10-02 02:30:00.207612
698	primary	public	lists_pkey	8192	2025-10-02 02:30:00.207612
699	primary	public	mentions_pkey	8192	2025-10-02 02:30:00.207612
700	primary	public	mutes_pkey	8192	2025-10-02 02:30:00.207612
701	primary	public	notification_permissions_pkey	8192	2025-10-02 02:30:00.207612
702	primary	public	notification_policies	8192	2025-10-02 02:30:00.207612
703	primary	public	notification_requests_pkey	8192	2025-10-02 02:30:00.207612
704	primary	public	preview_card_providers	8192	2025-10-02 02:30:00.207612
705	primary	public	preview_card_providers_pkey	8192	2025-10-02 02:30:00.207612
706	primary	public	preview_card_trends	8192	2025-10-02 02:30:00.207612
707	primary	public	preview_card_trends_pkey	8192	2025-10-02 02:30:00.207612
708	primary	public	preview_cards	8192	2025-10-02 02:30:00.207612
709	primary	public	preview_cards_pkey	8192	2025-10-02 02:30:00.207612
710	primary	public	preview_cards_statuses	8192	2025-10-02 02:30:00.207612
711	primary	public	preview_cards_statuses_pkey	8192	2025-10-02 02:30:00.207612
712	primary	public	relationship_severance_events	8192	2025-10-02 02:30:00.207612
713	primary	public	relationship_severance_events_pkey	8192	2025-10-02 02:30:00.207612
714	primary	public	relays	8192	2025-10-02 02:30:00.207612
715	primary	public	relays_pkey	8192	2025-10-02 02:30:00.207612
716	primary	public	report_notes	8192	2025-10-02 02:30:00.207612
717	primary	public	report_notes_pkey	8192	2025-10-02 02:30:00.207612
718	primary	public	rules	8192	2025-10-02 02:30:00.207612
719	primary	public	rules_pkey	8192	2025-10-02 02:30:00.207612
720	primary	public	scheduled_statuses	8192	2025-10-02 02:30:00.207612
721	primary	public	scheduled_statuses_pkey	8192	2025-10-02 02:30:00.207612
722	primary	public	settings	8192	2025-10-02 02:30:00.207612
723	primary	public	settings_pkey	8192	2025-10-02 02:30:00.207612
724	primary	public	severed_relationships	8192	2025-10-02 02:30:00.207612
725	primary	public	severed_relationships_pkey	8192	2025-10-02 02:30:00.207612
726	primary	public	site_uploads	8192	2025-10-02 02:30:00.207612
727	primary	public	site_uploads_pkey	8192	2025-10-02 02:30:00.207612
728	primary	public	status_pins_pkey	8192	2025-10-02 02:30:00.207612
729	primary	public	status_stats	8192	2025-10-02 02:30:00.207612
730	primary	public	status_trends	8192	2025-10-02 02:30:00.207612
731	primary	public	status_trends_pkey	8192	2025-10-02 02:30:00.207612
732	primary	public	statuses_tags	8192	2025-10-02 02:30:00.207612
733	primary	public	tag_follows_pkey	8192	2025-10-02 02:30:00.207612
734	primary	public	tombstones	8192	2025-10-02 02:30:00.207612
735	primary	public	tombstones_pkey	8192	2025-10-02 02:30:00.207612
736	primary	public	unavailable_domains	8192	2025-10-02 02:30:00.207612
737	primary	public	unavailable_domains_pkey	8192	2025-10-02 02:30:00.207612
738	primary	public	user_invite_requests	8192	2025-10-02 02:30:00.207612
739	primary	public	user_invite_requests_pkey	8192	2025-10-02 02:30:00.207612
740	primary	public	web_push_subscriptions	8192	2025-10-02 02:30:00.207612
741	primary	public	web_push_subscriptions_pkey	8192	2025-10-02 02:30:00.207612
742	primary	public	webauthn_credentials	8192	2025-10-02 02:30:00.207612
743	primary	public	webauthn_credentials_pkey	8192	2025-10-02 02:30:00.207612
744	primary	public	webhooks	8192	2025-10-02 02:30:00.207612
745	primary	public	webhooks_pkey	8192	2025-10-02 02:30:00.207612
746	primary	public	account_deletion_requests	0	2025-10-02 02:30:00.207612
747	primary	public	account_pins	0	2025-10-02 02:30:00.207612
748	primary	public	account_relationship_severance_events	0	2025-10-02 02:30:00.207612
749	primary	public	account_statuses_cleanup_policies	0	2025-10-02 02:30:00.207612
750	primary	public	accounts_tags	0	2025-10-02 02:30:00.207612
751	primary	public	announcement_mutes	0	2025-10-02 02:30:00.207612
752	primary	public	bookmarks	0	2025-10-02 02:30:00.207612
753	primary	public	conversation_mutes	0	2025-10-02 02:30:00.207612
754	primary	public	custom_filter_statuses	0	2025-10-02 02:30:00.207612
755	primary	public	favourites	0	2025-10-02 02:30:00.207612
756	primary	public	follow_recommendation_mutes	0	2025-10-02 02:30:00.207612
757	primary	public	follow_recommendation_suppressions	0	2025-10-02 02:30:00.207612
758	primary	public	list_accounts	0	2025-10-02 02:30:00.207612
759	primary	public	mentions	0	2025-10-02 02:30:00.207612
760	primary	public	mutes	0	2025-10-02 02:30:00.207612
761	primary	public	notification_permissions	0	2025-10-02 02:30:00.207612
762	primary	public	notification_requests	0	2025-10-02 02:30:00.207612
763	primary	public	status_pins	0	2025-10-02 02:30:00.207612
764	primary	public	tag_follows	0	2025-10-02 02:30:00.207612
765	primary	public	accounts	114688	2025-10-03 02:30:00.327163
766	primary	public	pghero_space_stats	114688	2025-10-03 02:30:00.327163
767	primary	public	media_attachments	57344	2025-10-03 02:30:00.327163
768	primary	public	schema_migrations	57344	2025-10-03 02:30:00.327163
769	primary	public	statuses	49152	2025-10-03 02:30:00.327163
770	primary	public	pghero_space_stats_pkey	32768	2025-10-03 02:30:00.327163
771	primary	public	schema_migrations_pkey	32768	2025-10-03 02:30:00.327163
772	primary	public	account_summaries	24576	2025-10-03 02:30:00.327163
773	primary	public	search_index	24576	2025-10-03 02:30:00.327163
774	primary	public	account_stats_pkey	16384	2025-10-03 02:30:00.327163
775	primary	public	accounts_pkey	16384	2025-10-03 02:30:00.327163
776	primary	public	ar_internal_metadata	16384	2025-10-03 02:30:00.327163
777	primary	public	ar_internal_metadata_pkey	16384	2025-10-03 02:30:00.327163
778	primary	public	conversations	16384	2025-10-03 02:30:00.327163
779	primary	public	conversations_pkey	16384	2025-10-03 02:30:00.327163
780	primary	public	custom_filter_keywords	16384	2025-10-03 02:30:00.327163
781	primary	public	custom_filter_keywords_pkey	16384	2025-10-03 02:30:00.327163
782	primary	public	custom_filters	16384	2025-10-03 02:30:00.327163
783	primary	public	custom_filters_pkey	16384	2025-10-03 02:30:00.327163
784	primary	public	follows	16384	2025-10-03 02:30:00.327163
785	primary	public	follows_pkey	16384	2025-10-03 02:30:00.327163
786	primary	public	idx_on_account_id_language_sensitive_250461e1eb	16384	2025-10-03 02:30:00.327163
787	primary	public	index_account_stats_on_account_id	16384	2025-10-03 02:30:00.327163
788	primary	public	index_account_stats_on_last_status_at_and_account_id	16384	2025-10-03 02:30:00.327163
789	primary	public	index_account_summaries_on_account_id	16384	2025-10-03 02:30:00.327163
790	primary	public	index_accounts_on_domain_and_id	16384	2025-10-03 02:30:00.327163
791	primary	public	index_accounts_on_uri	16384	2025-10-03 02:30:00.327163
792	primary	public	index_accounts_on_username_and_domain_lower	16384	2025-10-03 02:30:00.327163
793	primary	public	index_custom_filter_keywords_on_custom_filter_id	16384	2025-10-03 02:30:00.327163
794	primary	public	index_custom_filters_on_account_id	16384	2025-10-03 02:30:00.327163
795	primary	public	index_follows_on_account_id_and_target_account_id	16384	2025-10-03 02:30:00.327163
796	primary	public	index_follows_on_target_account_id	16384	2025-10-03 02:30:00.327163
797	primary	public	index_invites_on_code	16384	2025-10-03 02:30:00.327163
798	primary	public	index_invites_on_user_id	16384	2025-10-03 02:30:00.327163
799	primary	public	index_login_activities_on_user_id	16384	2025-10-03 02:30:00.327163
800	primary	public	index_markers_on_user_id_and_timeline	16384	2025-10-03 02:30:00.327163
801	primary	public	index_media_attachments_on_account_id_and_status_id	16384	2025-10-03 02:30:00.327163
802	primary	public	index_media_attachments_on_status_id	16384	2025-10-03 02:30:00.327163
803	primary	public	index_notification_policies_on_account_id	16384	2025-10-03 02:30:00.327163
804	primary	public	index_notifications_on_account_id_and_group_key	16384	2025-10-03 02:30:00.327163
805	primary	public	index_notifications_on_account_id_and_id_and_type	16384	2025-10-03 02:30:00.327163
806	primary	public	index_notifications_on_activity_id_and_activity_type	16384	2025-10-03 02:30:00.327163
807	primary	public	index_notifications_on_filtered	16384	2025-10-03 02:30:00.327163
808	primary	public	index_notifications_on_from_account_id	16384	2025-10-03 02:30:00.327163
809	primary	public	index_oauth_access_grants_on_resource_owner_id	16384	2025-10-03 02:30:00.327163
810	primary	public	index_oauth_access_grants_on_token	16384	2025-10-03 02:30:00.327163
811	primary	public	index_oauth_access_tokens_on_resource_owner_id	16384	2025-10-03 02:30:00.327163
812	primary	public	index_oauth_access_tokens_on_token	16384	2025-10-03 02:30:00.327163
813	primary	public	index_oauth_applications_on_owner_id_and_owner_type	16384	2025-10-03 02:30:00.327163
814	primary	public	index_oauth_applications_on_superapp	16384	2025-10-03 02:30:00.327163
815	primary	public	index_oauth_applications_on_uid	16384	2025-10-03 02:30:00.327163
816	primary	public	index_pghero_space_stats_on_database_and_captured_at	16384	2025-10-03 02:30:00.327163
817	primary	public	index_poll_votes_on_account_id	16384	2025-10-03 02:30:00.327163
818	primary	public	index_poll_votes_on_poll_id	16384	2025-10-03 02:30:00.327163
819	primary	public	index_polls_on_account_id	16384	2025-10-03 02:30:00.327163
820	primary	public	index_polls_on_status_id	16384	2025-10-03 02:30:00.327163
821	primary	public	index_reports_on_account_id	16384	2025-10-03 02:30:00.327163
822	primary	public	index_reports_on_target_account_id	16384	2025-10-03 02:30:00.327163
823	primary	public	index_session_activations_on_access_token_id	16384	2025-10-03 02:30:00.327163
824	primary	public	index_session_activations_on_session_id	16384	2025-10-03 02:30:00.327163
825	primary	public	index_session_activations_on_user_id	16384	2025-10-03 02:30:00.327163
826	primary	public	index_software_updates_on_version	16384	2025-10-03 02:30:00.327163
827	primary	public	index_status_edits_on_account_id	16384	2025-10-03 02:30:00.327163
828	primary	public	index_status_edits_on_status_id	16384	2025-10-03 02:30:00.327163
829	primary	public	index_status_stats_on_status_id	16384	2025-10-03 02:30:00.327163
830	primary	public	index_statuses_20190820	16384	2025-10-03 02:30:00.327163
831	primary	public	index_statuses_local_20190824	16384	2025-10-03 02:30:00.327163
832	primary	public	index_statuses_on_account_id	16384	2025-10-03 02:30:00.327163
833	primary	public	index_statuses_on_deleted_at	16384	2025-10-03 02:30:00.327163
834	primary	public	index_statuses_on_reblog_of_id_and_account_id	16384	2025-10-03 02:30:00.327163
835	primary	public	index_statuses_on_uri	16384	2025-10-03 02:30:00.327163
836	primary	public	index_statuses_public_20200119	16384	2025-10-03 02:30:00.327163
837	primary	public	index_statuses_tags_on_status_id	16384	2025-10-03 02:30:00.327163
838	primary	public	index_tags_on_name_lower_btree	16384	2025-10-03 02:30:00.327163
839	primary	public	index_users_on_account_id	16384	2025-10-03 02:30:00.327163
840	primary	public	index_users_on_confirmation_token	16384	2025-10-03 02:30:00.327163
841	primary	public	index_users_on_created_by_application_id	16384	2025-10-03 02:30:00.327163
842	primary	public	index_users_on_email	16384	2025-10-03 02:30:00.327163
843	primary	public	index_users_on_role_id	16384	2025-10-03 02:30:00.327163
844	primary	public	index_web_settings_on_user_id	16384	2025-10-03 02:30:00.327163
845	primary	public	invites	16384	2025-10-03 02:30:00.327163
846	primary	public	invites_pkey	16384	2025-10-03 02:30:00.327163
847	primary	public	login_activities	16384	2025-10-03 02:30:00.327163
848	primary	public	login_activities_pkey	16384	2025-10-03 02:30:00.327163
849	primary	public	markers	16384	2025-10-03 02:30:00.327163
850	primary	public	markers_pkey	16384	2025-10-03 02:30:00.327163
851	primary	public	media_attachments_pkey	16384	2025-10-03 02:30:00.327163
852	primary	public	notification_policies_pkey	16384	2025-10-03 02:30:00.327163
853	primary	public	notifications	16384	2025-10-03 02:30:00.327163
854	primary	public	notifications_pkey	16384	2025-10-03 02:30:00.327163
855	primary	public	oauth_access_grants	16384	2025-10-03 02:30:00.327163
856	primary	public	oauth_access_grants_pkey	16384	2025-10-03 02:30:00.327163
857	primary	public	oauth_access_tokens	16384	2025-10-03 02:30:00.327163
858	primary	public	oauth_access_tokens_pkey	16384	2025-10-03 02:30:00.327163
859	primary	public	oauth_applications	16384	2025-10-03 02:30:00.327163
860	primary	public	oauth_applications_pkey	16384	2025-10-03 02:30:00.327163
861	primary	public	poll_votes	16384	2025-10-03 02:30:00.327163
862	primary	public	poll_votes_pkey	16384	2025-10-03 02:30:00.327163
863	primary	public	polls	16384	2025-10-03 02:30:00.327163
864	primary	public	polls_pkey	16384	2025-10-03 02:30:00.327163
865	primary	public	reports	16384	2025-10-03 02:30:00.327163
866	primary	public	reports_pkey	16384	2025-10-03 02:30:00.327163
867	primary	public	session_activations	16384	2025-10-03 02:30:00.327163
868	primary	public	session_activations_pkey	16384	2025-10-03 02:30:00.327163
869	primary	public	software_updates	16384	2025-10-03 02:30:00.327163
870	primary	public	software_updates_pkey	16384	2025-10-03 02:30:00.327163
871	primary	public	status_edits	16384	2025-10-03 02:30:00.327163
872	primary	public	status_edits_pkey	16384	2025-10-03 02:30:00.327163
873	primary	public	status_stats_pkey	16384	2025-10-03 02:30:00.327163
874	primary	public	statuses_pkey	16384	2025-10-03 02:30:00.327163
875	primary	public	statuses_tags_pkey	16384	2025-10-03 02:30:00.327163
876	primary	public	tags	16384	2025-10-03 02:30:00.327163
877	primary	public	tags_pkey	16384	2025-10-03 02:30:00.327163
878	primary	public	user_roles	16384	2025-10-03 02:30:00.327163
879	primary	public	user_roles_pkey	16384	2025-10-03 02:30:00.327163
880	primary	public	users	16384	2025-10-03 02:30:00.327163
881	primary	public	users_pkey	16384	2025-10-03 02:30:00.327163
882	primary	public	web_settings	16384	2025-10-03 02:30:00.327163
883	primary	public	web_settings_pkey	16384	2025-10-03 02:30:00.327163
884	primary	public	account_aliases	8192	2025-10-03 02:30:00.327163
885	primary	public	account_aliases_pkey	8192	2025-10-03 02:30:00.327163
886	primary	public	account_conversations	8192	2025-10-03 02:30:00.327163
887	primary	public	account_conversations_pkey	8192	2025-10-03 02:30:00.327163
888	primary	public	account_deletion_requests_pkey	8192	2025-10-03 02:30:00.327163
889	primary	public	account_domain_blocks	8192	2025-10-03 02:30:00.327163
890	primary	public	account_domain_blocks_pkey	8192	2025-10-03 02:30:00.327163
891	primary	public	account_migrations	8192	2025-10-03 02:30:00.327163
892	primary	public	account_migrations_pkey	8192	2025-10-03 02:30:00.327163
893	primary	public	account_moderation_notes	8192	2025-10-03 02:30:00.327163
894	primary	public	account_moderation_notes_pkey	8192	2025-10-03 02:30:00.327163
895	primary	public	account_notes	8192	2025-10-03 02:30:00.327163
896	primary	public	account_notes_pkey	8192	2025-10-03 02:30:00.327163
897	primary	public	account_pins_pkey	8192	2025-10-03 02:30:00.327163
898	primary	public	account_relationship_severance_events_pkey	8192	2025-10-03 02:30:00.327163
899	primary	public	account_stats	8192	2025-10-03 02:30:00.327163
900	primary	public	account_statuses_cleanup_policies_pkey	8192	2025-10-03 02:30:00.327163
901	primary	public	account_warning_presets	8192	2025-10-03 02:30:00.327163
902	primary	public	account_warning_presets_pkey	8192	2025-10-03 02:30:00.327163
903	primary	public	account_warnings	8192	2025-10-03 02:30:00.327163
904	primary	public	account_warnings_pkey	8192	2025-10-03 02:30:00.327163
905	primary	public	accounts_tags_pkey	8192	2025-10-03 02:30:00.327163
906	primary	public	admin_action_logs	8192	2025-10-03 02:30:00.327163
907	primary	public	admin_action_logs_pkey	8192	2025-10-03 02:30:00.327163
908	primary	public	announcement_mutes_pkey	8192	2025-10-03 02:30:00.327163
909	primary	public	announcement_reactions	8192	2025-10-03 02:30:00.327163
910	primary	public	announcement_reactions_pkey	8192	2025-10-03 02:30:00.327163
911	primary	public	announcements	8192	2025-10-03 02:30:00.327163
912	primary	public	announcements_pkey	8192	2025-10-03 02:30:00.327163
913	primary	public	appeals	8192	2025-10-03 02:30:00.327163
914	primary	public	appeals_pkey	8192	2025-10-03 02:30:00.327163
915	primary	public	backups	8192	2025-10-03 02:30:00.327163
916	primary	public	backups_pkey	8192	2025-10-03 02:30:00.327163
917	primary	public	blocks	8192	2025-10-03 02:30:00.327163
918	primary	public	blocks_pkey	8192	2025-10-03 02:30:00.327163
919	primary	public	bookmarks_pkey	8192	2025-10-03 02:30:00.327163
920	primary	public	bulk_import_rows	8192	2025-10-03 02:30:00.327163
921	primary	public	bulk_import_rows_pkey	8192	2025-10-03 02:30:00.327163
922	primary	public	bulk_imports	8192	2025-10-03 02:30:00.327163
923	primary	public	bulk_imports_pkey	8192	2025-10-03 02:30:00.327163
924	primary	public	canonical_email_blocks	8192	2025-10-03 02:30:00.327163
925	primary	public	canonical_email_blocks_pkey	8192	2025-10-03 02:30:00.327163
926	primary	public	conversation_mutes_pkey	8192	2025-10-03 02:30:00.327163
927	primary	public	custom_emoji_categories	8192	2025-10-03 02:30:00.327163
928	primary	public	custom_emoji_categories_pkey	8192	2025-10-03 02:30:00.327163
929	primary	public	custom_emojis	8192	2025-10-03 02:30:00.327163
930	primary	public	custom_emojis_pkey	8192	2025-10-03 02:30:00.327163
931	primary	public	custom_filter_statuses_pkey	8192	2025-10-03 02:30:00.327163
932	primary	public	domain_allows	8192	2025-10-03 02:30:00.327163
933	primary	public	domain_allows_pkey	8192	2025-10-03 02:30:00.327163
934	primary	public	domain_blocks	8192	2025-10-03 02:30:00.327163
935	primary	public	domain_blocks_pkey	8192	2025-10-03 02:30:00.327163
936	primary	public	email_domain_blocks	8192	2025-10-03 02:30:00.327163
937	primary	public	email_domain_blocks_pkey	8192	2025-10-03 02:30:00.327163
938	primary	public	favourites_pkey	8192	2025-10-03 02:30:00.327163
939	primary	public	featured_tags	8192	2025-10-03 02:30:00.327163
940	primary	public	featured_tags_pkey	8192	2025-10-03 02:30:00.327163
941	primary	public	follow_recommendation_mutes_pkey	8192	2025-10-03 02:30:00.327163
942	primary	public	follow_recommendation_suppressions_pkey	8192	2025-10-03 02:30:00.327163
943	primary	public	follow_requests	8192	2025-10-03 02:30:00.327163
944	primary	public	follow_requests_pkey	8192	2025-10-03 02:30:00.327163
945	primary	public	generated_annual_reports	8192	2025-10-03 02:30:00.327163
946	primary	public	generated_annual_reports_pkey	8192	2025-10-03 02:30:00.327163
947	primary	public	global_follow_recommendations	8192	2025-10-03 02:30:00.327163
948	primary	public	identities	8192	2025-10-03 02:30:00.327163
949	primary	public	identities_pkey	8192	2025-10-03 02:30:00.327163
950	primary	public	idx_on_account_id_relationship_severance_event_id_7bd82bf20e	8192	2025-10-03 02:30:00.327163
951	primary	public	idx_on_account_id_target_account_id_a8c8ddf44e	8192	2025-10-03 02:30:00.327163
952	primary	public	idx_on_relationship_severance_event_id_403f53e707	8192	2025-10-03 02:30:00.327163
953	primary	public	imports	8192	2025-10-03 02:30:00.327163
954	primary	public	imports_pkey	8192	2025-10-03 02:30:00.327163
955	primary	public	index_account_aliases_on_account_id	8192	2025-10-03 02:30:00.327163
956	primary	public	index_account_aliases_on_account_id_and_uri	8192	2025-10-03 02:30:00.327163
957	primary	public	index_account_conversations_on_conversation_id	8192	2025-10-03 02:30:00.327163
958	primary	public	index_account_deletion_requests_on_account_id	8192	2025-10-03 02:30:00.327163
959	primary	public	index_account_domain_blocks_on_account_id_and_domain	8192	2025-10-03 02:30:00.327163
960	primary	public	index_account_migrations_on_account_id	8192	2025-10-03 02:30:00.327163
961	primary	public	index_account_migrations_on_target_account_id	8192	2025-10-03 02:30:00.327163
962	primary	public	index_account_moderation_notes_on_account_id	8192	2025-10-03 02:30:00.327163
963	primary	public	index_account_moderation_notes_on_target_account_id	8192	2025-10-03 02:30:00.327163
964	primary	public	index_account_notes_on_account_id_and_target_account_id	8192	2025-10-03 02:30:00.327163
965	primary	public	index_account_notes_on_target_account_id	8192	2025-10-03 02:30:00.327163
966	primary	public	index_account_pins_on_account_id_and_target_account_id	8192	2025-10-03 02:30:00.327163
967	primary	public	index_account_pins_on_target_account_id	8192	2025-10-03 02:30:00.327163
968	primary	public	index_account_relationship_severance_events_on_account_id	8192	2025-10-03 02:30:00.327163
969	primary	public	index_account_statuses_cleanup_policies_on_account_id	8192	2025-10-03 02:30:00.327163
970	primary	public	index_account_warnings_on_account_id	8192	2025-10-03 02:30:00.327163
971	primary	public	index_account_warnings_on_target_account_id	8192	2025-10-03 02:30:00.327163
972	primary	public	index_accounts_on_moved_to_account_id	8192	2025-10-03 02:30:00.327163
973	primary	public	index_accounts_on_url	8192	2025-10-03 02:30:00.327163
974	primary	public	index_accounts_tags_on_account_id_and_tag_id	8192	2025-10-03 02:30:00.327163
975	primary	public	index_admin_action_logs_on_account_id	8192	2025-10-03 02:30:00.327163
976	primary	public	index_admin_action_logs_on_target_type_and_target_id	8192	2025-10-03 02:30:00.327163
977	primary	public	index_announcement_mutes_on_account_id_and_announcement_id	8192	2025-10-03 02:30:00.327163
978	primary	public	index_announcement_mutes_on_announcement_id	8192	2025-10-03 02:30:00.327163
979	primary	public	index_announcement_reactions_on_account_id_and_announcement_id	8192	2025-10-03 02:30:00.327163
980	primary	public	index_announcement_reactions_on_announcement_id	8192	2025-10-03 02:30:00.327163
981	primary	public	index_announcement_reactions_on_custom_emoji_id	8192	2025-10-03 02:30:00.327163
982	primary	public	index_appeals_on_account_id	8192	2025-10-03 02:30:00.327163
983	primary	public	index_appeals_on_account_warning_id	8192	2025-10-03 02:30:00.327163
984	primary	public	index_appeals_on_approved_by_account_id	8192	2025-10-03 02:30:00.327163
985	primary	public	index_appeals_on_rejected_by_account_id	8192	2025-10-03 02:30:00.327163
986	primary	public	index_backups_on_user_id	8192	2025-10-03 02:30:00.327163
987	primary	public	index_blocks_on_account_id_and_target_account_id	8192	2025-10-03 02:30:00.327163
988	primary	public	index_blocks_on_target_account_id	8192	2025-10-03 02:30:00.327163
989	primary	public	index_bookmarks_on_account_id_and_status_id	8192	2025-10-03 02:30:00.327163
990	primary	public	index_bookmarks_on_status_id	8192	2025-10-03 02:30:00.327163
991	primary	public	index_bulk_import_rows_on_bulk_import_id	8192	2025-10-03 02:30:00.327163
992	primary	public	index_bulk_imports_on_account_id	8192	2025-10-03 02:30:00.327163
993	primary	public	index_bulk_imports_unconfirmed	8192	2025-10-03 02:30:00.327163
994	primary	public	index_canonical_email_blocks_on_canonical_email_hash	8192	2025-10-03 02:30:00.327163
995	primary	public	index_canonical_email_blocks_on_reference_account_id	8192	2025-10-03 02:30:00.327163
996	primary	public	index_conversation_mutes_on_account_id_and_conversation_id	8192	2025-10-03 02:30:00.327163
997	primary	public	index_conversations_on_uri	8192	2025-10-03 02:30:00.327163
998	primary	public	index_custom_emoji_categories_on_name	8192	2025-10-03 02:30:00.327163
999	primary	public	index_custom_emojis_on_shortcode_and_domain	8192	2025-10-03 02:30:00.327163
1000	primary	public	index_custom_filter_statuses_on_custom_filter_id	8192	2025-10-03 02:30:00.327163
1001	primary	public	index_custom_filter_statuses_on_status_id	8192	2025-10-03 02:30:00.327163
1002	primary	public	index_custom_filter_statuses_on_status_id_and_custom_filter_id	8192	2025-10-03 02:30:00.327163
1003	primary	public	index_domain_allows_on_domain	8192	2025-10-03 02:30:00.327163
1004	primary	public	index_domain_blocks_on_domain	8192	2025-10-03 02:30:00.327163
1005	primary	public	index_email_domain_blocks_on_domain	8192	2025-10-03 02:30:00.327163
1006	primary	public	index_favourites_on_account_id_and_id	8192	2025-10-03 02:30:00.327163
1007	primary	public	index_favourites_on_account_id_and_status_id	8192	2025-10-03 02:30:00.327163
1008	primary	public	index_favourites_on_status_id	8192	2025-10-03 02:30:00.327163
1009	primary	public	index_featured_tags_on_account_id_and_tag_id	8192	2025-10-03 02:30:00.327163
1010	primary	public	index_featured_tags_on_tag_id	8192	2025-10-03 02:30:00.327163
1011	primary	public	index_follow_recommendation_mutes_on_target_account_id	8192	2025-10-03 02:30:00.327163
1012	primary	public	index_follow_recommendation_suppressions_on_account_id	8192	2025-10-03 02:30:00.327163
1013	primary	public	index_follow_requests_on_account_id_and_target_account_id	8192	2025-10-03 02:30:00.327163
1014	primary	public	index_generated_annual_reports_on_account_id_and_year	8192	2025-10-03 02:30:00.327163
1015	primary	public	index_global_follow_recommendations_on_account_id	8192	2025-10-03 02:30:00.327163
1016	primary	public	index_identities_on_uid_and_provider	8192	2025-10-03 02:30:00.327163
1017	primary	public	index_identities_on_user_id	8192	2025-10-03 02:30:00.327163
1018	primary	public	index_instances_on_domain	8192	2025-10-03 02:30:00.327163
1019	primary	public	index_instances_on_reverse_domain	8192	2025-10-03 02:30:00.327163
1020	primary	public	index_ip_blocks_on_ip	8192	2025-10-03 02:30:00.327163
1021	primary	public	index_list_accounts_on_account_id_and_list_id	8192	2025-10-03 02:30:00.327163
1022	primary	public	index_list_accounts_on_follow_id	8192	2025-10-03 02:30:00.327163
1023	primary	public	index_list_accounts_on_follow_request_id	8192	2025-10-03 02:30:00.327163
1024	primary	public	index_list_accounts_on_list_id_and_account_id	8192	2025-10-03 02:30:00.327163
1025	primary	public	index_lists_on_account_id	8192	2025-10-03 02:30:00.327163
1026	primary	public	index_media_attachments_on_scheduled_status_id	8192	2025-10-03 02:30:00.327163
1027	primary	public	index_media_attachments_on_shortcode	8192	2025-10-03 02:30:00.327163
1028	primary	public	index_mentions_on_account_id_and_status_id	8192	2025-10-03 02:30:00.327163
1029	primary	public	index_mentions_on_status_id	8192	2025-10-03 02:30:00.327163
1030	primary	public	index_mutes_on_account_id_and_target_account_id	8192	2025-10-03 02:30:00.327163
1031	primary	public	index_mutes_on_target_account_id	8192	2025-10-03 02:30:00.327163
1032	primary	public	index_notification_permissions_on_account_id	8192	2025-10-03 02:30:00.327163
1033	primary	public	index_notification_permissions_on_from_account_id	8192	2025-10-03 02:30:00.327163
1034	primary	public	index_notification_requests_on_account_id_and_from_account_id	8192	2025-10-03 02:30:00.327163
1035	primary	public	index_notification_requests_on_from_account_id	8192	2025-10-03 02:30:00.327163
1036	primary	public	index_notification_requests_on_last_status_id	8192	2025-10-03 02:30:00.327163
1037	primary	public	index_oauth_access_tokens_on_refresh_token	8192	2025-10-03 02:30:00.327163
1038	primary	public	index_preview_card_providers_on_domain	8192	2025-10-03 02:30:00.327163
1039	primary	public	index_preview_card_trends_on_preview_card_id	8192	2025-10-03 02:30:00.327163
1040	primary	public	index_preview_cards_on_author_account_id	8192	2025-10-03 02:30:00.327163
1041	primary	public	index_preview_cards_on_url	8192	2025-10-03 02:30:00.327163
1042	primary	public	index_relationship_severance_events_on_type_and_target_name	8192	2025-10-03 02:30:00.327163
1043	primary	public	index_report_notes_on_account_id	8192	2025-10-03 02:30:00.327163
1044	primary	public	index_report_notes_on_report_id	8192	2025-10-03 02:30:00.327163
1045	primary	public	index_reports_on_action_taken_by_account_id	8192	2025-10-03 02:30:00.327163
1046	primary	public	index_reports_on_assigned_account_id	8192	2025-10-03 02:30:00.327163
1047	primary	public	index_scheduled_statuses_on_account_id	8192	2025-10-03 02:30:00.327163
1048	primary	public	index_scheduled_statuses_on_scheduled_at	8192	2025-10-03 02:30:00.327163
1049	primary	public	index_settings_on_thing_type_and_thing_id_and_var	8192	2025-10-03 02:30:00.327163
1050	primary	public	index_severed_relationships_on_local_account_and_event	8192	2025-10-03 02:30:00.327163
1051	primary	public	index_severed_relationships_on_remote_account_id	8192	2025-10-03 02:30:00.327163
1052	primary	public	index_severed_relationships_on_unique_tuples	8192	2025-10-03 02:30:00.327163
1053	primary	public	index_site_uploads_on_var	8192	2025-10-03 02:30:00.327163
1054	primary	public	index_status_pins_on_account_id_and_status_id	8192	2025-10-03 02:30:00.327163
1055	primary	public	index_status_pins_on_status_id	8192	2025-10-03 02:30:00.327163
1056	primary	public	index_status_trends_on_account_id	8192	2025-10-03 02:30:00.327163
1057	primary	public	index_status_trends_on_status_id	8192	2025-10-03 02:30:00.327163
1058	primary	public	index_statuses_on_in_reply_to_account_id	8192	2025-10-03 02:30:00.327163
1059	primary	public	index_statuses_on_in_reply_to_id	8192	2025-10-03 02:30:00.327163
1060	primary	public	index_tag_follows_on_account_id_and_tag_id	8192	2025-10-03 02:30:00.327163
1061	primary	public	index_tag_follows_on_tag_id	8192	2025-10-03 02:30:00.327163
1062	primary	public	index_tombstones_on_account_id	8192	2025-10-03 02:30:00.327163
1063	primary	public	index_tombstones_on_uri	8192	2025-10-03 02:30:00.327163
1064	primary	public	index_unavailable_domains_on_domain	8192	2025-10-03 02:30:00.327163
1065	primary	public	index_unique_conversations	8192	2025-10-03 02:30:00.327163
1066	primary	public	index_user_invite_requests_on_user_id	8192	2025-10-03 02:30:00.327163
1067	primary	public	index_users_on_reset_password_token	8192	2025-10-03 02:30:00.327163
1068	primary	public	index_users_on_unconfirmed_email	8192	2025-10-03 02:30:00.327163
1069	primary	public	index_web_push_subscriptions_on_access_token_id	8192	2025-10-03 02:30:00.327163
1070	primary	public	index_web_push_subscriptions_on_user_id	8192	2025-10-03 02:30:00.327163
1071	primary	public	index_webauthn_credentials_on_external_id	8192	2025-10-03 02:30:00.327163
1072	primary	public	index_webauthn_credentials_on_user_id	8192	2025-10-03 02:30:00.327163
1073	primary	public	index_webauthn_credentials_on_user_id_and_nickname	8192	2025-10-03 02:30:00.327163
1074	primary	public	index_webhooks_on_url	8192	2025-10-03 02:30:00.327163
1075	primary	public	instances	8192	2025-10-03 02:30:00.327163
1076	primary	public	ip_blocks	8192	2025-10-03 02:30:00.327163
1077	primary	public	ip_blocks_pkey	8192	2025-10-03 02:30:00.327163
1078	primary	public	list_accounts_pkey	8192	2025-10-03 02:30:00.327163
1079	primary	public	lists	8192	2025-10-03 02:30:00.327163
1080	primary	public	lists_pkey	8192	2025-10-03 02:30:00.327163
1081	primary	public	mentions_pkey	8192	2025-10-03 02:30:00.327163
1082	primary	public	mutes_pkey	8192	2025-10-03 02:30:00.327163
1083	primary	public	notification_permissions_pkey	8192	2025-10-03 02:30:00.327163
1084	primary	public	notification_policies	8192	2025-10-03 02:30:00.327163
1085	primary	public	notification_requests_pkey	8192	2025-10-03 02:30:00.327163
1086	primary	public	preview_card_providers	8192	2025-10-03 02:30:00.327163
1087	primary	public	preview_card_providers_pkey	8192	2025-10-03 02:30:00.327163
1088	primary	public	preview_card_trends	8192	2025-10-03 02:30:00.327163
1089	primary	public	preview_card_trends_pkey	8192	2025-10-03 02:30:00.327163
1090	primary	public	preview_cards	8192	2025-10-03 02:30:00.327163
1091	primary	public	preview_cards_pkey	8192	2025-10-03 02:30:00.327163
1092	primary	public	preview_cards_statuses	8192	2025-10-03 02:30:00.327163
1093	primary	public	preview_cards_statuses_pkey	8192	2025-10-03 02:30:00.327163
1094	primary	public	relationship_severance_events	8192	2025-10-03 02:30:00.327163
1095	primary	public	relationship_severance_events_pkey	8192	2025-10-03 02:30:00.327163
1096	primary	public	relays	8192	2025-10-03 02:30:00.327163
1097	primary	public	relays_pkey	8192	2025-10-03 02:30:00.327163
1098	primary	public	report_notes	8192	2025-10-03 02:30:00.327163
1099	primary	public	report_notes_pkey	8192	2025-10-03 02:30:00.327163
1100	primary	public	rules	8192	2025-10-03 02:30:00.327163
1101	primary	public	rules_pkey	8192	2025-10-03 02:30:00.327163
1102	primary	public	scheduled_statuses	8192	2025-10-03 02:30:00.327163
1103	primary	public	scheduled_statuses_pkey	8192	2025-10-03 02:30:00.327163
1104	primary	public	settings	8192	2025-10-03 02:30:00.327163
1105	primary	public	settings_pkey	8192	2025-10-03 02:30:00.327163
1106	primary	public	severed_relationships	8192	2025-10-03 02:30:00.327163
1107	primary	public	severed_relationships_pkey	8192	2025-10-03 02:30:00.327163
1108	primary	public	site_uploads	8192	2025-10-03 02:30:00.327163
1109	primary	public	site_uploads_pkey	8192	2025-10-03 02:30:00.327163
1110	primary	public	status_pins_pkey	8192	2025-10-03 02:30:00.327163
1111	primary	public	status_stats	8192	2025-10-03 02:30:00.327163
1112	primary	public	status_trends	8192	2025-10-03 02:30:00.327163
1113	primary	public	status_trends_pkey	8192	2025-10-03 02:30:00.327163
1114	primary	public	statuses_tags	8192	2025-10-03 02:30:00.327163
1115	primary	public	tag_follows_pkey	8192	2025-10-03 02:30:00.327163
1116	primary	public	tombstones	8192	2025-10-03 02:30:00.327163
1117	primary	public	tombstones_pkey	8192	2025-10-03 02:30:00.327163
1118	primary	public	unavailable_domains	8192	2025-10-03 02:30:00.327163
1119	primary	public	unavailable_domains_pkey	8192	2025-10-03 02:30:00.327163
1120	primary	public	user_invite_requests	8192	2025-10-03 02:30:00.327163
1121	primary	public	user_invite_requests_pkey	8192	2025-10-03 02:30:00.327163
1122	primary	public	web_push_subscriptions	8192	2025-10-03 02:30:00.327163
1123	primary	public	web_push_subscriptions_pkey	8192	2025-10-03 02:30:00.327163
1124	primary	public	webauthn_credentials	8192	2025-10-03 02:30:00.327163
1125	primary	public	webauthn_credentials_pkey	8192	2025-10-03 02:30:00.327163
1126	primary	public	webhooks	8192	2025-10-03 02:30:00.327163
1127	primary	public	webhooks_pkey	8192	2025-10-03 02:30:00.327163
1128	primary	public	account_deletion_requests	0	2025-10-03 02:30:00.327163
1129	primary	public	account_pins	0	2025-10-03 02:30:00.327163
1130	primary	public	account_relationship_severance_events	0	2025-10-03 02:30:00.327163
1131	primary	public	account_statuses_cleanup_policies	0	2025-10-03 02:30:00.327163
1132	primary	public	accounts_tags	0	2025-10-03 02:30:00.327163
1133	primary	public	announcement_mutes	0	2025-10-03 02:30:00.327163
1134	primary	public	bookmarks	0	2025-10-03 02:30:00.327163
1135	primary	public	conversation_mutes	0	2025-10-03 02:30:00.327163
1136	primary	public	custom_filter_statuses	0	2025-10-03 02:30:00.327163
1137	primary	public	favourites	0	2025-10-03 02:30:00.327163
1138	primary	public	follow_recommendation_mutes	0	2025-10-03 02:30:00.327163
1139	primary	public	follow_recommendation_suppressions	0	2025-10-03 02:30:00.327163
1140	primary	public	list_accounts	0	2025-10-03 02:30:00.327163
1141	primary	public	mentions	0	2025-10-03 02:30:00.327163
1142	primary	public	mutes	0	2025-10-03 02:30:00.327163
1143	primary	public	notification_permissions	0	2025-10-03 02:30:00.327163
1144	primary	public	notification_requests	0	2025-10-03 02:30:00.327163
1145	primary	public	status_pins	0	2025-10-03 02:30:00.327163
1146	primary	public	tag_follows	0	2025-10-03 02:30:00.327163
1147	primary	public	pghero_space_stats	147456	2025-10-04 06:30:00.134503
1148	primary	public	accounts	114688	2025-10-04 06:30:00.134503
1149	primary	public	media_attachments	57344	2025-10-04 06:30:00.134503
1150	primary	public	schema_migrations	57344	2025-10-04 06:30:00.134503
1151	primary	public	pghero_space_stats_pkey	49152	2025-10-04 06:30:00.134503
1152	primary	public	statuses	49152	2025-10-04 06:30:00.134503
1153	primary	public	schema_migrations_pkey	32768	2025-10-04 06:30:00.134503
1154	primary	public	account_summaries	24576	2025-10-04 06:30:00.134503
1155	primary	public	search_index	24576	2025-10-04 06:30:00.134503
1156	primary	public	account_stats_pkey	16384	2025-10-04 06:30:00.134503
1157	primary	public	accounts_pkey	16384	2025-10-04 06:30:00.134503
1158	primary	public	ar_internal_metadata	16384	2025-10-04 06:30:00.134503
1159	primary	public	ar_internal_metadata_pkey	16384	2025-10-04 06:30:00.134503
1160	primary	public	conversations	16384	2025-10-04 06:30:00.134503
1161	primary	public	conversations_pkey	16384	2025-10-04 06:30:00.134503
1162	primary	public	custom_filter_keywords	16384	2025-10-04 06:30:00.134503
1163	primary	public	custom_filter_keywords_pkey	16384	2025-10-04 06:30:00.134503
1164	primary	public	custom_filters	16384	2025-10-04 06:30:00.134503
1165	primary	public	custom_filters_pkey	16384	2025-10-04 06:30:00.134503
1166	primary	public	follows	16384	2025-10-04 06:30:00.134503
1167	primary	public	follows_pkey	16384	2025-10-04 06:30:00.134503
1168	primary	public	idx_on_account_id_language_sensitive_250461e1eb	16384	2025-10-04 06:30:00.134503
1169	primary	public	index_account_stats_on_account_id	16384	2025-10-04 06:30:00.134503
1170	primary	public	index_account_stats_on_last_status_at_and_account_id	16384	2025-10-04 06:30:00.134503
1171	primary	public	index_account_summaries_on_account_id	16384	2025-10-04 06:30:00.134503
1172	primary	public	index_accounts_on_domain_and_id	16384	2025-10-04 06:30:00.134503
1173	primary	public	index_accounts_on_uri	16384	2025-10-04 06:30:00.134503
1174	primary	public	index_accounts_on_username_and_domain_lower	16384	2025-10-04 06:30:00.134503
1175	primary	public	index_custom_filter_keywords_on_custom_filter_id	16384	2025-10-04 06:30:00.134503
1176	primary	public	index_custom_filters_on_account_id	16384	2025-10-04 06:30:00.134503
1177	primary	public	index_follows_on_account_id_and_target_account_id	16384	2025-10-04 06:30:00.134503
1178	primary	public	index_follows_on_target_account_id	16384	2025-10-04 06:30:00.134503
1179	primary	public	index_invites_on_code	16384	2025-10-04 06:30:00.134503
1180	primary	public	index_invites_on_user_id	16384	2025-10-04 06:30:00.134503
1181	primary	public	index_login_activities_on_user_id	16384	2025-10-04 06:30:00.134503
1182	primary	public	index_markers_on_user_id_and_timeline	16384	2025-10-04 06:30:00.134503
1183	primary	public	index_media_attachments_on_account_id_and_status_id	16384	2025-10-04 06:30:00.134503
1184	primary	public	index_media_attachments_on_status_id	16384	2025-10-04 06:30:00.134503
1185	primary	public	index_notification_policies_on_account_id	16384	2025-10-04 06:30:00.134503
1186	primary	public	index_notifications_on_account_id_and_group_key	16384	2025-10-04 06:30:00.134503
1187	primary	public	index_notifications_on_account_id_and_id_and_type	16384	2025-10-04 06:30:00.134503
1188	primary	public	index_notifications_on_activity_id_and_activity_type	16384	2025-10-04 06:30:00.134503
1189	primary	public	index_notifications_on_filtered	16384	2025-10-04 06:30:00.134503
1190	primary	public	index_notifications_on_from_account_id	16384	2025-10-04 06:30:00.134503
1191	primary	public	index_oauth_access_grants_on_resource_owner_id	16384	2025-10-04 06:30:00.134503
1192	primary	public	index_oauth_access_grants_on_token	16384	2025-10-04 06:30:00.134503
1193	primary	public	index_oauth_access_tokens_on_resource_owner_id	16384	2025-10-04 06:30:00.134503
1194	primary	public	index_oauth_access_tokens_on_token	16384	2025-10-04 06:30:00.134503
1195	primary	public	index_oauth_applications_on_owner_id_and_owner_type	16384	2025-10-04 06:30:00.134503
1196	primary	public	index_oauth_applications_on_superapp	16384	2025-10-04 06:30:00.134503
1197	primary	public	index_oauth_applications_on_uid	16384	2025-10-04 06:30:00.134503
1198	primary	public	index_pghero_space_stats_on_database_and_captured_at	16384	2025-10-04 06:30:00.134503
1199	primary	public	index_poll_votes_on_account_id	16384	2025-10-04 06:30:00.134503
1200	primary	public	index_poll_votes_on_poll_id	16384	2025-10-04 06:30:00.134503
1201	primary	public	index_polls_on_account_id	16384	2025-10-04 06:30:00.134503
1202	primary	public	index_polls_on_status_id	16384	2025-10-04 06:30:00.134503
1203	primary	public	index_reports_on_account_id	16384	2025-10-04 06:30:00.134503
1204	primary	public	index_reports_on_target_account_id	16384	2025-10-04 06:30:00.134503
1205	primary	public	index_session_activations_on_access_token_id	16384	2025-10-04 06:30:00.134503
1206	primary	public	index_session_activations_on_session_id	16384	2025-10-04 06:30:00.134503
1207	primary	public	index_session_activations_on_user_id	16384	2025-10-04 06:30:00.134503
1208	primary	public	index_software_updates_on_version	16384	2025-10-04 06:30:00.134503
1209	primary	public	index_status_edits_on_account_id	16384	2025-10-04 06:30:00.134503
1210	primary	public	index_status_edits_on_status_id	16384	2025-10-04 06:30:00.134503
1211	primary	public	index_status_stats_on_status_id	16384	2025-10-04 06:30:00.134503
1212	primary	public	index_statuses_20190820	16384	2025-10-04 06:30:00.134503
1213	primary	public	index_statuses_local_20190824	16384	2025-10-04 06:30:00.134503
1214	primary	public	index_statuses_on_account_id	16384	2025-10-04 06:30:00.134503
1215	primary	public	index_statuses_on_deleted_at	16384	2025-10-04 06:30:00.134503
1216	primary	public	index_statuses_on_reblog_of_id_and_account_id	16384	2025-10-04 06:30:00.134503
1217	primary	public	index_statuses_on_uri	16384	2025-10-04 06:30:00.134503
1218	primary	public	index_statuses_public_20200119	16384	2025-10-04 06:30:00.134503
1219	primary	public	index_statuses_tags_on_status_id	16384	2025-10-04 06:30:00.134503
1220	primary	public	index_tags_on_name_lower_btree	16384	2025-10-04 06:30:00.134503
1221	primary	public	index_users_on_account_id	16384	2025-10-04 06:30:00.134503
1222	primary	public	index_users_on_confirmation_token	16384	2025-10-04 06:30:00.134503
1223	primary	public	index_users_on_created_by_application_id	16384	2025-10-04 06:30:00.134503
1224	primary	public	index_users_on_email	16384	2025-10-04 06:30:00.134503
1225	primary	public	index_users_on_role_id	16384	2025-10-04 06:30:00.134503
1226	primary	public	index_web_settings_on_user_id	16384	2025-10-04 06:30:00.134503
1227	primary	public	invites	16384	2025-10-04 06:30:00.134503
1228	primary	public	invites_pkey	16384	2025-10-04 06:30:00.134503
1229	primary	public	login_activities	16384	2025-10-04 06:30:00.134503
1230	primary	public	login_activities_pkey	16384	2025-10-04 06:30:00.134503
1231	primary	public	markers	16384	2025-10-04 06:30:00.134503
1232	primary	public	markers_pkey	16384	2025-10-04 06:30:00.134503
1233	primary	public	media_attachments_pkey	16384	2025-10-04 06:30:00.134503
1234	primary	public	notification_policies_pkey	16384	2025-10-04 06:30:00.134503
1235	primary	public	notifications	16384	2025-10-04 06:30:00.134503
1236	primary	public	notifications_pkey	16384	2025-10-04 06:30:00.134503
1237	primary	public	oauth_access_grants	16384	2025-10-04 06:30:00.134503
1238	primary	public	oauth_access_grants_pkey	16384	2025-10-04 06:30:00.134503
1239	primary	public	oauth_access_tokens	16384	2025-10-04 06:30:00.134503
1240	primary	public	oauth_access_tokens_pkey	16384	2025-10-04 06:30:00.134503
1241	primary	public	oauth_applications	16384	2025-10-04 06:30:00.134503
1242	primary	public	oauth_applications_pkey	16384	2025-10-04 06:30:00.134503
1243	primary	public	poll_votes	16384	2025-10-04 06:30:00.134503
1244	primary	public	poll_votes_pkey	16384	2025-10-04 06:30:00.134503
1245	primary	public	polls	16384	2025-10-04 06:30:00.134503
1246	primary	public	polls_pkey	16384	2025-10-04 06:30:00.134503
1247	primary	public	reports	16384	2025-10-04 06:30:00.134503
1248	primary	public	reports_pkey	16384	2025-10-04 06:30:00.134503
1249	primary	public	session_activations	16384	2025-10-04 06:30:00.134503
1250	primary	public	session_activations_pkey	16384	2025-10-04 06:30:00.134503
1251	primary	public	software_updates	16384	2025-10-04 06:30:00.134503
1252	primary	public	software_updates_pkey	16384	2025-10-04 06:30:00.134503
1253	primary	public	status_edits	16384	2025-10-04 06:30:00.134503
1254	primary	public	status_edits_pkey	16384	2025-10-04 06:30:00.134503
1255	primary	public	status_stats_pkey	16384	2025-10-04 06:30:00.134503
1256	primary	public	statuses_pkey	16384	2025-10-04 06:30:00.134503
1257	primary	public	statuses_tags_pkey	16384	2025-10-04 06:30:00.134503
1258	primary	public	tags	16384	2025-10-04 06:30:00.134503
1259	primary	public	tags_pkey	16384	2025-10-04 06:30:00.134503
1260	primary	public	user_roles	16384	2025-10-04 06:30:00.134503
1261	primary	public	user_roles_pkey	16384	2025-10-04 06:30:00.134503
1262	primary	public	users	16384	2025-10-04 06:30:00.134503
1263	primary	public	users_pkey	16384	2025-10-04 06:30:00.134503
1264	primary	public	web_settings	16384	2025-10-04 06:30:00.134503
1265	primary	public	web_settings_pkey	16384	2025-10-04 06:30:00.134503
1266	primary	public	account_aliases	8192	2025-10-04 06:30:00.134503
1267	primary	public	account_aliases_pkey	8192	2025-10-04 06:30:00.134503
1268	primary	public	account_conversations	8192	2025-10-04 06:30:00.134503
1269	primary	public	account_conversations_pkey	8192	2025-10-04 06:30:00.134503
1270	primary	public	account_deletion_requests_pkey	8192	2025-10-04 06:30:00.134503
1271	primary	public	account_domain_blocks	8192	2025-10-04 06:30:00.134503
1272	primary	public	account_domain_blocks_pkey	8192	2025-10-04 06:30:00.134503
1273	primary	public	account_migrations	8192	2025-10-04 06:30:00.134503
1274	primary	public	account_migrations_pkey	8192	2025-10-04 06:30:00.134503
1275	primary	public	account_moderation_notes	8192	2025-10-04 06:30:00.134503
1276	primary	public	account_moderation_notes_pkey	8192	2025-10-04 06:30:00.134503
1277	primary	public	account_notes	8192	2025-10-04 06:30:00.134503
1278	primary	public	account_notes_pkey	8192	2025-10-04 06:30:00.134503
1279	primary	public	account_pins_pkey	8192	2025-10-04 06:30:00.134503
1280	primary	public	account_relationship_severance_events_pkey	8192	2025-10-04 06:30:00.134503
1281	primary	public	account_stats	8192	2025-10-04 06:30:00.134503
1282	primary	public	account_statuses_cleanup_policies_pkey	8192	2025-10-04 06:30:00.134503
1283	primary	public	account_warning_presets	8192	2025-10-04 06:30:00.134503
1284	primary	public	account_warning_presets_pkey	8192	2025-10-04 06:30:00.134503
1285	primary	public	account_warnings	8192	2025-10-04 06:30:00.134503
1286	primary	public	account_warnings_pkey	8192	2025-10-04 06:30:00.134503
1287	primary	public	accounts_tags_pkey	8192	2025-10-04 06:30:00.134503
1288	primary	public	admin_action_logs	8192	2025-10-04 06:30:00.134503
1289	primary	public	admin_action_logs_pkey	8192	2025-10-04 06:30:00.134503
1290	primary	public	announcement_mutes_pkey	8192	2025-10-04 06:30:00.134503
1291	primary	public	announcement_reactions	8192	2025-10-04 06:30:00.134503
1292	primary	public	announcement_reactions_pkey	8192	2025-10-04 06:30:00.134503
1293	primary	public	announcements	8192	2025-10-04 06:30:00.134503
1294	primary	public	announcements_pkey	8192	2025-10-04 06:30:00.134503
1295	primary	public	appeals	8192	2025-10-04 06:30:00.134503
1296	primary	public	appeals_pkey	8192	2025-10-04 06:30:00.134503
1297	primary	public	backups	8192	2025-10-04 06:30:00.134503
1298	primary	public	backups_pkey	8192	2025-10-04 06:30:00.134503
1299	primary	public	blocks	8192	2025-10-04 06:30:00.134503
1300	primary	public	blocks_pkey	8192	2025-10-04 06:30:00.134503
1301	primary	public	bookmarks_pkey	8192	2025-10-04 06:30:00.134503
1302	primary	public	bulk_import_rows	8192	2025-10-04 06:30:00.134503
1303	primary	public	bulk_import_rows_pkey	8192	2025-10-04 06:30:00.134503
1304	primary	public	bulk_imports	8192	2025-10-04 06:30:00.134503
1305	primary	public	bulk_imports_pkey	8192	2025-10-04 06:30:00.134503
1306	primary	public	canonical_email_blocks	8192	2025-10-04 06:30:00.134503
1307	primary	public	canonical_email_blocks_pkey	8192	2025-10-04 06:30:00.134503
1308	primary	public	conversation_mutes_pkey	8192	2025-10-04 06:30:00.134503
1309	primary	public	custom_emoji_categories	8192	2025-10-04 06:30:00.134503
1310	primary	public	custom_emoji_categories_pkey	8192	2025-10-04 06:30:00.134503
1311	primary	public	custom_emojis	8192	2025-10-04 06:30:00.134503
1312	primary	public	custom_emojis_pkey	8192	2025-10-04 06:30:00.134503
1313	primary	public	custom_filter_statuses_pkey	8192	2025-10-04 06:30:00.134503
1314	primary	public	domain_allows	8192	2025-10-04 06:30:00.134503
1315	primary	public	domain_allows_pkey	8192	2025-10-04 06:30:00.134503
1316	primary	public	domain_blocks	8192	2025-10-04 06:30:00.134503
1317	primary	public	domain_blocks_pkey	8192	2025-10-04 06:30:00.134503
1318	primary	public	email_domain_blocks	8192	2025-10-04 06:30:00.134503
1319	primary	public	email_domain_blocks_pkey	8192	2025-10-04 06:30:00.134503
1320	primary	public	favourites_pkey	8192	2025-10-04 06:30:00.134503
1321	primary	public	featured_tags	8192	2025-10-04 06:30:00.134503
1322	primary	public	featured_tags_pkey	8192	2025-10-04 06:30:00.134503
1323	primary	public	follow_recommendation_mutes_pkey	8192	2025-10-04 06:30:00.134503
1324	primary	public	follow_recommendation_suppressions_pkey	8192	2025-10-04 06:30:00.134503
1325	primary	public	follow_requests	8192	2025-10-04 06:30:00.134503
1326	primary	public	follow_requests_pkey	8192	2025-10-04 06:30:00.134503
1327	primary	public	generated_annual_reports	8192	2025-10-04 06:30:00.134503
1328	primary	public	generated_annual_reports_pkey	8192	2025-10-04 06:30:00.134503
1329	primary	public	global_follow_recommendations	8192	2025-10-04 06:30:00.134503
1330	primary	public	identities	8192	2025-10-04 06:30:00.134503
1331	primary	public	identities_pkey	8192	2025-10-04 06:30:00.134503
1332	primary	public	idx_on_account_id_relationship_severance_event_id_7bd82bf20e	8192	2025-10-04 06:30:00.134503
1333	primary	public	idx_on_account_id_target_account_id_a8c8ddf44e	8192	2025-10-04 06:30:00.134503
1334	primary	public	idx_on_relationship_severance_event_id_403f53e707	8192	2025-10-04 06:30:00.134503
1335	primary	public	imports	8192	2025-10-04 06:30:00.134503
1336	primary	public	imports_pkey	8192	2025-10-04 06:30:00.134503
1337	primary	public	index_account_aliases_on_account_id	8192	2025-10-04 06:30:00.134503
1338	primary	public	index_account_aliases_on_account_id_and_uri	8192	2025-10-04 06:30:00.134503
1339	primary	public	index_account_conversations_on_conversation_id	8192	2025-10-04 06:30:00.134503
1340	primary	public	index_account_deletion_requests_on_account_id	8192	2025-10-04 06:30:00.134503
1341	primary	public	index_account_domain_blocks_on_account_id_and_domain	8192	2025-10-04 06:30:00.134503
1342	primary	public	index_account_migrations_on_account_id	8192	2025-10-04 06:30:00.134503
1343	primary	public	index_account_migrations_on_target_account_id	8192	2025-10-04 06:30:00.134503
1344	primary	public	index_account_moderation_notes_on_account_id	8192	2025-10-04 06:30:00.134503
1345	primary	public	index_account_moderation_notes_on_target_account_id	8192	2025-10-04 06:30:00.134503
1346	primary	public	index_account_notes_on_account_id_and_target_account_id	8192	2025-10-04 06:30:00.134503
1347	primary	public	index_account_notes_on_target_account_id	8192	2025-10-04 06:30:00.134503
1348	primary	public	index_account_pins_on_account_id_and_target_account_id	8192	2025-10-04 06:30:00.134503
1349	primary	public	index_account_pins_on_target_account_id	8192	2025-10-04 06:30:00.134503
1350	primary	public	index_account_relationship_severance_events_on_account_id	8192	2025-10-04 06:30:00.134503
1351	primary	public	index_account_statuses_cleanup_policies_on_account_id	8192	2025-10-04 06:30:00.134503
1352	primary	public	index_account_warnings_on_account_id	8192	2025-10-04 06:30:00.134503
1353	primary	public	index_account_warnings_on_target_account_id	8192	2025-10-04 06:30:00.134503
1354	primary	public	index_accounts_on_moved_to_account_id	8192	2025-10-04 06:30:00.134503
1355	primary	public	index_accounts_on_url	8192	2025-10-04 06:30:00.134503
1356	primary	public	index_accounts_tags_on_account_id_and_tag_id	8192	2025-10-04 06:30:00.134503
1357	primary	public	index_admin_action_logs_on_account_id	8192	2025-10-04 06:30:00.134503
1358	primary	public	index_admin_action_logs_on_target_type_and_target_id	8192	2025-10-04 06:30:00.134503
1359	primary	public	index_announcement_mutes_on_account_id_and_announcement_id	8192	2025-10-04 06:30:00.134503
1360	primary	public	index_announcement_mutes_on_announcement_id	8192	2025-10-04 06:30:00.134503
1361	primary	public	index_announcement_reactions_on_account_id_and_announcement_id	8192	2025-10-04 06:30:00.134503
1362	primary	public	index_announcement_reactions_on_announcement_id	8192	2025-10-04 06:30:00.134503
1363	primary	public	index_announcement_reactions_on_custom_emoji_id	8192	2025-10-04 06:30:00.134503
1364	primary	public	index_appeals_on_account_id	8192	2025-10-04 06:30:00.134503
1365	primary	public	index_appeals_on_account_warning_id	8192	2025-10-04 06:30:00.134503
1366	primary	public	index_appeals_on_approved_by_account_id	8192	2025-10-04 06:30:00.134503
1367	primary	public	index_appeals_on_rejected_by_account_id	8192	2025-10-04 06:30:00.134503
1368	primary	public	index_backups_on_user_id	8192	2025-10-04 06:30:00.134503
1369	primary	public	index_blocks_on_account_id_and_target_account_id	8192	2025-10-04 06:30:00.134503
1370	primary	public	index_blocks_on_target_account_id	8192	2025-10-04 06:30:00.134503
1371	primary	public	index_bookmarks_on_account_id_and_status_id	8192	2025-10-04 06:30:00.134503
1372	primary	public	index_bookmarks_on_status_id	8192	2025-10-04 06:30:00.134503
1373	primary	public	index_bulk_import_rows_on_bulk_import_id	8192	2025-10-04 06:30:00.134503
1374	primary	public	index_bulk_imports_on_account_id	8192	2025-10-04 06:30:00.134503
1375	primary	public	index_bulk_imports_unconfirmed	8192	2025-10-04 06:30:00.134503
1376	primary	public	index_canonical_email_blocks_on_canonical_email_hash	8192	2025-10-04 06:30:00.134503
1377	primary	public	index_canonical_email_blocks_on_reference_account_id	8192	2025-10-04 06:30:00.134503
1378	primary	public	index_conversation_mutes_on_account_id_and_conversation_id	8192	2025-10-04 06:30:00.134503
1379	primary	public	index_conversations_on_uri	8192	2025-10-04 06:30:00.134503
1380	primary	public	index_custom_emoji_categories_on_name	8192	2025-10-04 06:30:00.134503
1381	primary	public	index_custom_emojis_on_shortcode_and_domain	8192	2025-10-04 06:30:00.134503
1382	primary	public	index_custom_filter_statuses_on_custom_filter_id	8192	2025-10-04 06:30:00.134503
1383	primary	public	index_custom_filter_statuses_on_status_id	8192	2025-10-04 06:30:00.134503
1384	primary	public	index_custom_filter_statuses_on_status_id_and_custom_filter_id	8192	2025-10-04 06:30:00.134503
1385	primary	public	index_domain_allows_on_domain	8192	2025-10-04 06:30:00.134503
1386	primary	public	index_domain_blocks_on_domain	8192	2025-10-04 06:30:00.134503
1387	primary	public	index_email_domain_blocks_on_domain	8192	2025-10-04 06:30:00.134503
1388	primary	public	index_favourites_on_account_id_and_id	8192	2025-10-04 06:30:00.134503
1389	primary	public	index_favourites_on_account_id_and_status_id	8192	2025-10-04 06:30:00.134503
1390	primary	public	index_favourites_on_status_id	8192	2025-10-04 06:30:00.134503
1391	primary	public	index_featured_tags_on_account_id_and_tag_id	8192	2025-10-04 06:30:00.134503
1392	primary	public	index_featured_tags_on_tag_id	8192	2025-10-04 06:30:00.134503
1469	primary	public	preview_card_providers_pkey	8192	2025-10-04 06:30:00.134503
1393	primary	public	index_follow_recommendation_mutes_on_target_account_id	8192	2025-10-04 06:30:00.134503
1394	primary	public	index_follow_recommendation_suppressions_on_account_id	8192	2025-10-04 06:30:00.134503
1395	primary	public	index_follow_requests_on_account_id_and_target_account_id	8192	2025-10-04 06:30:00.134503
1396	primary	public	index_generated_annual_reports_on_account_id_and_year	8192	2025-10-04 06:30:00.134503
1397	primary	public	index_global_follow_recommendations_on_account_id	8192	2025-10-04 06:30:00.134503
1398	primary	public	index_identities_on_uid_and_provider	8192	2025-10-04 06:30:00.134503
1399	primary	public	index_identities_on_user_id	8192	2025-10-04 06:30:00.134503
1400	primary	public	index_instances_on_domain	8192	2025-10-04 06:30:00.134503
1401	primary	public	index_instances_on_reverse_domain	8192	2025-10-04 06:30:00.134503
1402	primary	public	index_ip_blocks_on_ip	8192	2025-10-04 06:30:00.134503
1403	primary	public	index_list_accounts_on_account_id_and_list_id	8192	2025-10-04 06:30:00.134503
1404	primary	public	index_list_accounts_on_follow_id	8192	2025-10-04 06:30:00.134503
1405	primary	public	index_list_accounts_on_follow_request_id	8192	2025-10-04 06:30:00.134503
1406	primary	public	index_list_accounts_on_list_id_and_account_id	8192	2025-10-04 06:30:00.134503
1407	primary	public	index_lists_on_account_id	8192	2025-10-04 06:30:00.134503
1408	primary	public	index_media_attachments_on_scheduled_status_id	8192	2025-10-04 06:30:00.134503
1409	primary	public	index_media_attachments_on_shortcode	8192	2025-10-04 06:30:00.134503
1410	primary	public	index_mentions_on_account_id_and_status_id	8192	2025-10-04 06:30:00.134503
1411	primary	public	index_mentions_on_status_id	8192	2025-10-04 06:30:00.134503
1412	primary	public	index_mutes_on_account_id_and_target_account_id	8192	2025-10-04 06:30:00.134503
1413	primary	public	index_mutes_on_target_account_id	8192	2025-10-04 06:30:00.134503
1414	primary	public	index_notification_permissions_on_account_id	8192	2025-10-04 06:30:00.134503
1415	primary	public	index_notification_permissions_on_from_account_id	8192	2025-10-04 06:30:00.134503
1416	primary	public	index_notification_requests_on_account_id_and_from_account_id	8192	2025-10-04 06:30:00.134503
1417	primary	public	index_notification_requests_on_from_account_id	8192	2025-10-04 06:30:00.134503
1418	primary	public	index_notification_requests_on_last_status_id	8192	2025-10-04 06:30:00.134503
1419	primary	public	index_oauth_access_tokens_on_refresh_token	8192	2025-10-04 06:30:00.134503
1420	primary	public	index_preview_card_providers_on_domain	8192	2025-10-04 06:30:00.134503
1421	primary	public	index_preview_card_trends_on_preview_card_id	8192	2025-10-04 06:30:00.134503
1422	primary	public	index_preview_cards_on_author_account_id	8192	2025-10-04 06:30:00.134503
1423	primary	public	index_preview_cards_on_url	8192	2025-10-04 06:30:00.134503
1424	primary	public	index_relationship_severance_events_on_type_and_target_name	8192	2025-10-04 06:30:00.134503
1425	primary	public	index_report_notes_on_account_id	8192	2025-10-04 06:30:00.134503
1426	primary	public	index_report_notes_on_report_id	8192	2025-10-04 06:30:00.134503
1427	primary	public	index_reports_on_action_taken_by_account_id	8192	2025-10-04 06:30:00.134503
1428	primary	public	index_reports_on_assigned_account_id	8192	2025-10-04 06:30:00.134503
1429	primary	public	index_scheduled_statuses_on_account_id	8192	2025-10-04 06:30:00.134503
1430	primary	public	index_scheduled_statuses_on_scheduled_at	8192	2025-10-04 06:30:00.134503
1431	primary	public	index_settings_on_thing_type_and_thing_id_and_var	8192	2025-10-04 06:30:00.134503
1432	primary	public	index_severed_relationships_on_local_account_and_event	8192	2025-10-04 06:30:00.134503
1433	primary	public	index_severed_relationships_on_remote_account_id	8192	2025-10-04 06:30:00.134503
1434	primary	public	index_severed_relationships_on_unique_tuples	8192	2025-10-04 06:30:00.134503
1435	primary	public	index_site_uploads_on_var	8192	2025-10-04 06:30:00.134503
1436	primary	public	index_status_pins_on_account_id_and_status_id	8192	2025-10-04 06:30:00.134503
1437	primary	public	index_status_pins_on_status_id	8192	2025-10-04 06:30:00.134503
1438	primary	public	index_status_trends_on_account_id	8192	2025-10-04 06:30:00.134503
1439	primary	public	index_status_trends_on_status_id	8192	2025-10-04 06:30:00.134503
1440	primary	public	index_statuses_on_in_reply_to_account_id	8192	2025-10-04 06:30:00.134503
1441	primary	public	index_statuses_on_in_reply_to_id	8192	2025-10-04 06:30:00.134503
1442	primary	public	index_tag_follows_on_account_id_and_tag_id	8192	2025-10-04 06:30:00.134503
1443	primary	public	index_tag_follows_on_tag_id	8192	2025-10-04 06:30:00.134503
1444	primary	public	index_tombstones_on_account_id	8192	2025-10-04 06:30:00.134503
1445	primary	public	index_tombstones_on_uri	8192	2025-10-04 06:30:00.134503
1446	primary	public	index_unavailable_domains_on_domain	8192	2025-10-04 06:30:00.134503
1447	primary	public	index_unique_conversations	8192	2025-10-04 06:30:00.134503
1448	primary	public	index_user_invite_requests_on_user_id	8192	2025-10-04 06:30:00.134503
1449	primary	public	index_users_on_reset_password_token	8192	2025-10-04 06:30:00.134503
1450	primary	public	index_users_on_unconfirmed_email	8192	2025-10-04 06:30:00.134503
1451	primary	public	index_web_push_subscriptions_on_access_token_id	8192	2025-10-04 06:30:00.134503
1452	primary	public	index_web_push_subscriptions_on_user_id	8192	2025-10-04 06:30:00.134503
1453	primary	public	index_webauthn_credentials_on_external_id	8192	2025-10-04 06:30:00.134503
1454	primary	public	index_webauthn_credentials_on_user_id	8192	2025-10-04 06:30:00.134503
1455	primary	public	index_webauthn_credentials_on_user_id_and_nickname	8192	2025-10-04 06:30:00.134503
1456	primary	public	index_webhooks_on_url	8192	2025-10-04 06:30:00.134503
1457	primary	public	instances	8192	2025-10-04 06:30:00.134503
1458	primary	public	ip_blocks	8192	2025-10-04 06:30:00.134503
1459	primary	public	ip_blocks_pkey	8192	2025-10-04 06:30:00.134503
1460	primary	public	list_accounts_pkey	8192	2025-10-04 06:30:00.134503
1461	primary	public	lists	8192	2025-10-04 06:30:00.134503
1462	primary	public	lists_pkey	8192	2025-10-04 06:30:00.134503
1463	primary	public	mentions_pkey	8192	2025-10-04 06:30:00.134503
1464	primary	public	mutes_pkey	8192	2025-10-04 06:30:00.134503
1465	primary	public	notification_permissions_pkey	8192	2025-10-04 06:30:00.134503
1466	primary	public	notification_policies	8192	2025-10-04 06:30:00.134503
1467	primary	public	notification_requests_pkey	8192	2025-10-04 06:30:00.134503
1468	primary	public	preview_card_providers	8192	2025-10-04 06:30:00.134503
1470	primary	public	preview_card_trends	8192	2025-10-04 06:30:00.134503
1471	primary	public	preview_card_trends_pkey	8192	2025-10-04 06:30:00.134503
1472	primary	public	preview_cards	8192	2025-10-04 06:30:00.134503
1473	primary	public	preview_cards_pkey	8192	2025-10-04 06:30:00.134503
1474	primary	public	preview_cards_statuses	8192	2025-10-04 06:30:00.134503
1475	primary	public	preview_cards_statuses_pkey	8192	2025-10-04 06:30:00.134503
1476	primary	public	relationship_severance_events	8192	2025-10-04 06:30:00.134503
1477	primary	public	relationship_severance_events_pkey	8192	2025-10-04 06:30:00.134503
1478	primary	public	relays	8192	2025-10-04 06:30:00.134503
1479	primary	public	relays_pkey	8192	2025-10-04 06:30:00.134503
1480	primary	public	report_notes	8192	2025-10-04 06:30:00.134503
1481	primary	public	report_notes_pkey	8192	2025-10-04 06:30:00.134503
1482	primary	public	rules	8192	2025-10-04 06:30:00.134503
1483	primary	public	rules_pkey	8192	2025-10-04 06:30:00.134503
1484	primary	public	scheduled_statuses	8192	2025-10-04 06:30:00.134503
1485	primary	public	scheduled_statuses_pkey	8192	2025-10-04 06:30:00.134503
1486	primary	public	settings	8192	2025-10-04 06:30:00.134503
1487	primary	public	settings_pkey	8192	2025-10-04 06:30:00.134503
1488	primary	public	severed_relationships	8192	2025-10-04 06:30:00.134503
1489	primary	public	severed_relationships_pkey	8192	2025-10-04 06:30:00.134503
1490	primary	public	site_uploads	8192	2025-10-04 06:30:00.134503
1491	primary	public	site_uploads_pkey	8192	2025-10-04 06:30:00.134503
1492	primary	public	status_pins_pkey	8192	2025-10-04 06:30:00.134503
1493	primary	public	status_stats	8192	2025-10-04 06:30:00.134503
1494	primary	public	status_trends	8192	2025-10-04 06:30:00.134503
1495	primary	public	status_trends_pkey	8192	2025-10-04 06:30:00.134503
1496	primary	public	statuses_tags	8192	2025-10-04 06:30:00.134503
1497	primary	public	tag_follows_pkey	8192	2025-10-04 06:30:00.134503
1498	primary	public	tombstones	8192	2025-10-04 06:30:00.134503
1499	primary	public	tombstones_pkey	8192	2025-10-04 06:30:00.134503
1500	primary	public	unavailable_domains	8192	2025-10-04 06:30:00.134503
1501	primary	public	unavailable_domains_pkey	8192	2025-10-04 06:30:00.134503
1502	primary	public	user_invite_requests	8192	2025-10-04 06:30:00.134503
1503	primary	public	user_invite_requests_pkey	8192	2025-10-04 06:30:00.134503
1504	primary	public	web_push_subscriptions	8192	2025-10-04 06:30:00.134503
1505	primary	public	web_push_subscriptions_pkey	8192	2025-10-04 06:30:00.134503
1506	primary	public	webauthn_credentials	8192	2025-10-04 06:30:00.134503
1507	primary	public	webauthn_credentials_pkey	8192	2025-10-04 06:30:00.134503
1508	primary	public	webhooks	8192	2025-10-04 06:30:00.134503
1509	primary	public	webhooks_pkey	8192	2025-10-04 06:30:00.134503
1510	primary	public	account_deletion_requests	0	2025-10-04 06:30:00.134503
1511	primary	public	account_pins	0	2025-10-04 06:30:00.134503
1512	primary	public	account_relationship_severance_events	0	2025-10-04 06:30:00.134503
1513	primary	public	account_statuses_cleanup_policies	0	2025-10-04 06:30:00.134503
1514	primary	public	accounts_tags	0	2025-10-04 06:30:00.134503
1515	primary	public	announcement_mutes	0	2025-10-04 06:30:00.134503
1516	primary	public	bookmarks	0	2025-10-04 06:30:00.134503
1517	primary	public	conversation_mutes	0	2025-10-04 06:30:00.134503
1518	primary	public	custom_filter_statuses	0	2025-10-04 06:30:00.134503
1519	primary	public	favourites	0	2025-10-04 06:30:00.134503
1520	primary	public	follow_recommendation_mutes	0	2025-10-04 06:30:00.134503
1521	primary	public	follow_recommendation_suppressions	0	2025-10-04 06:30:00.134503
1522	primary	public	list_accounts	0	2025-10-04 06:30:00.134503
1523	primary	public	mentions	0	2025-10-04 06:30:00.134503
1524	primary	public	mutes	0	2025-10-04 06:30:00.134503
1525	primary	public	notification_permissions	0	2025-10-04 06:30:00.134503
1526	primary	public	notification_requests	0	2025-10-04 06:30:00.134503
1527	primary	public	status_pins	0	2025-10-04 06:30:00.134503
1528	primary	public	tag_follows	0	2025-10-04 06:30:00.134503
1529	primary	public	pghero_space_stats	188416	2025-10-05 04:00:00.334012
1530	primary	public	accounts	114688	2025-10-05 04:00:00.334012
1531	primary	public	media_attachments	57344	2025-10-05 04:00:00.334012
1532	primary	public	pghero_space_stats_pkey	57344	2025-10-05 04:00:00.334012
1533	primary	public	schema_migrations	57344	2025-10-05 04:00:00.334012
1534	primary	public	statuses	49152	2025-10-05 04:00:00.334012
1535	primary	public	index_pghero_space_stats_on_database_and_captured_at	32768	2025-10-05 04:00:00.334012
1536	primary	public	schema_migrations_pkey	32768	2025-10-05 04:00:00.334012
1537	primary	public	account_summaries	24576	2025-10-05 04:00:00.334012
1538	primary	public	search_index	24576	2025-10-05 04:00:00.334012
1539	primary	public	account_stats_pkey	16384	2025-10-05 04:00:00.334012
1540	primary	public	accounts_pkey	16384	2025-10-05 04:00:00.334012
1541	primary	public	ar_internal_metadata	16384	2025-10-05 04:00:00.334012
1542	primary	public	ar_internal_metadata_pkey	16384	2025-10-05 04:00:00.334012
1543	primary	public	conversations	16384	2025-10-05 04:00:00.334012
1544	primary	public	conversations_pkey	16384	2025-10-05 04:00:00.334012
1545	primary	public	custom_filter_keywords	16384	2025-10-05 04:00:00.334012
1546	primary	public	custom_filter_keywords_pkey	16384	2025-10-05 04:00:00.334012
1547	primary	public	custom_filters	16384	2025-10-05 04:00:00.334012
1548	primary	public	custom_filters_pkey	16384	2025-10-05 04:00:00.334012
1549	primary	public	follows	16384	2025-10-05 04:00:00.334012
1550	primary	public	follows_pkey	16384	2025-10-05 04:00:00.334012
1551	primary	public	idx_on_account_id_language_sensitive_250461e1eb	16384	2025-10-05 04:00:00.334012
1552	primary	public	index_account_stats_on_account_id	16384	2025-10-05 04:00:00.334012
1553	primary	public	index_account_stats_on_last_status_at_and_account_id	16384	2025-10-05 04:00:00.334012
1554	primary	public	index_account_summaries_on_account_id	16384	2025-10-05 04:00:00.334012
1555	primary	public	index_accounts_on_domain_and_id	16384	2025-10-05 04:00:00.334012
1556	primary	public	index_accounts_on_uri	16384	2025-10-05 04:00:00.334012
1557	primary	public	index_accounts_on_username_and_domain_lower	16384	2025-10-05 04:00:00.334012
1558	primary	public	index_custom_filter_keywords_on_custom_filter_id	16384	2025-10-05 04:00:00.334012
1559	primary	public	index_custom_filters_on_account_id	16384	2025-10-05 04:00:00.334012
1560	primary	public	index_follows_on_account_id_and_target_account_id	16384	2025-10-05 04:00:00.334012
1561	primary	public	index_follows_on_target_account_id	16384	2025-10-05 04:00:00.334012
1562	primary	public	index_invites_on_code	16384	2025-10-05 04:00:00.334012
1563	primary	public	index_invites_on_user_id	16384	2025-10-05 04:00:00.334012
1564	primary	public	index_login_activities_on_user_id	16384	2025-10-05 04:00:00.334012
1565	primary	public	index_markers_on_user_id_and_timeline	16384	2025-10-05 04:00:00.334012
1566	primary	public	index_media_attachments_on_account_id_and_status_id	16384	2025-10-05 04:00:00.334012
1567	primary	public	index_media_attachments_on_status_id	16384	2025-10-05 04:00:00.334012
1568	primary	public	index_notification_policies_on_account_id	16384	2025-10-05 04:00:00.334012
1569	primary	public	index_notifications_on_account_id_and_group_key	16384	2025-10-05 04:00:00.334012
1570	primary	public	index_notifications_on_account_id_and_id_and_type	16384	2025-10-05 04:00:00.334012
1571	primary	public	index_notifications_on_activity_id_and_activity_type	16384	2025-10-05 04:00:00.334012
1572	primary	public	index_notifications_on_filtered	16384	2025-10-05 04:00:00.334012
1573	primary	public	index_notifications_on_from_account_id	16384	2025-10-05 04:00:00.334012
1574	primary	public	index_oauth_access_grants_on_resource_owner_id	16384	2025-10-05 04:00:00.334012
1575	primary	public	index_oauth_access_grants_on_token	16384	2025-10-05 04:00:00.334012
1576	primary	public	index_oauth_access_tokens_on_resource_owner_id	16384	2025-10-05 04:00:00.334012
1577	primary	public	index_oauth_access_tokens_on_token	16384	2025-10-05 04:00:00.334012
1578	primary	public	index_oauth_applications_on_owner_id_and_owner_type	16384	2025-10-05 04:00:00.334012
1579	primary	public	index_oauth_applications_on_superapp	16384	2025-10-05 04:00:00.334012
1580	primary	public	index_oauth_applications_on_uid	16384	2025-10-05 04:00:00.334012
1581	primary	public	index_poll_votes_on_account_id	16384	2025-10-05 04:00:00.334012
1582	primary	public	index_poll_votes_on_poll_id	16384	2025-10-05 04:00:00.334012
1583	primary	public	index_polls_on_account_id	16384	2025-10-05 04:00:00.334012
1584	primary	public	index_polls_on_status_id	16384	2025-10-05 04:00:00.334012
1585	primary	public	index_reports_on_account_id	16384	2025-10-05 04:00:00.334012
1586	primary	public	index_reports_on_target_account_id	16384	2025-10-05 04:00:00.334012
1587	primary	public	index_session_activations_on_access_token_id	16384	2025-10-05 04:00:00.334012
1588	primary	public	index_session_activations_on_session_id	16384	2025-10-05 04:00:00.334012
1589	primary	public	index_session_activations_on_user_id	16384	2025-10-05 04:00:00.334012
1590	primary	public	index_software_updates_on_version	16384	2025-10-05 04:00:00.334012
1591	primary	public	index_status_edits_on_account_id	16384	2025-10-05 04:00:00.334012
1592	primary	public	index_status_edits_on_status_id	16384	2025-10-05 04:00:00.334012
1593	primary	public	index_status_stats_on_status_id	16384	2025-10-05 04:00:00.334012
1594	primary	public	index_statuses_20190820	16384	2025-10-05 04:00:00.334012
1595	primary	public	index_statuses_local_20190824	16384	2025-10-05 04:00:00.334012
1596	primary	public	index_statuses_on_account_id	16384	2025-10-05 04:00:00.334012
1597	primary	public	index_statuses_on_deleted_at	16384	2025-10-05 04:00:00.334012
1598	primary	public	index_statuses_on_reblog_of_id_and_account_id	16384	2025-10-05 04:00:00.334012
1599	primary	public	index_statuses_on_uri	16384	2025-10-05 04:00:00.334012
1600	primary	public	index_statuses_public_20200119	16384	2025-10-05 04:00:00.334012
1601	primary	public	index_statuses_tags_on_status_id	16384	2025-10-05 04:00:00.334012
1602	primary	public	index_tags_on_name_lower_btree	16384	2025-10-05 04:00:00.334012
1603	primary	public	index_users_on_account_id	16384	2025-10-05 04:00:00.334012
1604	primary	public	index_users_on_confirmation_token	16384	2025-10-05 04:00:00.334012
1605	primary	public	index_users_on_created_by_application_id	16384	2025-10-05 04:00:00.334012
1606	primary	public	index_users_on_email	16384	2025-10-05 04:00:00.334012
1607	primary	public	index_users_on_role_id	16384	2025-10-05 04:00:00.334012
1608	primary	public	index_web_settings_on_user_id	16384	2025-10-05 04:00:00.334012
1609	primary	public	invites	16384	2025-10-05 04:00:00.334012
1610	primary	public	invites_pkey	16384	2025-10-05 04:00:00.334012
1611	primary	public	login_activities	16384	2025-10-05 04:00:00.334012
1612	primary	public	login_activities_pkey	16384	2025-10-05 04:00:00.334012
1613	primary	public	markers	16384	2025-10-05 04:00:00.334012
1614	primary	public	markers_pkey	16384	2025-10-05 04:00:00.334012
1615	primary	public	media_attachments_pkey	16384	2025-10-05 04:00:00.334012
1616	primary	public	notification_policies_pkey	16384	2025-10-05 04:00:00.334012
1617	primary	public	notifications	16384	2025-10-05 04:00:00.334012
1618	primary	public	notifications_pkey	16384	2025-10-05 04:00:00.334012
1619	primary	public	oauth_access_grants	16384	2025-10-05 04:00:00.334012
1620	primary	public	oauth_access_grants_pkey	16384	2025-10-05 04:00:00.334012
1621	primary	public	oauth_access_tokens	16384	2025-10-05 04:00:00.334012
1622	primary	public	oauth_access_tokens_pkey	16384	2025-10-05 04:00:00.334012
1623	primary	public	oauth_applications	16384	2025-10-05 04:00:00.334012
1624	primary	public	oauth_applications_pkey	16384	2025-10-05 04:00:00.334012
1625	primary	public	poll_votes	16384	2025-10-05 04:00:00.334012
1626	primary	public	poll_votes_pkey	16384	2025-10-05 04:00:00.334012
1627	primary	public	polls	16384	2025-10-05 04:00:00.334012
1628	primary	public	polls_pkey	16384	2025-10-05 04:00:00.334012
1629	primary	public	reports	16384	2025-10-05 04:00:00.334012
1630	primary	public	reports_pkey	16384	2025-10-05 04:00:00.334012
1631	primary	public	session_activations	16384	2025-10-05 04:00:00.334012
1632	primary	public	session_activations_pkey	16384	2025-10-05 04:00:00.334012
1633	primary	public	software_updates	16384	2025-10-05 04:00:00.334012
1634	primary	public	software_updates_pkey	16384	2025-10-05 04:00:00.334012
1635	primary	public	status_edits	16384	2025-10-05 04:00:00.334012
1636	primary	public	status_edits_pkey	16384	2025-10-05 04:00:00.334012
1637	primary	public	status_stats_pkey	16384	2025-10-05 04:00:00.334012
1638	primary	public	statuses_pkey	16384	2025-10-05 04:00:00.334012
1639	primary	public	statuses_tags_pkey	16384	2025-10-05 04:00:00.334012
1640	primary	public	tags	16384	2025-10-05 04:00:00.334012
1641	primary	public	tags_pkey	16384	2025-10-05 04:00:00.334012
1642	primary	public	user_roles	16384	2025-10-05 04:00:00.334012
1643	primary	public	user_roles_pkey	16384	2025-10-05 04:00:00.334012
1644	primary	public	users	16384	2025-10-05 04:00:00.334012
1645	primary	public	users_pkey	16384	2025-10-05 04:00:00.334012
1646	primary	public	web_settings	16384	2025-10-05 04:00:00.334012
1647	primary	public	web_settings_pkey	16384	2025-10-05 04:00:00.334012
1648	primary	public	account_aliases	8192	2025-10-05 04:00:00.334012
1649	primary	public	account_aliases_pkey	8192	2025-10-05 04:00:00.334012
1650	primary	public	account_conversations	8192	2025-10-05 04:00:00.334012
1651	primary	public	account_conversations_pkey	8192	2025-10-05 04:00:00.334012
1652	primary	public	account_deletion_requests_pkey	8192	2025-10-05 04:00:00.334012
1653	primary	public	account_domain_blocks	8192	2025-10-05 04:00:00.334012
1654	primary	public	account_domain_blocks_pkey	8192	2025-10-05 04:00:00.334012
1655	primary	public	account_migrations	8192	2025-10-05 04:00:00.334012
1656	primary	public	account_migrations_pkey	8192	2025-10-05 04:00:00.334012
1657	primary	public	account_moderation_notes	8192	2025-10-05 04:00:00.334012
1658	primary	public	account_moderation_notes_pkey	8192	2025-10-05 04:00:00.334012
1659	primary	public	account_notes	8192	2025-10-05 04:00:00.334012
1660	primary	public	account_notes_pkey	8192	2025-10-05 04:00:00.334012
1661	primary	public	account_pins_pkey	8192	2025-10-05 04:00:00.334012
1662	primary	public	account_relationship_severance_events_pkey	8192	2025-10-05 04:00:00.334012
1663	primary	public	account_stats	8192	2025-10-05 04:00:00.334012
1664	primary	public	account_statuses_cleanup_policies_pkey	8192	2025-10-05 04:00:00.334012
1665	primary	public	account_warning_presets	8192	2025-10-05 04:00:00.334012
1666	primary	public	account_warning_presets_pkey	8192	2025-10-05 04:00:00.334012
1667	primary	public	account_warnings	8192	2025-10-05 04:00:00.334012
1668	primary	public	account_warnings_pkey	8192	2025-10-05 04:00:00.334012
1669	primary	public	accounts_tags_pkey	8192	2025-10-05 04:00:00.334012
1670	primary	public	admin_action_logs	8192	2025-10-05 04:00:00.334012
1671	primary	public	admin_action_logs_pkey	8192	2025-10-05 04:00:00.334012
1672	primary	public	announcement_mutes_pkey	8192	2025-10-05 04:00:00.334012
1673	primary	public	announcement_reactions	8192	2025-10-05 04:00:00.334012
1674	primary	public	announcement_reactions_pkey	8192	2025-10-05 04:00:00.334012
1675	primary	public	announcements	8192	2025-10-05 04:00:00.334012
1676	primary	public	announcements_pkey	8192	2025-10-05 04:00:00.334012
1677	primary	public	appeals	8192	2025-10-05 04:00:00.334012
1678	primary	public	appeals_pkey	8192	2025-10-05 04:00:00.334012
1679	primary	public	backups	8192	2025-10-05 04:00:00.334012
1680	primary	public	backups_pkey	8192	2025-10-05 04:00:00.334012
1681	primary	public	blocks	8192	2025-10-05 04:00:00.334012
1682	primary	public	blocks_pkey	8192	2025-10-05 04:00:00.334012
1683	primary	public	bookmarks_pkey	8192	2025-10-05 04:00:00.334012
1684	primary	public	bulk_import_rows	8192	2025-10-05 04:00:00.334012
1685	primary	public	bulk_import_rows_pkey	8192	2025-10-05 04:00:00.334012
1686	primary	public	bulk_imports	8192	2025-10-05 04:00:00.334012
1687	primary	public	bulk_imports_pkey	8192	2025-10-05 04:00:00.334012
1688	primary	public	canonical_email_blocks	8192	2025-10-05 04:00:00.334012
1689	primary	public	canonical_email_blocks_pkey	8192	2025-10-05 04:00:00.334012
1690	primary	public	conversation_mutes_pkey	8192	2025-10-05 04:00:00.334012
1691	primary	public	custom_emoji_categories	8192	2025-10-05 04:00:00.334012
1692	primary	public	custom_emoji_categories_pkey	8192	2025-10-05 04:00:00.334012
1693	primary	public	custom_emojis	8192	2025-10-05 04:00:00.334012
1694	primary	public	custom_emojis_pkey	8192	2025-10-05 04:00:00.334012
1695	primary	public	custom_filter_statuses_pkey	8192	2025-10-05 04:00:00.334012
1696	primary	public	domain_allows	8192	2025-10-05 04:00:00.334012
1697	primary	public	domain_allows_pkey	8192	2025-10-05 04:00:00.334012
1698	primary	public	domain_blocks	8192	2025-10-05 04:00:00.334012
1699	primary	public	domain_blocks_pkey	8192	2025-10-05 04:00:00.334012
1700	primary	public	email_domain_blocks	8192	2025-10-05 04:00:00.334012
1701	primary	public	email_domain_blocks_pkey	8192	2025-10-05 04:00:00.334012
1702	primary	public	favourites_pkey	8192	2025-10-05 04:00:00.334012
1703	primary	public	featured_tags	8192	2025-10-05 04:00:00.334012
1704	primary	public	featured_tags_pkey	8192	2025-10-05 04:00:00.334012
1705	primary	public	follow_recommendation_mutes_pkey	8192	2025-10-05 04:00:00.334012
1706	primary	public	follow_recommendation_suppressions_pkey	8192	2025-10-05 04:00:00.334012
1707	primary	public	follow_requests	8192	2025-10-05 04:00:00.334012
1708	primary	public	follow_requests_pkey	8192	2025-10-05 04:00:00.334012
1709	primary	public	generated_annual_reports	8192	2025-10-05 04:00:00.334012
1710	primary	public	generated_annual_reports_pkey	8192	2025-10-05 04:00:00.334012
1711	primary	public	global_follow_recommendations	8192	2025-10-05 04:00:00.334012
1712	primary	public	identities	8192	2025-10-05 04:00:00.334012
1713	primary	public	identities_pkey	8192	2025-10-05 04:00:00.334012
1714	primary	public	idx_on_account_id_relationship_severance_event_id_7bd82bf20e	8192	2025-10-05 04:00:00.334012
1715	primary	public	idx_on_account_id_target_account_id_a8c8ddf44e	8192	2025-10-05 04:00:00.334012
1716	primary	public	idx_on_relationship_severance_event_id_403f53e707	8192	2025-10-05 04:00:00.334012
1717	primary	public	imports	8192	2025-10-05 04:00:00.334012
1718	primary	public	imports_pkey	8192	2025-10-05 04:00:00.334012
1719	primary	public	index_account_aliases_on_account_id	8192	2025-10-05 04:00:00.334012
1720	primary	public	index_account_aliases_on_account_id_and_uri	8192	2025-10-05 04:00:00.334012
1721	primary	public	index_account_conversations_on_conversation_id	8192	2025-10-05 04:00:00.334012
1722	primary	public	index_account_deletion_requests_on_account_id	8192	2025-10-05 04:00:00.334012
1723	primary	public	index_account_domain_blocks_on_account_id_and_domain	8192	2025-10-05 04:00:00.334012
1724	primary	public	index_account_migrations_on_account_id	8192	2025-10-05 04:00:00.334012
1725	primary	public	index_account_migrations_on_target_account_id	8192	2025-10-05 04:00:00.334012
1726	primary	public	index_account_moderation_notes_on_account_id	8192	2025-10-05 04:00:00.334012
1727	primary	public	index_account_moderation_notes_on_target_account_id	8192	2025-10-05 04:00:00.334012
1728	primary	public	index_account_notes_on_account_id_and_target_account_id	8192	2025-10-05 04:00:00.334012
1729	primary	public	index_account_notes_on_target_account_id	8192	2025-10-05 04:00:00.334012
1730	primary	public	index_account_pins_on_account_id_and_target_account_id	8192	2025-10-05 04:00:00.334012
1731	primary	public	index_account_pins_on_target_account_id	8192	2025-10-05 04:00:00.334012
1732	primary	public	index_account_relationship_severance_events_on_account_id	8192	2025-10-05 04:00:00.334012
1733	primary	public	index_account_statuses_cleanup_policies_on_account_id	8192	2025-10-05 04:00:00.334012
1734	primary	public	index_account_warnings_on_account_id	8192	2025-10-05 04:00:00.334012
1735	primary	public	index_account_warnings_on_target_account_id	8192	2025-10-05 04:00:00.334012
1736	primary	public	index_accounts_on_moved_to_account_id	8192	2025-10-05 04:00:00.334012
1737	primary	public	index_accounts_on_url	8192	2025-10-05 04:00:00.334012
1738	primary	public	index_accounts_tags_on_account_id_and_tag_id	8192	2025-10-05 04:00:00.334012
1739	primary	public	index_admin_action_logs_on_account_id	8192	2025-10-05 04:00:00.334012
1740	primary	public	index_admin_action_logs_on_target_type_and_target_id	8192	2025-10-05 04:00:00.334012
1741	primary	public	index_announcement_mutes_on_account_id_and_announcement_id	8192	2025-10-05 04:00:00.334012
1742	primary	public	index_announcement_mutes_on_announcement_id	8192	2025-10-05 04:00:00.334012
1743	primary	public	index_announcement_reactions_on_account_id_and_announcement_id	8192	2025-10-05 04:00:00.334012
1744	primary	public	index_announcement_reactions_on_announcement_id	8192	2025-10-05 04:00:00.334012
1745	primary	public	index_announcement_reactions_on_custom_emoji_id	8192	2025-10-05 04:00:00.334012
1746	primary	public	index_appeals_on_account_id	8192	2025-10-05 04:00:00.334012
1747	primary	public	index_appeals_on_account_warning_id	8192	2025-10-05 04:00:00.334012
1748	primary	public	index_appeals_on_approved_by_account_id	8192	2025-10-05 04:00:00.334012
1749	primary	public	index_appeals_on_rejected_by_account_id	8192	2025-10-05 04:00:00.334012
1750	primary	public	index_backups_on_user_id	8192	2025-10-05 04:00:00.334012
1751	primary	public	index_blocks_on_account_id_and_target_account_id	8192	2025-10-05 04:00:00.334012
1752	primary	public	index_blocks_on_target_account_id	8192	2025-10-05 04:00:00.334012
1753	primary	public	index_bookmarks_on_account_id_and_status_id	8192	2025-10-05 04:00:00.334012
1754	primary	public	index_bookmarks_on_status_id	8192	2025-10-05 04:00:00.334012
1755	primary	public	index_bulk_import_rows_on_bulk_import_id	8192	2025-10-05 04:00:00.334012
1756	primary	public	index_bulk_imports_on_account_id	8192	2025-10-05 04:00:00.334012
1757	primary	public	index_bulk_imports_unconfirmed	8192	2025-10-05 04:00:00.334012
1758	primary	public	index_canonical_email_blocks_on_canonical_email_hash	8192	2025-10-05 04:00:00.334012
1759	primary	public	index_canonical_email_blocks_on_reference_account_id	8192	2025-10-05 04:00:00.334012
1760	primary	public	index_conversation_mutes_on_account_id_and_conversation_id	8192	2025-10-05 04:00:00.334012
1761	primary	public	index_conversations_on_uri	8192	2025-10-05 04:00:00.334012
1762	primary	public	index_custom_emoji_categories_on_name	8192	2025-10-05 04:00:00.334012
1763	primary	public	index_custom_emojis_on_shortcode_and_domain	8192	2025-10-05 04:00:00.334012
1764	primary	public	index_custom_filter_statuses_on_custom_filter_id	8192	2025-10-05 04:00:00.334012
1765	primary	public	index_custom_filter_statuses_on_status_id	8192	2025-10-05 04:00:00.334012
1766	primary	public	index_custom_filter_statuses_on_status_id_and_custom_filter_id	8192	2025-10-05 04:00:00.334012
1767	primary	public	index_domain_allows_on_domain	8192	2025-10-05 04:00:00.334012
1768	primary	public	index_domain_blocks_on_domain	8192	2025-10-05 04:00:00.334012
1769	primary	public	index_email_domain_blocks_on_domain	8192	2025-10-05 04:00:00.334012
1770	primary	public	index_favourites_on_account_id_and_id	8192	2025-10-05 04:00:00.334012
1771	primary	public	index_favourites_on_account_id_and_status_id	8192	2025-10-05 04:00:00.334012
1772	primary	public	index_favourites_on_status_id	8192	2025-10-05 04:00:00.334012
1773	primary	public	index_featured_tags_on_account_id_and_tag_id	8192	2025-10-05 04:00:00.334012
1774	primary	public	index_featured_tags_on_tag_id	8192	2025-10-05 04:00:00.334012
1775	primary	public	index_follow_recommendation_mutes_on_target_account_id	8192	2025-10-05 04:00:00.334012
1776	primary	public	index_follow_recommendation_suppressions_on_account_id	8192	2025-10-05 04:00:00.334012
1777	primary	public	index_follow_requests_on_account_id_and_target_account_id	8192	2025-10-05 04:00:00.334012
1778	primary	public	index_generated_annual_reports_on_account_id_and_year	8192	2025-10-05 04:00:00.334012
1779	primary	public	index_global_follow_recommendations_on_account_id	8192	2025-10-05 04:00:00.334012
1780	primary	public	index_identities_on_uid_and_provider	8192	2025-10-05 04:00:00.334012
1781	primary	public	index_identities_on_user_id	8192	2025-10-05 04:00:00.334012
1782	primary	public	index_instances_on_domain	8192	2025-10-05 04:00:00.334012
1783	primary	public	index_instances_on_reverse_domain	8192	2025-10-05 04:00:00.334012
1784	primary	public	index_ip_blocks_on_ip	8192	2025-10-05 04:00:00.334012
1785	primary	public	index_list_accounts_on_account_id_and_list_id	8192	2025-10-05 04:00:00.334012
1786	primary	public	index_list_accounts_on_follow_id	8192	2025-10-05 04:00:00.334012
1787	primary	public	index_list_accounts_on_follow_request_id	8192	2025-10-05 04:00:00.334012
1788	primary	public	index_list_accounts_on_list_id_and_account_id	8192	2025-10-05 04:00:00.334012
1789	primary	public	index_lists_on_account_id	8192	2025-10-05 04:00:00.334012
1790	primary	public	index_media_attachments_on_scheduled_status_id	8192	2025-10-05 04:00:00.334012
1791	primary	public	index_media_attachments_on_shortcode	8192	2025-10-05 04:00:00.334012
1792	primary	public	index_mentions_on_account_id_and_status_id	8192	2025-10-05 04:00:00.334012
1793	primary	public	index_mentions_on_status_id	8192	2025-10-05 04:00:00.334012
1794	primary	public	index_mutes_on_account_id_and_target_account_id	8192	2025-10-05 04:00:00.334012
1795	primary	public	index_mutes_on_target_account_id	8192	2025-10-05 04:00:00.334012
1796	primary	public	index_notification_permissions_on_account_id	8192	2025-10-05 04:00:00.334012
1797	primary	public	index_notification_permissions_on_from_account_id	8192	2025-10-05 04:00:00.334012
1798	primary	public	index_notification_requests_on_account_id_and_from_account_id	8192	2025-10-05 04:00:00.334012
1799	primary	public	index_notification_requests_on_from_account_id	8192	2025-10-05 04:00:00.334012
1800	primary	public	index_notification_requests_on_last_status_id	8192	2025-10-05 04:00:00.334012
1801	primary	public	index_oauth_access_tokens_on_refresh_token	8192	2025-10-05 04:00:00.334012
1802	primary	public	index_preview_card_providers_on_domain	8192	2025-10-05 04:00:00.334012
1803	primary	public	index_preview_card_trends_on_preview_card_id	8192	2025-10-05 04:00:00.334012
1804	primary	public	index_preview_cards_on_author_account_id	8192	2025-10-05 04:00:00.334012
1805	primary	public	index_preview_cards_on_url	8192	2025-10-05 04:00:00.334012
1806	primary	public	index_relationship_severance_events_on_type_and_target_name	8192	2025-10-05 04:00:00.334012
1807	primary	public	index_report_notes_on_account_id	8192	2025-10-05 04:00:00.334012
1808	primary	public	index_report_notes_on_report_id	8192	2025-10-05 04:00:00.334012
1809	primary	public	index_reports_on_action_taken_by_account_id	8192	2025-10-05 04:00:00.334012
1810	primary	public	index_reports_on_assigned_account_id	8192	2025-10-05 04:00:00.334012
1811	primary	public	index_scheduled_statuses_on_account_id	8192	2025-10-05 04:00:00.334012
1812	primary	public	index_scheduled_statuses_on_scheduled_at	8192	2025-10-05 04:00:00.334012
1813	primary	public	index_settings_on_thing_type_and_thing_id_and_var	8192	2025-10-05 04:00:00.334012
1814	primary	public	index_severed_relationships_on_local_account_and_event	8192	2025-10-05 04:00:00.334012
1815	primary	public	index_severed_relationships_on_remote_account_id	8192	2025-10-05 04:00:00.334012
1816	primary	public	index_severed_relationships_on_unique_tuples	8192	2025-10-05 04:00:00.334012
1817	primary	public	index_site_uploads_on_var	8192	2025-10-05 04:00:00.334012
1818	primary	public	index_status_pins_on_account_id_and_status_id	8192	2025-10-05 04:00:00.334012
1819	primary	public	index_status_pins_on_status_id	8192	2025-10-05 04:00:00.334012
1820	primary	public	index_status_trends_on_account_id	8192	2025-10-05 04:00:00.334012
1821	primary	public	index_status_trends_on_status_id	8192	2025-10-05 04:00:00.334012
1822	primary	public	index_statuses_on_in_reply_to_account_id	8192	2025-10-05 04:00:00.334012
1823	primary	public	index_statuses_on_in_reply_to_id	8192	2025-10-05 04:00:00.334012
1824	primary	public	index_tag_follows_on_account_id_and_tag_id	8192	2025-10-05 04:00:00.334012
1825	primary	public	index_tag_follows_on_tag_id	8192	2025-10-05 04:00:00.334012
1826	primary	public	index_tombstones_on_account_id	8192	2025-10-05 04:00:00.334012
1827	primary	public	index_tombstones_on_uri	8192	2025-10-05 04:00:00.334012
1828	primary	public	index_unavailable_domains_on_domain	8192	2025-10-05 04:00:00.334012
1829	primary	public	index_unique_conversations	8192	2025-10-05 04:00:00.334012
1830	primary	public	index_user_invite_requests_on_user_id	8192	2025-10-05 04:00:00.334012
1831	primary	public	index_users_on_reset_password_token	8192	2025-10-05 04:00:00.334012
1832	primary	public	index_users_on_unconfirmed_email	8192	2025-10-05 04:00:00.334012
1833	primary	public	index_web_push_subscriptions_on_access_token_id	8192	2025-10-05 04:00:00.334012
1834	primary	public	index_web_push_subscriptions_on_user_id	8192	2025-10-05 04:00:00.334012
1835	primary	public	index_webauthn_credentials_on_external_id	8192	2025-10-05 04:00:00.334012
1836	primary	public	index_webauthn_credentials_on_user_id	8192	2025-10-05 04:00:00.334012
1837	primary	public	index_webauthn_credentials_on_user_id_and_nickname	8192	2025-10-05 04:00:00.334012
1838	primary	public	index_webhooks_on_url	8192	2025-10-05 04:00:00.334012
1839	primary	public	instances	8192	2025-10-05 04:00:00.334012
1840	primary	public	ip_blocks	8192	2025-10-05 04:00:00.334012
1841	primary	public	ip_blocks_pkey	8192	2025-10-05 04:00:00.334012
1842	primary	public	list_accounts_pkey	8192	2025-10-05 04:00:00.334012
1843	primary	public	lists	8192	2025-10-05 04:00:00.334012
1844	primary	public	lists_pkey	8192	2025-10-05 04:00:00.334012
1845	primary	public	mentions_pkey	8192	2025-10-05 04:00:00.334012
1846	primary	public	mutes_pkey	8192	2025-10-05 04:00:00.334012
1847	primary	public	notification_permissions_pkey	8192	2025-10-05 04:00:00.334012
1848	primary	public	notification_policies	8192	2025-10-05 04:00:00.334012
1849	primary	public	notification_requests_pkey	8192	2025-10-05 04:00:00.334012
1850	primary	public	preview_card_providers	8192	2025-10-05 04:00:00.334012
1851	primary	public	preview_card_providers_pkey	8192	2025-10-05 04:00:00.334012
1852	primary	public	preview_card_trends	8192	2025-10-05 04:00:00.334012
1853	primary	public	preview_card_trends_pkey	8192	2025-10-05 04:00:00.334012
1854	primary	public	preview_cards	8192	2025-10-05 04:00:00.334012
1855	primary	public	preview_cards_pkey	8192	2025-10-05 04:00:00.334012
1856	primary	public	preview_cards_statuses	8192	2025-10-05 04:00:00.334012
1857	primary	public	preview_cards_statuses_pkey	8192	2025-10-05 04:00:00.334012
1858	primary	public	relationship_severance_events	8192	2025-10-05 04:00:00.334012
1859	primary	public	relationship_severance_events_pkey	8192	2025-10-05 04:00:00.334012
1860	primary	public	relays	8192	2025-10-05 04:00:00.334012
1861	primary	public	relays_pkey	8192	2025-10-05 04:00:00.334012
1862	primary	public	report_notes	8192	2025-10-05 04:00:00.334012
1863	primary	public	report_notes_pkey	8192	2025-10-05 04:00:00.334012
1864	primary	public	rules	8192	2025-10-05 04:00:00.334012
1865	primary	public	rules_pkey	8192	2025-10-05 04:00:00.334012
1866	primary	public	scheduled_statuses	8192	2025-10-05 04:00:00.334012
1867	primary	public	scheduled_statuses_pkey	8192	2025-10-05 04:00:00.334012
1868	primary	public	settings	8192	2025-10-05 04:00:00.334012
1869	primary	public	settings_pkey	8192	2025-10-05 04:00:00.334012
1870	primary	public	severed_relationships	8192	2025-10-05 04:00:00.334012
1871	primary	public	severed_relationships_pkey	8192	2025-10-05 04:00:00.334012
1872	primary	public	site_uploads	8192	2025-10-05 04:00:00.334012
1873	primary	public	site_uploads_pkey	8192	2025-10-05 04:00:00.334012
1874	primary	public	status_pins_pkey	8192	2025-10-05 04:00:00.334012
1875	primary	public	status_stats	8192	2025-10-05 04:00:00.334012
1876	primary	public	status_trends	8192	2025-10-05 04:00:00.334012
1877	primary	public	status_trends_pkey	8192	2025-10-05 04:00:00.334012
1878	primary	public	statuses_tags	8192	2025-10-05 04:00:00.334012
1879	primary	public	tag_follows_pkey	8192	2025-10-05 04:00:00.334012
1880	primary	public	tombstones	8192	2025-10-05 04:00:00.334012
1881	primary	public	tombstones_pkey	8192	2025-10-05 04:00:00.334012
1882	primary	public	unavailable_domains	8192	2025-10-05 04:00:00.334012
1883	primary	public	unavailable_domains_pkey	8192	2025-10-05 04:00:00.334012
1884	primary	public	user_invite_requests	8192	2025-10-05 04:00:00.334012
1885	primary	public	user_invite_requests_pkey	8192	2025-10-05 04:00:00.334012
1886	primary	public	web_push_subscriptions	8192	2025-10-05 04:00:00.334012
1887	primary	public	web_push_subscriptions_pkey	8192	2025-10-05 04:00:00.334012
1888	primary	public	webauthn_credentials	8192	2025-10-05 04:00:00.334012
1889	primary	public	webauthn_credentials_pkey	8192	2025-10-05 04:00:00.334012
1890	primary	public	webhooks	8192	2025-10-05 04:00:00.334012
1891	primary	public	webhooks_pkey	8192	2025-10-05 04:00:00.334012
1892	primary	public	account_deletion_requests	0	2025-10-05 04:00:00.334012
1893	primary	public	account_pins	0	2025-10-05 04:00:00.334012
1894	primary	public	account_relationship_severance_events	0	2025-10-05 04:00:00.334012
1895	primary	public	account_statuses_cleanup_policies	0	2025-10-05 04:00:00.334012
1896	primary	public	accounts_tags	0	2025-10-05 04:00:00.334012
1897	primary	public	announcement_mutes	0	2025-10-05 04:00:00.334012
1898	primary	public	bookmarks	0	2025-10-05 04:00:00.334012
1899	primary	public	conversation_mutes	0	2025-10-05 04:00:00.334012
1900	primary	public	custom_filter_statuses	0	2025-10-05 04:00:00.334012
1901	primary	public	favourites	0	2025-10-05 04:00:00.334012
1902	primary	public	follow_recommendation_mutes	0	2025-10-05 04:00:00.334012
1903	primary	public	follow_recommendation_suppressions	0	2025-10-05 04:00:00.334012
1904	primary	public	list_accounts	0	2025-10-05 04:00:00.334012
1905	primary	public	mentions	0	2025-10-05 04:00:00.334012
1906	primary	public	mutes	0	2025-10-05 04:00:00.334012
1907	primary	public	notification_permissions	0	2025-10-05 04:00:00.334012
1908	primary	public	notification_requests	0	2025-10-05 04:00:00.334012
1909	primary	public	status_pins	0	2025-10-05 04:00:00.334012
1910	primary	public	tag_follows	0	2025-10-05 04:00:00.334012
1911	primary	public	pghero_space_stats	237568	2025-10-27 11:29:08.944793
1912	primary	public	accounts	114688	2025-10-27 11:29:08.944793
1913	primary	public	pghero_space_stats_pkey	65536	2025-10-27 11:29:08.944793
1914	primary	public	media_attachments	57344	2025-10-27 11:29:08.944793
1915	primary	public	schema_migrations	57344	2025-10-27 11:29:08.944793
1916	primary	public	statuses	49152	2025-10-27 11:29:08.944793
1917	primary	public	index_pghero_space_stats_on_database_and_captured_at	40960	2025-10-27 11:29:08.944793
1918	primary	public	schema_migrations_pkey	32768	2025-10-27 11:29:08.944793
1919	primary	public	account_summaries	24576	2025-10-27 11:29:08.944793
1920	primary	public	search_index	24576	2025-10-27 11:29:08.944793
1921	primary	public	account_stats_pkey	16384	2025-10-27 11:29:08.944793
1922	primary	public	accounts_pkey	16384	2025-10-27 11:29:08.944793
1923	primary	public	ar_internal_metadata	16384	2025-10-27 11:29:08.944793
1924	primary	public	ar_internal_metadata_pkey	16384	2025-10-27 11:29:08.944793
1925	primary	public	conversations	16384	2025-10-27 11:29:08.944793
1926	primary	public	conversations_pkey	16384	2025-10-27 11:29:08.944793
1927	primary	public	custom_filter_keywords	16384	2025-10-27 11:29:08.944793
1928	primary	public	custom_filter_keywords_pkey	16384	2025-10-27 11:29:08.944793
1929	primary	public	custom_filters	16384	2025-10-27 11:29:08.944793
1930	primary	public	custom_filters_pkey	16384	2025-10-27 11:29:08.944793
1931	primary	public	follows	16384	2025-10-27 11:29:08.944793
1932	primary	public	follows_pkey	16384	2025-10-27 11:29:08.944793
1933	primary	public	idx_on_account_id_language_sensitive_250461e1eb	16384	2025-10-27 11:29:08.944793
1934	primary	public	index_account_stats_on_account_id	16384	2025-10-27 11:29:08.944793
1935	primary	public	index_account_stats_on_last_status_at_and_account_id	16384	2025-10-27 11:29:08.944793
1936	primary	public	index_account_summaries_on_account_id	16384	2025-10-27 11:29:08.944793
1937	primary	public	index_accounts_on_domain_and_id	16384	2025-10-27 11:29:08.944793
1938	primary	public	index_accounts_on_uri	16384	2025-10-27 11:29:08.944793
1939	primary	public	index_accounts_on_username_and_domain_lower	16384	2025-10-27 11:29:08.944793
1940	primary	public	index_custom_filter_keywords_on_custom_filter_id	16384	2025-10-27 11:29:08.944793
1941	primary	public	index_custom_filters_on_account_id	16384	2025-10-27 11:29:08.944793
1942	primary	public	index_follows_on_account_id_and_target_account_id	16384	2025-10-27 11:29:08.944793
1943	primary	public	index_follows_on_target_account_id	16384	2025-10-27 11:29:08.944793
1944	primary	public	index_invites_on_code	16384	2025-10-27 11:29:08.944793
1945	primary	public	index_invites_on_user_id	16384	2025-10-27 11:29:08.944793
1946	primary	public	index_login_activities_on_user_id	16384	2025-10-27 11:29:08.944793
1947	primary	public	index_markers_on_user_id_and_timeline	16384	2025-10-27 11:29:08.944793
1948	primary	public	index_media_attachments_on_account_id_and_status_id	16384	2025-10-27 11:29:08.944793
1949	primary	public	index_media_attachments_on_status_id	16384	2025-10-27 11:29:08.944793
1950	primary	public	index_notification_policies_on_account_id	16384	2025-10-27 11:29:08.944793
1951	primary	public	index_notifications_on_account_id_and_group_key	16384	2025-10-27 11:29:08.944793
1952	primary	public	index_notifications_on_account_id_and_id_and_type	16384	2025-10-27 11:29:08.944793
1953	primary	public	index_notifications_on_activity_id_and_activity_type	16384	2025-10-27 11:29:08.944793
1954	primary	public	index_notifications_on_filtered	16384	2025-10-27 11:29:08.944793
1955	primary	public	index_notifications_on_from_account_id	16384	2025-10-27 11:29:08.944793
1956	primary	public	index_oauth_access_grants_on_resource_owner_id	16384	2025-10-27 11:29:08.944793
1957	primary	public	index_oauth_access_grants_on_token	16384	2025-10-27 11:29:08.944793
1958	primary	public	index_oauth_access_tokens_on_resource_owner_id	16384	2025-10-27 11:29:08.944793
1959	primary	public	index_oauth_access_tokens_on_token	16384	2025-10-27 11:29:08.944793
1960	primary	public	index_oauth_applications_on_owner_id_and_owner_type	16384	2025-10-27 11:29:08.944793
1961	primary	public	index_oauth_applications_on_superapp	16384	2025-10-27 11:29:08.944793
1962	primary	public	index_oauth_applications_on_uid	16384	2025-10-27 11:29:08.944793
1963	primary	public	index_poll_votes_on_account_id	16384	2025-10-27 11:29:08.944793
1964	primary	public	index_poll_votes_on_poll_id	16384	2025-10-27 11:29:08.944793
1965	primary	public	index_polls_on_account_id	16384	2025-10-27 11:29:08.944793
1966	primary	public	index_polls_on_status_id	16384	2025-10-27 11:29:08.944793
1967	primary	public	index_reports_on_account_id	16384	2025-10-27 11:29:08.944793
1968	primary	public	index_reports_on_target_account_id	16384	2025-10-27 11:29:08.944793
1969	primary	public	index_session_activations_on_access_token_id	16384	2025-10-27 11:29:08.944793
1970	primary	public	index_session_activations_on_session_id	16384	2025-10-27 11:29:08.944793
1971	primary	public	index_session_activations_on_user_id	16384	2025-10-27 11:29:08.944793
1972	primary	public	index_software_updates_on_version	16384	2025-10-27 11:29:08.944793
1973	primary	public	index_status_edits_on_account_id	16384	2025-10-27 11:29:08.944793
1974	primary	public	index_status_edits_on_status_id	16384	2025-10-27 11:29:08.944793
1975	primary	public	index_status_stats_on_status_id	16384	2025-10-27 11:29:08.944793
1976	primary	public	index_statuses_20190820	16384	2025-10-27 11:29:08.944793
1977	primary	public	index_statuses_local_20190824	16384	2025-10-27 11:29:08.944793
1978	primary	public	index_statuses_on_account_id	16384	2025-10-27 11:29:08.944793
1979	primary	public	index_statuses_on_deleted_at	16384	2025-10-27 11:29:08.944793
1980	primary	public	index_statuses_on_reblog_of_id_and_account_id	16384	2025-10-27 11:29:08.944793
1981	primary	public	index_statuses_on_uri	16384	2025-10-27 11:29:08.944793
1982	primary	public	index_statuses_public_20200119	16384	2025-10-27 11:29:08.944793
1983	primary	public	index_statuses_tags_on_status_id	16384	2025-10-27 11:29:08.944793
1984	primary	public	index_tags_on_name_lower_btree	16384	2025-10-27 11:29:08.944793
1985	primary	public	index_users_on_account_id	16384	2025-10-27 11:29:08.944793
1986	primary	public	index_users_on_confirmation_token	16384	2025-10-27 11:29:08.944793
1987	primary	public	index_users_on_created_by_application_id	16384	2025-10-27 11:29:08.944793
1988	primary	public	index_users_on_email	16384	2025-10-27 11:29:08.944793
1989	primary	public	index_users_on_role_id	16384	2025-10-27 11:29:08.944793
1990	primary	public	index_web_settings_on_user_id	16384	2025-10-27 11:29:08.944793
1991	primary	public	invites	16384	2025-10-27 11:29:08.944793
1992	primary	public	invites_pkey	16384	2025-10-27 11:29:08.944793
1993	primary	public	login_activities	16384	2025-10-27 11:29:08.944793
1994	primary	public	login_activities_pkey	16384	2025-10-27 11:29:08.944793
1995	primary	public	markers	16384	2025-10-27 11:29:08.944793
1996	primary	public	markers_pkey	16384	2025-10-27 11:29:08.944793
1997	primary	public	media_attachments_pkey	16384	2025-10-27 11:29:08.944793
1998	primary	public	notification_policies_pkey	16384	2025-10-27 11:29:08.944793
1999	primary	public	notifications	16384	2025-10-27 11:29:08.944793
2000	primary	public	notifications_pkey	16384	2025-10-27 11:29:08.944793
2001	primary	public	oauth_access_grants	16384	2025-10-27 11:29:08.944793
2002	primary	public	oauth_access_grants_pkey	16384	2025-10-27 11:29:08.944793
2003	primary	public	oauth_access_tokens	16384	2025-10-27 11:29:08.944793
2004	primary	public	oauth_access_tokens_pkey	16384	2025-10-27 11:29:08.944793
2005	primary	public	oauth_applications	16384	2025-10-27 11:29:08.944793
2006	primary	public	oauth_applications_pkey	16384	2025-10-27 11:29:08.944793
2007	primary	public	poll_votes	16384	2025-10-27 11:29:08.944793
2008	primary	public	poll_votes_pkey	16384	2025-10-27 11:29:08.944793
2009	primary	public	polls	16384	2025-10-27 11:29:08.944793
2010	primary	public	polls_pkey	16384	2025-10-27 11:29:08.944793
2011	primary	public	reports	16384	2025-10-27 11:29:08.944793
2012	primary	public	reports_pkey	16384	2025-10-27 11:29:08.944793
2013	primary	public	session_activations	16384	2025-10-27 11:29:08.944793
2014	primary	public	session_activations_pkey	16384	2025-10-27 11:29:08.944793
2015	primary	public	software_updates	16384	2025-10-27 11:29:08.944793
2016	primary	public	software_updates_pkey	16384	2025-10-27 11:29:08.944793
2017	primary	public	status_edits	16384	2025-10-27 11:29:08.944793
2018	primary	public	status_edits_pkey	16384	2025-10-27 11:29:08.944793
2019	primary	public	status_stats_pkey	16384	2025-10-27 11:29:08.944793
2020	primary	public	statuses_pkey	16384	2025-10-27 11:29:08.944793
2021	primary	public	statuses_tags_pkey	16384	2025-10-27 11:29:08.944793
2022	primary	public	tags	16384	2025-10-27 11:29:08.944793
2023	primary	public	tags_pkey	16384	2025-10-27 11:29:08.944793
2024	primary	public	user_roles	16384	2025-10-27 11:29:08.944793
2025	primary	public	user_roles_pkey	16384	2025-10-27 11:29:08.944793
2026	primary	public	users	16384	2025-10-27 11:29:08.944793
2027	primary	public	users_pkey	16384	2025-10-27 11:29:08.944793
2028	primary	public	web_settings	16384	2025-10-27 11:29:08.944793
2029	primary	public	web_settings_pkey	16384	2025-10-27 11:29:08.944793
2030	primary	public	account_aliases	8192	2025-10-27 11:29:08.944793
2031	primary	public	account_aliases_pkey	8192	2025-10-27 11:29:08.944793
2032	primary	public	account_conversations	8192	2025-10-27 11:29:08.944793
2033	primary	public	account_conversations_pkey	8192	2025-10-27 11:29:08.944793
2034	primary	public	account_deletion_requests_pkey	8192	2025-10-27 11:29:08.944793
2035	primary	public	account_domain_blocks	8192	2025-10-27 11:29:08.944793
2036	primary	public	account_domain_blocks_pkey	8192	2025-10-27 11:29:08.944793
2037	primary	public	account_migrations	8192	2025-10-27 11:29:08.944793
2038	primary	public	account_migrations_pkey	8192	2025-10-27 11:29:08.944793
2039	primary	public	account_moderation_notes	8192	2025-10-27 11:29:08.944793
2040	primary	public	account_moderation_notes_pkey	8192	2025-10-27 11:29:08.944793
2041	primary	public	account_notes	8192	2025-10-27 11:29:08.944793
2042	primary	public	account_notes_pkey	8192	2025-10-27 11:29:08.944793
2043	primary	public	account_pins_pkey	8192	2025-10-27 11:29:08.944793
2044	primary	public	account_relationship_severance_events_pkey	8192	2025-10-27 11:29:08.944793
2045	primary	public	account_stats	8192	2025-10-27 11:29:08.944793
2046	primary	public	account_statuses_cleanup_policies_pkey	8192	2025-10-27 11:29:08.944793
2047	primary	public	account_warning_presets	8192	2025-10-27 11:29:08.944793
2048	primary	public	account_warning_presets_pkey	8192	2025-10-27 11:29:08.944793
2049	primary	public	account_warnings	8192	2025-10-27 11:29:08.944793
2050	primary	public	account_warnings_pkey	8192	2025-10-27 11:29:08.944793
2051	primary	public	accounts_tags_pkey	8192	2025-10-27 11:29:08.944793
2052	primary	public	admin_action_logs	8192	2025-10-27 11:29:08.944793
2053	primary	public	admin_action_logs_pkey	8192	2025-10-27 11:29:08.944793
2054	primary	public	announcement_mutes_pkey	8192	2025-10-27 11:29:08.944793
2055	primary	public	announcement_reactions	8192	2025-10-27 11:29:08.944793
2056	primary	public	announcement_reactions_pkey	8192	2025-10-27 11:29:08.944793
2057	primary	public	announcements	8192	2025-10-27 11:29:08.944793
2058	primary	public	announcements_pkey	8192	2025-10-27 11:29:08.944793
2059	primary	public	appeals	8192	2025-10-27 11:29:08.944793
2060	primary	public	appeals_pkey	8192	2025-10-27 11:29:08.944793
2061	primary	public	backups	8192	2025-10-27 11:29:08.944793
2062	primary	public	backups_pkey	8192	2025-10-27 11:29:08.944793
2063	primary	public	blocks	8192	2025-10-27 11:29:08.944793
2064	primary	public	blocks_pkey	8192	2025-10-27 11:29:08.944793
2065	primary	public	bookmarks_pkey	8192	2025-10-27 11:29:08.944793
2066	primary	public	bulk_import_rows	8192	2025-10-27 11:29:08.944793
2067	primary	public	bulk_import_rows_pkey	8192	2025-10-27 11:29:08.944793
2068	primary	public	bulk_imports	8192	2025-10-27 11:29:08.944793
2069	primary	public	bulk_imports_pkey	8192	2025-10-27 11:29:08.944793
2070	primary	public	canonical_email_blocks	8192	2025-10-27 11:29:08.944793
2071	primary	public	canonical_email_blocks_pkey	8192	2025-10-27 11:29:08.944793
2072	primary	public	conversation_mutes_pkey	8192	2025-10-27 11:29:08.944793
2073	primary	public	custom_emoji_categories	8192	2025-10-27 11:29:08.944793
2074	primary	public	custom_emoji_categories_pkey	8192	2025-10-27 11:29:08.944793
2075	primary	public	custom_emojis	8192	2025-10-27 11:29:08.944793
2076	primary	public	custom_emojis_pkey	8192	2025-10-27 11:29:08.944793
2077	primary	public	custom_filter_statuses_pkey	8192	2025-10-27 11:29:08.944793
2078	primary	public	domain_allows	8192	2025-10-27 11:29:08.944793
2079	primary	public	domain_allows_pkey	8192	2025-10-27 11:29:08.944793
2080	primary	public	domain_blocks	8192	2025-10-27 11:29:08.944793
2081	primary	public	domain_blocks_pkey	8192	2025-10-27 11:29:08.944793
2082	primary	public	email_domain_blocks	8192	2025-10-27 11:29:08.944793
2083	primary	public	email_domain_blocks_pkey	8192	2025-10-27 11:29:08.944793
2084	primary	public	favourites_pkey	8192	2025-10-27 11:29:08.944793
2085	primary	public	featured_tags	8192	2025-10-27 11:29:08.944793
2086	primary	public	featured_tags_pkey	8192	2025-10-27 11:29:08.944793
2087	primary	public	follow_recommendation_mutes_pkey	8192	2025-10-27 11:29:08.944793
2088	primary	public	follow_recommendation_suppressions_pkey	8192	2025-10-27 11:29:08.944793
2089	primary	public	follow_requests	8192	2025-10-27 11:29:08.944793
2090	primary	public	follow_requests_pkey	8192	2025-10-27 11:29:08.944793
2091	primary	public	generated_annual_reports	8192	2025-10-27 11:29:08.944793
2092	primary	public	generated_annual_reports_pkey	8192	2025-10-27 11:29:08.944793
2093	primary	public	global_follow_recommendations	8192	2025-10-27 11:29:08.944793
2094	primary	public	identities	8192	2025-10-27 11:29:08.944793
2095	primary	public	identities_pkey	8192	2025-10-27 11:29:08.944793
2096	primary	public	idx_on_account_id_relationship_severance_event_id_7bd82bf20e	8192	2025-10-27 11:29:08.944793
2097	primary	public	idx_on_account_id_target_account_id_a8c8ddf44e	8192	2025-10-27 11:29:08.944793
2098	primary	public	idx_on_relationship_severance_event_id_403f53e707	8192	2025-10-27 11:29:08.944793
2099	primary	public	imports	8192	2025-10-27 11:29:08.944793
2100	primary	public	imports_pkey	8192	2025-10-27 11:29:08.944793
2101	primary	public	index_account_aliases_on_account_id	8192	2025-10-27 11:29:08.944793
2102	primary	public	index_account_aliases_on_account_id_and_uri	8192	2025-10-27 11:29:08.944793
2103	primary	public	index_account_conversations_on_conversation_id	8192	2025-10-27 11:29:08.944793
2104	primary	public	index_account_deletion_requests_on_account_id	8192	2025-10-27 11:29:08.944793
2105	primary	public	index_account_domain_blocks_on_account_id_and_domain	8192	2025-10-27 11:29:08.944793
2106	primary	public	index_account_migrations_on_account_id	8192	2025-10-27 11:29:08.944793
2107	primary	public	index_account_migrations_on_target_account_id	8192	2025-10-27 11:29:08.944793
2108	primary	public	index_account_moderation_notes_on_account_id	8192	2025-10-27 11:29:08.944793
2109	primary	public	index_account_moderation_notes_on_target_account_id	8192	2025-10-27 11:29:08.944793
2110	primary	public	index_account_notes_on_account_id_and_target_account_id	8192	2025-10-27 11:29:08.944793
2111	primary	public	index_account_notes_on_target_account_id	8192	2025-10-27 11:29:08.944793
2112	primary	public	index_account_pins_on_account_id_and_target_account_id	8192	2025-10-27 11:29:08.944793
2113	primary	public	index_account_pins_on_target_account_id	8192	2025-10-27 11:29:08.944793
2114	primary	public	index_account_relationship_severance_events_on_account_id	8192	2025-10-27 11:29:08.944793
2115	primary	public	index_account_statuses_cleanup_policies_on_account_id	8192	2025-10-27 11:29:08.944793
2116	primary	public	index_account_warnings_on_account_id	8192	2025-10-27 11:29:08.944793
2117	primary	public	index_account_warnings_on_target_account_id	8192	2025-10-27 11:29:08.944793
2118	primary	public	index_accounts_on_moved_to_account_id	8192	2025-10-27 11:29:08.944793
2119	primary	public	index_accounts_on_url	8192	2025-10-27 11:29:08.944793
2120	primary	public	index_accounts_tags_on_account_id_and_tag_id	8192	2025-10-27 11:29:08.944793
2121	primary	public	index_admin_action_logs_on_account_id	8192	2025-10-27 11:29:08.944793
2122	primary	public	index_admin_action_logs_on_target_type_and_target_id	8192	2025-10-27 11:29:08.944793
2123	primary	public	index_announcement_mutes_on_account_id_and_announcement_id	8192	2025-10-27 11:29:08.944793
2124	primary	public	index_announcement_mutes_on_announcement_id	8192	2025-10-27 11:29:08.944793
2125	primary	public	index_announcement_reactions_on_account_id_and_announcement_id	8192	2025-10-27 11:29:08.944793
2126	primary	public	index_announcement_reactions_on_announcement_id	8192	2025-10-27 11:29:08.944793
2127	primary	public	index_announcement_reactions_on_custom_emoji_id	8192	2025-10-27 11:29:08.944793
2128	primary	public	index_appeals_on_account_id	8192	2025-10-27 11:29:08.944793
2129	primary	public	index_appeals_on_account_warning_id	8192	2025-10-27 11:29:08.944793
2130	primary	public	index_appeals_on_approved_by_account_id	8192	2025-10-27 11:29:08.944793
2131	primary	public	index_appeals_on_rejected_by_account_id	8192	2025-10-27 11:29:08.944793
2132	primary	public	index_backups_on_user_id	8192	2025-10-27 11:29:08.944793
2133	primary	public	index_blocks_on_account_id_and_target_account_id	8192	2025-10-27 11:29:08.944793
2134	primary	public	index_blocks_on_target_account_id	8192	2025-10-27 11:29:08.944793
2135	primary	public	index_bookmarks_on_account_id_and_status_id	8192	2025-10-27 11:29:08.944793
2136	primary	public	index_bookmarks_on_status_id	8192	2025-10-27 11:29:08.944793
2137	primary	public	index_bulk_import_rows_on_bulk_import_id	8192	2025-10-27 11:29:08.944793
2138	primary	public	index_bulk_imports_on_account_id	8192	2025-10-27 11:29:08.944793
2139	primary	public	index_bulk_imports_unconfirmed	8192	2025-10-27 11:29:08.944793
2140	primary	public	index_canonical_email_blocks_on_canonical_email_hash	8192	2025-10-27 11:29:08.944793
2141	primary	public	index_canonical_email_blocks_on_reference_account_id	8192	2025-10-27 11:29:08.944793
2142	primary	public	index_conversation_mutes_on_account_id_and_conversation_id	8192	2025-10-27 11:29:08.944793
2143	primary	public	index_conversations_on_uri	8192	2025-10-27 11:29:08.944793
2144	primary	public	index_custom_emoji_categories_on_name	8192	2025-10-27 11:29:08.944793
2145	primary	public	index_custom_emojis_on_shortcode_and_domain	8192	2025-10-27 11:29:08.944793
2146	primary	public	index_custom_filter_statuses_on_custom_filter_id	8192	2025-10-27 11:29:08.944793
2147	primary	public	index_custom_filter_statuses_on_status_id	8192	2025-10-27 11:29:08.944793
2148	primary	public	index_custom_filter_statuses_on_status_id_and_custom_filter_id	8192	2025-10-27 11:29:08.944793
2149	primary	public	index_domain_allows_on_domain	8192	2025-10-27 11:29:08.944793
2150	primary	public	index_domain_blocks_on_domain	8192	2025-10-27 11:29:08.944793
2151	primary	public	index_email_domain_blocks_on_domain	8192	2025-10-27 11:29:08.944793
2152	primary	public	index_favourites_on_account_id_and_id	8192	2025-10-27 11:29:08.944793
2153	primary	public	index_favourites_on_account_id_and_status_id	8192	2025-10-27 11:29:08.944793
2154	primary	public	index_favourites_on_status_id	8192	2025-10-27 11:29:08.944793
2155	primary	public	index_featured_tags_on_account_id_and_tag_id	8192	2025-10-27 11:29:08.944793
2156	primary	public	index_featured_tags_on_tag_id	8192	2025-10-27 11:29:08.944793
2157	primary	public	index_follow_recommendation_mutes_on_target_account_id	8192	2025-10-27 11:29:08.944793
2158	primary	public	index_follow_recommendation_suppressions_on_account_id	8192	2025-10-27 11:29:08.944793
2159	primary	public	index_follow_requests_on_account_id_and_target_account_id	8192	2025-10-27 11:29:08.944793
2160	primary	public	index_generated_annual_reports_on_account_id_and_year	8192	2025-10-27 11:29:08.944793
2161	primary	public	index_global_follow_recommendations_on_account_id	8192	2025-10-27 11:29:08.944793
2162	primary	public	index_identities_on_uid_and_provider	8192	2025-10-27 11:29:08.944793
2163	primary	public	index_identities_on_user_id	8192	2025-10-27 11:29:08.944793
2164	primary	public	index_instances_on_domain	8192	2025-10-27 11:29:08.944793
2165	primary	public	index_instances_on_reverse_domain	8192	2025-10-27 11:29:08.944793
2166	primary	public	index_ip_blocks_on_ip	8192	2025-10-27 11:29:08.944793
2167	primary	public	index_list_accounts_on_account_id_and_list_id	8192	2025-10-27 11:29:08.944793
2168	primary	public	index_list_accounts_on_follow_id	8192	2025-10-27 11:29:08.944793
2169	primary	public	index_list_accounts_on_follow_request_id	8192	2025-10-27 11:29:08.944793
2170	primary	public	index_list_accounts_on_list_id_and_account_id	8192	2025-10-27 11:29:08.944793
2171	primary	public	index_lists_on_account_id	8192	2025-10-27 11:29:08.944793
2172	primary	public	index_media_attachments_on_scheduled_status_id	8192	2025-10-27 11:29:08.944793
2173	primary	public	index_media_attachments_on_shortcode	8192	2025-10-27 11:29:08.944793
2174	primary	public	index_mentions_on_account_id_and_status_id	8192	2025-10-27 11:29:08.944793
2175	primary	public	index_mentions_on_status_id	8192	2025-10-27 11:29:08.944793
2176	primary	public	index_mutes_on_account_id_and_target_account_id	8192	2025-10-27 11:29:08.944793
2177	primary	public	index_mutes_on_target_account_id	8192	2025-10-27 11:29:08.944793
2178	primary	public	index_notification_permissions_on_account_id	8192	2025-10-27 11:29:08.944793
2179	primary	public	index_notification_permissions_on_from_account_id	8192	2025-10-27 11:29:08.944793
2180	primary	public	index_notification_requests_on_account_id_and_from_account_id	8192	2025-10-27 11:29:08.944793
2181	primary	public	index_notification_requests_on_from_account_id	8192	2025-10-27 11:29:08.944793
2182	primary	public	index_notification_requests_on_last_status_id	8192	2025-10-27 11:29:08.944793
2183	primary	public	index_oauth_access_tokens_on_refresh_token	8192	2025-10-27 11:29:08.944793
2184	primary	public	index_preview_card_providers_on_domain	8192	2025-10-27 11:29:08.944793
2185	primary	public	index_preview_card_trends_on_preview_card_id	8192	2025-10-27 11:29:08.944793
2186	primary	public	index_preview_cards_on_author_account_id	8192	2025-10-27 11:29:08.944793
2187	primary	public	index_preview_cards_on_url	8192	2025-10-27 11:29:08.944793
2188	primary	public	index_relationship_severance_events_on_type_and_target_name	8192	2025-10-27 11:29:08.944793
2189	primary	public	index_report_notes_on_account_id	8192	2025-10-27 11:29:08.944793
2190	primary	public	index_report_notes_on_report_id	8192	2025-10-27 11:29:08.944793
2191	primary	public	index_reports_on_action_taken_by_account_id	8192	2025-10-27 11:29:08.944793
2192	primary	public	index_reports_on_assigned_account_id	8192	2025-10-27 11:29:08.944793
2193	primary	public	index_scheduled_statuses_on_account_id	8192	2025-10-27 11:29:08.944793
2194	primary	public	index_scheduled_statuses_on_scheduled_at	8192	2025-10-27 11:29:08.944793
2195	primary	public	index_settings_on_thing_type_and_thing_id_and_var	8192	2025-10-27 11:29:08.944793
2196	primary	public	index_severed_relationships_on_local_account_and_event	8192	2025-10-27 11:29:08.944793
2197	primary	public	index_severed_relationships_on_remote_account_id	8192	2025-10-27 11:29:08.944793
2198	primary	public	index_severed_relationships_on_unique_tuples	8192	2025-10-27 11:29:08.944793
2199	primary	public	index_site_uploads_on_var	8192	2025-10-27 11:29:08.944793
2200	primary	public	index_status_pins_on_account_id_and_status_id	8192	2025-10-27 11:29:08.944793
2201	primary	public	index_status_pins_on_status_id	8192	2025-10-27 11:29:08.944793
2202	primary	public	index_status_trends_on_account_id	8192	2025-10-27 11:29:08.944793
2203	primary	public	index_status_trends_on_status_id	8192	2025-10-27 11:29:08.944793
2204	primary	public	index_statuses_on_in_reply_to_account_id	8192	2025-10-27 11:29:08.944793
2205	primary	public	index_statuses_on_in_reply_to_id	8192	2025-10-27 11:29:08.944793
2206	primary	public	index_tag_follows_on_account_id_and_tag_id	8192	2025-10-27 11:29:08.944793
2207	primary	public	index_tag_follows_on_tag_id	8192	2025-10-27 11:29:08.944793
2208	primary	public	index_tombstones_on_account_id	8192	2025-10-27 11:29:08.944793
2209	primary	public	index_tombstones_on_uri	8192	2025-10-27 11:29:08.944793
2210	primary	public	index_unavailable_domains_on_domain	8192	2025-10-27 11:29:08.944793
2211	primary	public	index_unique_conversations	8192	2025-10-27 11:29:08.944793
2212	primary	public	index_user_invite_requests_on_user_id	8192	2025-10-27 11:29:08.944793
2213	primary	public	index_users_on_reset_password_token	8192	2025-10-27 11:29:08.944793
2214	primary	public	index_users_on_unconfirmed_email	8192	2025-10-27 11:29:08.944793
2215	primary	public	index_web_push_subscriptions_on_access_token_id	8192	2025-10-27 11:29:08.944793
2216	primary	public	index_web_push_subscriptions_on_user_id	8192	2025-10-27 11:29:08.944793
2217	primary	public	index_webauthn_credentials_on_external_id	8192	2025-10-27 11:29:08.944793
2218	primary	public	index_webauthn_credentials_on_user_id	8192	2025-10-27 11:29:08.944793
2219	primary	public	index_webauthn_credentials_on_user_id_and_nickname	8192	2025-10-27 11:29:08.944793
2220	primary	public	index_webhooks_on_url	8192	2025-10-27 11:29:08.944793
2221	primary	public	instances	8192	2025-10-27 11:29:08.944793
2222	primary	public	ip_blocks	8192	2025-10-27 11:29:08.944793
2223	primary	public	ip_blocks_pkey	8192	2025-10-27 11:29:08.944793
2224	primary	public	list_accounts_pkey	8192	2025-10-27 11:29:08.944793
2225	primary	public	lists	8192	2025-10-27 11:29:08.944793
2226	primary	public	lists_pkey	8192	2025-10-27 11:29:08.944793
2227	primary	public	mentions_pkey	8192	2025-10-27 11:29:08.944793
2228	primary	public	mutes_pkey	8192	2025-10-27 11:29:08.944793
2229	primary	public	notification_permissions_pkey	8192	2025-10-27 11:29:08.944793
2230	primary	public	notification_policies	8192	2025-10-27 11:29:08.944793
2231	primary	public	notification_requests_pkey	8192	2025-10-27 11:29:08.944793
2232	primary	public	preview_card_providers	8192	2025-10-27 11:29:08.944793
2233	primary	public	preview_card_providers_pkey	8192	2025-10-27 11:29:08.944793
2234	primary	public	preview_card_trends	8192	2025-10-27 11:29:08.944793
2235	primary	public	preview_card_trends_pkey	8192	2025-10-27 11:29:08.944793
2236	primary	public	preview_cards	8192	2025-10-27 11:29:08.944793
2237	primary	public	preview_cards_pkey	8192	2025-10-27 11:29:08.944793
2238	primary	public	preview_cards_statuses	8192	2025-10-27 11:29:08.944793
2239	primary	public	preview_cards_statuses_pkey	8192	2025-10-27 11:29:08.944793
2240	primary	public	relationship_severance_events	8192	2025-10-27 11:29:08.944793
2241	primary	public	relationship_severance_events_pkey	8192	2025-10-27 11:29:08.944793
2242	primary	public	relays	8192	2025-10-27 11:29:08.944793
2243	primary	public	relays_pkey	8192	2025-10-27 11:29:08.944793
2244	primary	public	report_notes	8192	2025-10-27 11:29:08.944793
2245	primary	public	report_notes_pkey	8192	2025-10-27 11:29:08.944793
2246	primary	public	rules	8192	2025-10-27 11:29:08.944793
2247	primary	public	rules_pkey	8192	2025-10-27 11:29:08.944793
2248	primary	public	scheduled_statuses	8192	2025-10-27 11:29:08.944793
2249	primary	public	scheduled_statuses_pkey	8192	2025-10-27 11:29:08.944793
2250	primary	public	settings	8192	2025-10-27 11:29:08.944793
2251	primary	public	settings_pkey	8192	2025-10-27 11:29:08.944793
2252	primary	public	severed_relationships	8192	2025-10-27 11:29:08.944793
2253	primary	public	severed_relationships_pkey	8192	2025-10-27 11:29:08.944793
2254	primary	public	site_uploads	8192	2025-10-27 11:29:08.944793
2255	primary	public	site_uploads_pkey	8192	2025-10-27 11:29:08.944793
2256	primary	public	status_pins_pkey	8192	2025-10-27 11:29:08.944793
2257	primary	public	status_stats	8192	2025-10-27 11:29:08.944793
2258	primary	public	status_trends	8192	2025-10-27 11:29:08.944793
2259	primary	public	status_trends_pkey	8192	2025-10-27 11:29:08.944793
2260	primary	public	statuses_tags	8192	2025-10-27 11:29:08.944793
2261	primary	public	tag_follows_pkey	8192	2025-10-27 11:29:08.944793
2262	primary	public	tombstones	8192	2025-10-27 11:29:08.944793
2263	primary	public	tombstones_pkey	8192	2025-10-27 11:29:08.944793
2264	primary	public	unavailable_domains	8192	2025-10-27 11:29:08.944793
2265	primary	public	unavailable_domains_pkey	8192	2025-10-27 11:29:08.944793
2266	primary	public	user_invite_requests	8192	2025-10-27 11:29:08.944793
2267	primary	public	user_invite_requests_pkey	8192	2025-10-27 11:29:08.944793
2268	primary	public	web_push_subscriptions	8192	2025-10-27 11:29:08.944793
2269	primary	public	web_push_subscriptions_pkey	8192	2025-10-27 11:29:08.944793
2270	primary	public	webauthn_credentials	8192	2025-10-27 11:29:08.944793
2271	primary	public	webauthn_credentials_pkey	8192	2025-10-27 11:29:08.944793
2272	primary	public	webhooks	8192	2025-10-27 11:29:08.944793
2273	primary	public	webhooks_pkey	8192	2025-10-27 11:29:08.944793
2274	primary	public	account_deletion_requests	0	2025-10-27 11:29:08.944793
2275	primary	public	account_pins	0	2025-10-27 11:29:08.944793
2276	primary	public	account_relationship_severance_events	0	2025-10-27 11:29:08.944793
2277	primary	public	account_statuses_cleanup_policies	0	2025-10-27 11:29:08.944793
2278	primary	public	accounts_tags	0	2025-10-27 11:29:08.944793
2279	primary	public	announcement_mutes	0	2025-10-27 11:29:08.944793
2280	primary	public	bookmarks	0	2025-10-27 11:29:08.944793
2281	primary	public	conversation_mutes	0	2025-10-27 11:29:08.944793
2282	primary	public	custom_filter_statuses	0	2025-10-27 11:29:08.944793
2283	primary	public	favourites	0	2025-10-27 11:29:08.944793
2284	primary	public	follow_recommendation_mutes	0	2025-10-27 11:29:08.944793
2285	primary	public	follow_recommendation_suppressions	0	2025-10-27 11:29:08.944793
2286	primary	public	list_accounts	0	2025-10-27 11:29:08.944793
2287	primary	public	mentions	0	2025-10-27 11:29:08.944793
2288	primary	public	mutes	0	2025-10-27 11:29:08.944793
2289	primary	public	notification_permissions	0	2025-10-27 11:29:08.944793
2290	primary	public	notification_requests	0	2025-10-27 11:29:08.944793
2291	primary	public	status_pins	0	2025-10-27 11:29:08.944793
2292	primary	public	tag_follows	0	2025-10-27 11:29:08.944793
\.


--
-- Data for Name: poll_votes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.poll_votes (id, account_id, poll_id, choice, created_at, updated_at, uri) FROM stdin;
1	115338428522805842	1	0	2025-10-10 05:06:48.125298	2025-10-10 05:06:48.125298	\N
\.


--
-- Data for Name: polls; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.polls (id, account_id, status_id, expires_at, options, cached_tallies, multiple, hide_totals, votes_count, last_fetched_at, created_at, updated_at, lock_version, voters_count) FROM stdin;
1	115338428325536028	115348126416869763	2025-10-11 05:05:29.743038	{YSE,NO}	{1,0}	f	f	1	\N	2025-10-10 05:05:29.750837	2025-10-10 05:06:48.895376	2	1
2	115338428522805842	115433627788463436	2025-11-01 07:29:37.130441	{USA,China,Russia,Brazil}	{0,0,0,0}	t	f	0	\N	2025-10-25 07:29:37.156763	2025-10-25 07:29:37.156763	0	0
\.


--
-- Data for Name: preview_card_providers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.preview_card_providers (id, domain, icon_file_name, icon_content_type, icon_file_size, icon_updated_at, trendable, reviewed_at, requested_review_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: preview_card_trends; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.preview_card_trends (id, preview_card_id, score, rank, allowed, language) FROM stdin;
\.


--
-- Data for Name: preview_cards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.preview_cards (id, url, title, description, image_file_name, image_content_type, image_file_size, image_updated_at, type, html, author_name, author_url, provider_name, provider_url, width, height, created_at, updated_at, embed_url, image_storage_schema_version, blurhash, language, max_score, max_score_at, trendable, link_type, published_at, image_description, author_account_id) FROM stdin;
\.


--
-- Data for Name: preview_cards_statuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.preview_cards_statuses (preview_card_id, status_id, url) FROM stdin;
\.


--
-- Data for Name: relationship_severance_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.relationship_severance_events (id, type, target_name, purged, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: relays; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.relays (id, inbox_url, follow_activity_id, created_at, updated_at, state) FROM stdin;
\.


--
-- Data for Name: report_notes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.report_notes (id, content, report_id, account_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reports (id, status_ids, comment, created_at, updated_at, account_id, action_taken_by_account_id, target_account_id, assigned_account_id, uri, forwarded, category, action_taken_at, rule_ids, application_id) FROM stdin;
1	{115348126416869763}		2025-10-13 20:05:08.438839	2025-10-13 20:05:08.438839	115338428522805842	\N	115338428325536028	\N	https://10.0.2.2/a58c11c7-4efa-48e5-a2b5-c566ec4411b2	f	0	\N	\N	10
2	{115348126416869763}		2025-10-13 20:09:03.722329	2025-10-13 20:09:03.722329	115338428522805842	\N	115338428325536028	\N	https://10.0.2.2/357855ad-e2a2-4794-9e6f-657d7a1912b7	f	1000	\N	\N	10
\.


--
-- Data for Name: rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rules (id, priority, deleted_at, text, created_at, updated_at, hint) FROM stdin;
\.


--
-- Data for Name: scheduled_statuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scheduled_statuses (id, account_id, scheduled_at, params) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schema_migrations (version) FROM stdin;
20241007071624
20240916190140
20240909014637
20240808125420
20240808124339
20240808124338
20240808114841
20240724181224
20240720140205
20240713171909
20240713171841
20240712064044
20240607094856
20240607094603
20240607093954
20240607093446
20240603195202
20240522041528
20240513123807
20240513095755
20240510192043
20240322161611
20240322130318
20240322125607
20240321160706
20240320163441
20240320140159
20240312105620
20240312100644
20240310123453
20240307180905
20240304090449
20240227191620
20240222203722
20240222193403
20240221211359
20240221195828
20240221195424
20240217171534
20240111033014
20240109103012
20231222100226
20231212073317
20231211234923
20231210154528
20231018193659
20231018193355
20231018193209
20231018192110
20231006183200
20230907150100
20230904134623
20230822081029
20230818142253
20230818141056
20230814223300
20230811103651
20230803112520
20230803082451
20230725213448
20230724160715
20230702151753
20230702131023
20230630145300
20230605085711
20230605085710
20230531154811
20230531153942
20230524194155
20230524192812
20230524190515
20230330155710
20230330140036
20230330135507
20230215074423
20230215074327
20230129023109
20221206114142
20221104133904
20221101190723
20221025171544
20221021055441
20221012181003
20221006061337
20220829192658
20220829192633
20220827195229
20220824233535
20220824164532
20220824164433
20220808101323
20220729171123
20220714171049
20220710102457
20220704024901
20220617202502
20220613110903
20220613110834
20220613110802
20220613110711
20220613110628
20220611212541
20220611210335
20220606044941
20220527114923
20220429101850
20220429101025
20220428114902
20220428114454
20220428112727
20220428112511
20220316233212
20220310060959
20220310060939
20220310060926
20220310060913
20220310060854
20220310060833
20220310060809
20220310060750
20220310060740
20220310060722
20220310060706
20220310060653
20220310060641
20220310060626
20220310060614
20220310060556
20220310060545
20220309213005
20220307094650
20220307083603
20220304195405
20220303203437
20220303000827
20220302232632
20220227041951
20220224010024
20220210153119
20220202201015
20220202200926
20220202200743
20220124141035
20220118183123
20220118183010
20220116202951
20220115125341
20220115125126
20220109213908
20220105163928
20211231080958
20211213040746
20211126000907
20211123212714
20211115032527
20211112011713
20211031031021
20210908220918
20210904215403
20210808071221
20210722120340
20210630000137
20210621221010
20210616214526
20210616214135
20210609202149
20210526193025
20210507001928
20210505174616
20210502233513
20210425135952
20210421121431
20210416200740
20210324171613
20210323114347
20210322164601
20210308133107
20210306164523
20210221045109
20201218054746
20201206004238
20201017234926
20201017233919
20201008220312
20201008202037
20200917222734
20200917222316
20200917193528
20200917193034
20200917192924
20200908193330
20200630190544
20200630190240
20200628133322
20200627125810
20200622213645
20200620164023
20200614002136
20200608113046
20200605155027
20200601222558
20200529214050
20200521180606
20200518083523
20200516183822
20200516180352
20200510181721
20200510110808
20200508212852
20200417125749
20200407202420
20200407201300
20200317021758
20200312185443
20200312162302
20200312144258
20200309150742
20200306035625
20200126203551
20200119112504
20200114113335
20200113125135
20191218153258
20191212163405
20191212003415
20191031163205
20191007013357
20191001213028
20190927232842
20190927124642
20190917213523
20190915194355
20190914202517
20190904222339
20190901040524
20190901035623
20190823221802
20190820003045
20190819134503
20190815225426
20190807135426
20190805123746
20190729185330
20190726175042
20190715164535
20190715031050
20190706233204
20190705002136
20190701022101
20190627222826
20190627222225
20190529143559
20190519130537
20190511152737
20190511134027
20190509164208
20190420025523
20190409054914
20190403141604
20190317135723
20190316190352
20190314181829
20190307234537
20190306145741
20190304152020
20190226003449
20190225031625
20190225031541
20190203180359
20190201012802
20190117114553
20190103124754
20190103124649
20181226021420
20181219235220
20181213185533
20181213184704
20181207011115
20181204215309
20181204193439
20181203021853
20181203003808
20181127165847
20181127130500
20181116184611
20181116173541
20181116165755
20181026034033
20181024224956
20181018205649
20181017170937
20181010141500
20181007025445
20180929222014
20180831171112
20180820232245
20180814171349
20180813113448
20180812173710
20180812162710
20180812123222
20180808175627
20180711152640
20180707154237
20180628181026
20180617162849
20180616192031
20180615122121
20180609104432
20180608213548
20180528141303
20180514140000
20180514130000
20180510230049
20180510214435
20180506221944
20180416210259
20180410204633
20180402040909
20180402031200
20180310000000
20180304013859
20180211015820
20180206000000
20180204034416
20180109143959
20180106000232
20171226094803
20171212195226
20171201000000
20171130000000
20171129172043
20171125190735
20171125185353
20171125031751
20171125024930
20171122120436
20171119172437
20171118012443
20171116161857
20171114231651
20171114080328
20171109012327
20171107143624
20171107143332
20171028221157
20171020084748
20171010025614
20171010023049
20171006142024
20171005171936
20171005102658
20170928082043
20170927215609
20170924022025
20170920032311
20170920024819
20170918125918
20170917153509
20170913000752
20170905165803
20170905044538
20170901142658
20170901141119
20170829215220
20170824103029
20170823162448
20170720000000
20170718211102
20170716191202
20170714184731
20170713190709
20170713175513
20170713112503
20170711225116
20170625140443
20170624134742
20170623152212
20170610000000
20170609145826
20170606113804
20170604144747
20170601210557
20170520145338
20170516072309
20170508230434
20170507141759
20170507000211
20170506235850
20170427011934
20170425202925
20170425131920
20170424112722
20170424003227
20170423005413
20170418160728
20170414132105
20170414080609
20170409170753
20170406215816
20170405112956
20170403172249
20170330164118
20170330163835
20170330021336
20170322162804
20170322143850
20170322021028
20170318214217
20170317193015
20170304202101
20170303212857
20170301222600
20170217012631
20170214110202
20170209184350
20170205175257
20170127165745
20170125145934
20170123203248
20170123162658
20170119214911
20170114203041
20170114194937
20170112154826
20170109120109
20170105224407
20161222204147
20161222201034
20161221152630
20161205214545
20161203164520
20161202132159
20161130185319
20161130142058
20161128103007
20161123093447
20161122163057
20161119211120
20161116162355
20161105130633
20161104173623
20161027172456
20161009120834
20161006213403
20161003145426
20161003142332
20160926213048
20160920003904
20160919221059
20160905150353
20160826155805
20160325130944
20160322193748
20160316103650
20160314164231
20160312193225
20160306172223
20160305115639
20160227230233
20160224223247
20160223171800
20160223165855
20160223165723
20160223164502
20160223162837
20160222143943
20160222122600
20160221003621
20160221003140
20160220211917
20160220174730
\.


--
-- Data for Name: session_activations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.session_activations (id, session_id, created_at, updated_at, user_agent, ip, access_token_id, user_id, web_push_subscription_id) FROM stdin;
3	dd8b6606c2ba232604f4d080253a0f4c	2025-10-08 14:50:34.975344	2025-10-08 14:50:34.975344	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	172.18.0.1	4	3	\N
7	e315bea877d8fb22d1501bd50e884c8f	2025-10-10 05:06:41.596243	2025-10-13 07:22:38.514235	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	172.18.0.1	15	3	\N
11	34ab27530b8a6f370e76831e6912b83c	2025-10-16 12:31:09.551356	2025-10-16 12:31:09.551356	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	172.18.0.1	24	3	\N
14	c177709c7b2ea1954eb7ff913b6d6214	2025-10-21 06:57:12.461976	2025-10-21 06:57:12.461976	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	172.18.0.1	31	3	\N
18	e175eebc17e7560c0ae3f532cf62d20c	2025-10-27 13:36:40.212534	2025-10-27 13:36:40.212534	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	172.18.0.1	38	6	\N
23	4b29da37b2bbae6123c33f6f098991a4	2025-10-03 03:15:53.433307	2025-10-03 03:15:53.433307	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	172.18.0.1	49	15	\N
55	97729059b6f99b1bc6d4026de47e008f	2025-10-15 14:31:53.855843	2025-10-15 14:31:53.855843	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	172.18.0.1	81	1	\N
57	23f6505a02372593f54614c169061004	2025-11-17 12:15:53.928687	2025-11-17 12:15:53.928687	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36	172.18.0.1	85	3	\N
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settings (id, var, value, thing_type, created_at, updated_at, thing_id) FROM stdin;
\.


--
-- Data for Name: severed_relationships; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.severed_relationships (id, relationship_severance_event_id, local_account_id, remote_account_id, direction, show_reblogs, notify, languages, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: site_uploads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.site_uploads (id, var, file_file_name, file_content_type, file_file_size, file_updated_at, meta, created_at, updated_at, blurhash) FROM stdin;
\.


--
-- Data for Name: software_updates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.software_updates (id, version, urgent, type, release_notes, created_at, updated_at) FROM stdin;
2	4.3.14	f	0	https://github.com/mastodon/mastodon/releases/tag/v4.3.14	2025-10-16 12:06:55.60423	2025-10-16 12:06:55.60423
3	4.4.8	f	1	https://github.com/mastodon/mastodon/releases/tag/v4.4.8	2025-10-04 06:30:02.124428	2025-10-04 06:30:02.124428
\.


--
-- Data for Name: status_edits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status_edits (id, status_id, account_id, text, spoiler_text, created_at, updated_at, ordered_media_attachment_ids, media_descriptions, poll_options, sensitive) FROM stdin;
1	115297747807930559	115445893227871976	"Finally finished that 10-page paper. Rewarding myself with a massive pizza 🍕 Who else is celebrating small victories today? #StudentWins #CollegeStress"		2025-10-01 07:33:33.183007	2025-10-01 07:44:02.983111	{}	{}	\N	f
2	115297747807930559	115445893227871976	"Finally finished that 10-page paper. Rewarding myself with a massive pizza 🍕 Who else is celebrating small victories today? #StudentWins #CollegeStress"		2025-10-01 07:44:03.004039	2025-10-01 07:44:03.034686	{115297788590177428}	{NULL}	\N	f
4	115383769269972821	115383709981264049	🎓 Excited to share next week’s #OpenTalk!\nTopic: AI-Powered Urban Mobility — How Machine Learning Shapes Future Transportation\nSpeaker: Dr. Lin Qiao (Associate Professor, Institute of Intelligent Systems)\nDate & Time: Oct 20, 2025 (Mon) 15:00 – 16:30\nVenue: Auditorium 2-A, Innovation Building\n\n🚗💡 With cities facing congestion and sustainability challenges, this talk explores how modern machine learning can transform traffic prediction, fleet optimization, and eco-routing.\n\n#OpenTalk		2025-10-16 12:09:56.528564	2025-10-27 13:37:16.251408	{}	{}	\N	f
5	115383769269972821	115383709981264049	🎓 Excited to share next week’s #OpenTalk!\nTopic: AI-Powered Urban Mobility\nSpeaker: Dr. Lin Qiao (Associate Professor, Institute of Intelligent Systems)\nDate & Time: Oct 24, 2025 (Mon) 15:00 – 16:30\nVenue: Auditorium 2-A, Innovation Building\n\n🚗💡 With cities facing congestion and sustainability challenges, this talk explores how modern machine learning can transform traffic prediction, fleet optimization, and eco-routing.\n\n#OpenTalk		2025-10-27 13:37:16.270607	2025-10-27 13:37:16.286074	{}	{}	\N	f
6	115359670141158913	115347680582977591	Looking for a Persian but with less grooming? The Exotic Shorthair is the perfect match! They have the same sweet, affectionate personality as the Persian but with a short, manageable coat. These cats are calm, loving, and make wonderful companions. 😽 #ExoticShorthair #EasyCare		2025-10-12 06:01:13.004231	2025-10-12 06:06:48.478962	{}	{}	\N	f
7	115359670141158913	115347680582977591	Looking for a Persian but with less grooming? The Exotic Shorthair is the perfect match! They have the same sweet, affectionate personality as the Persian but with a short, manageable coat. These cats are calm, loving, and make wonderful companions. 😽 #ExoticShorthair #EasyCare #cats		2025-10-12 06:06:48.488338	2025-10-12 06:06:48.49194	{}	{}	\N	f
8	115342692663348018	115347680582977591	The Abyssinian is one of the most active cat breeds! Their sleek, ticked coat and agile nature make them excellent climbers and explorers. These cats are highly intelligent and love to interact with their humans, always keeping you on your toes with their playful antics. 🐾💨 #AbyssinianCat #EnergeticCat		2025-10-09 06:03:37.253356	2025-10-12 06:06:59.87946	{115342692590126513}	{NULL}	\N	f
9	115342692663348018	115347680582977591	The Abyssinian is one of the most active cat breeds! Their sleek, ticked coat and agile nature make them excellent climbers and explorers. These cats are highly intelligent and love to interact with their humans, always keeping you on your toes with their playful antics. 🐾💨 #AbyssinianCat #EnergeticCat #cats		2025-10-12 06:06:59.881974	2025-10-12 06:06:59.88425	{115342692590126513}	{NULL}	\N	f
\.


--
-- Data for Name: status_pins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status_pins (id, account_id, status_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: status_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status_stats (id, status_id, replies_count, reblogs_count, favourites_count, created_at, updated_at) FROM stdin;
2	115339095529918402	0	0	0	2025-10-13 12:57:07.687917	2025-10-13 12:58:00.605357
3	115348126416869763	0	0	0	2025-10-13 13:18:54.11666	2025-10-13 13:19:00.356259
1	115348102480027134	0	0	0	2025-10-10 05:00:16.303549	2025-10-25 06:30:56.031628
\.


--
-- Data for Name: status_trends; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status_trends (id, status_id, account_id, score, rank, allowed, language) FROM stdin;
\.


--
-- Data for Name: statuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.statuses (id, uri, text, created_at, updated_at, in_reply_to_id, reblog_of_id, url, sensitive, visibility, spoiler_text, reply, language, conversation_id, local, account_id, application_id, in_reply_to_account_id, poll_id, deleted_at, edited_at, trendable, ordered_media_attachment_ids) FROM stdin;
115338428759320819	https://10.0.2.2/users/owner/statuses/115338428759320819	Hello from Owner 👋	2025-10-08 11:59:15.248444	2025-10-08 11:59:15.248444	\N	\N	\N	f	0		f	\N	1	t	115338428152261473	\N	\N	\N	\N	\N	\N	\N
115338428764059445	https://10.0.2.2/users/demo/statuses/115338428764059445	Hello from Demo ✨	2025-10-08 11:59:15.310451	2025-10-08 11:59:15.310451	\N	\N	\N	f	0		f	\N	2	t	115338428325536028	\N	\N	\N	\N	\N	\N	\N
115338428767107750	https://10.0.2.2/users/test/statuses/115338428767107750	Hello from Test 🚀	2025-10-08 11:59:15.357231	2025-10-08 11:59:15.357231	\N	\N	\N	f	0		f	\N	3	t	115338428522805842	\N	\N	\N	\N	\N	\N	\N
115339079234848283	https://10.0.2.2/users/demo/statuses/115339079234848283	🏙️ Beijing is my hometown — the heart of China 🇨🇳!\nCan’t wait to welcome you all to visit during the holidays ✨🎉	2025-10-08 14:44:40.722624	2025-10-08 14:44:40.722624	\N	\N	\N	f	0		f	en	4	t	115338428325536028	2	\N	\N	\N	\N	\N	{115339075632389303}
115339087247102887	https://10.0.2.2/users/demo/statuses/115339087247102887	NYC next week! ✈️🗽\nWho’s in town? Let’s grab some food together 😋🍕🍹	2025-10-08 14:46:42.965891	2025-10-08 14:46:42.965891	\N	\N	\N	f	2		f	en	5	t	115338428325536028	2	\N	\N	\N	\N	\N	{115339086365608467}
115339095529918402	https://10.0.2.2/users/demo/statuses/115339095529918402	Had a fun day with Alice 💕 checking out the new K11 mall 🏙️\nTried McDonald’s new meal too 🍔✨ — so happy! 😋🎉	2025-10-08 14:48:49.350203	2025-10-08 14:48:49.350203	\N	\N	\N	f	0		f	en	6	t	115338428325536028	2	\N	\N	\N	\N	\N	{115339094836531384,115339094842664479}
115383849716842309	https://10.0.2.2/users/openUniversity/statuses/115383849716842309	🤖 Don’t miss this week’s #OpenTalk!\nTopic: Embodied GUI Agents — Towards Intelligent Interfaces that Act\nSpeaker: Dr. Evelyn Cho (Human–AI Interaction Lab)\nDate & Time: Nov 3, 2025 (Mon) 15:00 – 16:30\nVenue: Lecture Hall B-102, Cognitive Computing Center\n\nDr. Cho will introduce her lab’s latest work on multimodal agents that can see, click, and reason across graphical interfaces — bridging large language models with visual perception and motor control.\n\n#OpenTalk	2025-10-16 12:30:24.049774	2025-10-16 12:30:24.049774	\N	\N	\N	f	0		f	en	27	t	115383709981264049	18	\N	\N	\N	\N	\N	{}
115383884712317564	https://10.0.2.2/users/openUniversity/statuses/115383884712317564	🔒 Upcoming #OpenTalk — Security in the Age of Generative Models\nSpeaker: Dr. Farid Rahman (Cybersecurity Research Unit)\nDate & Time: Nov 10, 2025 (Mon) 15:30 – 17:00\nVenue: Room 3C-207, Data Science Building\n\nDr. Rahman will share insights into adversarial prompting, data poisoning, and model inversion attacks, along with mitigation techniques for LLM-based applications.\nExpect practical case studies and an open Q&A on responsible model deployment.\n\n#OpenTalk	2025-10-16 12:39:18.039466	2025-10-16 12:39:18.039466	\N	\N	\N	f	0		f	en	28	t	115383709981264049	18	\N	\N	\N	\N	\N	{}
115383982312877318	https://10.0.2.2/users/frank/statuses/115383982312877318	Leaked video shows actress Emma R. admitting to drug use — can’t believe she fooled us all!	2025-10-16 13:04:07.304704	2025-10-16 13:04:07.304704	\N	\N	\N	f	0		f	en	29	t	115383646696917550	17	\N	\N	\N	\N	\N	{115383981873060857}
115348102480027134	https://10.0.2.2/users/demo/statuses/115348102480027134	#dogs\nGolden Retrievers have that rare magic: they don’t just wag their tails — they heal hearts. Maybe it’s time I bring one home. 💛🐶	2025-10-10 04:59:24.505058	2025-10-10 04:59:24.505058	\N	\N	\N	f	0		f	en	10	t	115338428325536028	8	\N	\N	\N	\N	\N	{115348093867186946,115348093881333080,115348093888400356}
115383991708563582	https://10.0.2.2/users/frank/statuses/115383991708563582	My neighbor got the flu shot and was paralyzed the next day. These vaccines are poison — protect your kids by saying no!	2025-10-16 13:06:30.671137	2025-10-16 13:06:30.671137	\N	\N	\N	f	0		f	en	31	t	115383646696917550	17	\N	\N	\N	\N	\N	{}
115348126416869763	https://10.0.2.2/users/demo/statuses/115348126416869763	Would you like to get a pet?	2025-10-10 05:05:29.749272	2025-10-10 05:05:29.749272	\N	\N	\N	f	0		f	en	13	t	115338428325536028	8	\N	1	\N	\N	\N	{}
115383670282413681	https://10.0.2.2/users/frank/statuses/115383670282413681	Doctors don’t want you to know this — drink baking soda with lemon every morning and you’ll never get cancer. Big Pharma hides this cure.	2025-10-16 11:44:46.097382	2025-10-16 11:44:46.097382	\N	\N	\N	f	0		f	en	20	t	115383646696917550	17	\N	\N	\N	\N	\N	{}
115383686318250006	https://10.0.2.2/users/frank/statuses/115383686318250006	Just got a message from my cousin in the fire department — there’s a gas leak near the city mall, they’re covering it up! Leave the area NOW before it explodes!	2025-10-16 11:48:50.784704	2025-10-16 11:48:50.784704	\N	\N	\N	f	0		f	en	21	t	115383646696917550	17	\N	\N	\N	\N	\N	{}
115383714683140568	https://10.0.2.2/users/frank/statuses/115383714683140568	Don’t bother voting tomorrow, they already decided the winner. The machines delete any ballot that isn’t for Party X.	2025-10-16 11:56:03.598155	2025-10-16 11:56:03.598155	\N	\N	\N	f	0		f	en	22	t	115383646696917550	17	\N	\N	\N	\N	\N	{}
115383739473577086	https://10.0.2.2/users/frank/statuses/115383739473577086	Open your eyes — immigrants are secretly getting free houses while locals pay rent. The media is silent because they’re all in on it.	2025-10-16 12:02:21.869572	2025-10-16 12:02:21.869572	\N	\N	\N	f	0		f	en	23	t	115383646696917550	17	\N	\N	\N	\N	\N	{}
115383802106899661	https://10.0.2.2/users/openUniversity/statuses/115383802106899661	🌐 Join us for the upcoming #OpenTalk!\nTopic: Beyond the Cloud — The Future of Edge Intelligence in Everyday Devices\nSpeaker: Prof. Mateo Zhang (School of Computing Systems)\nDate & Time: Oct 27, 2025 (Mon) 14:30 – 16:00\nVenue: Room 401, Tech Innovation Center\n\nProf. Zhang will demonstrate how low-power AI accelerators and federated learning can enable privacy-preserving, real-time adaptation on smartphones, sensors, and wearables.\n\n#OpenTalk	2025-10-16 12:18:17.57906	2025-10-16 12:18:17.57906	\N	\N	\N	f	0		f	en	25	t	115383709981264049	18	\N	\N	\N	\N	\N	{}
115383838647217129	https://10.0.2.2/users/frank/statuses/115383838647217129	Gov’t just announced a $1,000 energy rebate. Click here to claim yours before midnight: https://benefits.portal.example.com/us/energy/rebate?id=7f23a9&verify=bank. You only need your ID and bank info.	2025-10-16 12:27:35.139431	2025-10-16 12:27:35.139431	\N	\N	\N	f	0		f	en	26	t	115383646696917550	17	\N	\N	\N	\N	\N	{}
115383987272402574	https://10.0.2.2/users/openUniversity/statuses/115383987272402574	🧠 Coming soon: #OpenTalk on The Cognitive Limits of Artificial Understanding\nSpeaker: Prof. Maria Velasquez (Center for Computational Cognition)\nDate & Time: Nov 17, 2025 (Mon) 14:00 – 15:30\nVenue: Room 2201, Knowledge Science Building\n\nCan large models truly understand meaning?\nProf. Velasquez will bridge cognitive psychology and neural computation to explore where current AI reasoning diverges from human mental models.\n\n#OpenTalk	2025-10-16 13:05:22.981438	2025-10-16 13:05:22.981438	\N	\N	\N	f	0		f	en	30	t	115383709981264049	18	\N	\N	\N	\N	\N	{}
115384006900557641	https://10.0.2.2/users/frank/statuses/115384006900557641	Heartbreaking! Earthquake victims need help. Please send any amount to this PayPal address — we’re directly helping families! \nPayPal: family-relief@donations.invalid	2025-10-16 13:10:22.482657	2025-10-16 13:10:22.482657	\N	\N	\N	f	0		f	en	32	t	115383646696917550	17	\N	\N	\N	\N	\N	{}
115384014916118822	https://10.0.2.2/users/openUniversity/statuses/115384014916118822	🌱 Wrapping up this month’s #OpenTalk series!\nTopic: Green AI — Designing Sustainable Computation for a Carbon-Conscious Future\nSpeaker: Dr. Kai Nakamura\nDate & Time: Nov 24, 2025 (Mon) 15:00 – 16:30\nVenue: EcoTech Auditorium, Energy Research Center\n\nDr. Nakamura will discuss new frameworks for measuring and reducing the carbon footprint of AI training and inference.\nTopics include energy-aware model design, lifecycle tracking in sustainable AI ecosystems.\n\n#OpenTalk	2025-10-16 13:12:24.792278	2025-10-16 13:12:24.792278	\N	\N	\N	f	0		f	en	33	t	115383709981264049	18	\N	\N	\N	\N	\N	{}
115410810887077411	https://10.0.2.2/users/pupper/statuses/115410810887077411	The Labrador Retriever is known for its friendly and outgoing nature. Originally bred for retrieving game during hunts, it is highly trainable and loves to swim. Because of their stable temperament, Labs are often used as service dogs or companions.\n\n#dogs #puppy	2025-10-21 06:46:58.860707	2025-10-21 06:46:58.860707	\N	\N	\N	f	0		f	en	34	t	115410778295457737	22	\N	\N	\N	\N	\N	{115410808524757931}
115410813905484454	https://10.0.2.2/users/pupper/statuses/115410813905484454	#pets #puppy #dogs\nThe German Shepherd is intelligent, loyal, and versatile. It excels in many roles such as police work, search-and-rescue, and protection. With proper training and socialization, it can be both a guardian and a loving family pet.	2025-10-21 06:47:44.917598	2025-10-21 06:47:44.917598	\N	\N	\N	f	0		f	en	35	t	115410778295457737	22	\N	\N	\N	\N	\N	{115410813763931783}
115410818912936581	https://10.0.2.2/users/pupper/statuses/115410818912936581	#lovely #pets\nBulldogs are sturdy #dogs with a distinctive pushed-in face and a calm demeanor. They don’t need excessive exercise, so they adapt well to apartment living. Although they look strong, they are very affectionate with their family.	2025-10-21 06:49:01.325391	2025-10-21 06:49:01.325391	\N	\N	\N	f	0		f	en	36	t	115410778295457737	22	\N	\N	\N	\N	\N	{115410818800106320,115410818807091709}
115410836820181445	https://10.0.2.2/users/pupper/statuses/115410836820181445	The Border Collie is often regarded as the most intelligent dog breed, with exceptional herding instincts. They are energetic and thrive on mental challenges like agility training or obedience tasks. Without enough stimulation, they may become bored or restless.\n\n#puppy #dogs #pets #cute	2025-10-21 06:53:34.566084	2025-10-21 06:53:34.566084	\N	\N	\N	f	0		f	en	37	t	115410778295457737	22	\N	\N	\N	\N	\N	{115410836622615596,115410836631400287,115410836640130215}
115302220743550512	https://10.0.2.2/users/alice/statuses/115302220743550512	Can’t believe how much I’ve learned in just a semester. Grateful for all the growth. 📚 #CollegeJourney #LearningEveryday	2025-10-02 02:31:04.767758	2025-10-02 02:31:04.767758	\N	\N	\N	f	0		f	en	42	t	115445893227871976	24	\N	\N	\N	\N	\N	{}
115433627788463436	https://10.0.2.2/users/test/statuses/115433627788463436	Which country has the largest land area?	2025-10-25 07:29:37.145914	2025-10-25 07:29:37.145914	\N	\N	\N	f	0		f	en	38	t	115338428522805842	23	\N	2	\N	\N	\N	{}
115296559617869861	https://10.0.2.2/users/alice/statuses/115296559617869861	"Midterm week is here 😅 I need a caffeine boost ASAP. Anyone else struggling? #CollegeLife #StudyGrind"	2025-10-01 02:31:22.843555	2025-10-01 02:31:22.843555	\N	\N	\N	f	0		f	en	39	t	115445893227871976	24	\N	\N	\N	\N	\N	{}
115297747807930559	https://10.0.2.2/users/alice/statuses/115297747807930559	"Finally finished that 10-page paper. Rewarding myself with a massive pizza 🍕 Who else is celebrating small victories today? #StudentWins #CollegeStress"	2025-10-01 07:33:33.183007	2025-10-01 07:44:03.020554	\N	\N	\N	f	0		f	en	40	t	115445893227871976	24	\N	\N	\N	2025-10-01 07:44:03.004039	\N	{115297788590177428}
115302217969195468	https://10.0.2.2/users/alice/statuses/115302217969195468	"Feeling so motivated after that lecture on AI. The future really is now! 🤖💡 #TechTalk	2025-10-02 02:30:22.446948	2025-10-02 02:30:22.446948	\N	\N	\N	f	0		f	en	41	t	115445893227871976	24	\N	\N	\N	\N	\N	{}
115307881713558689	https://10.0.2.2/users/alice/statuses/115307881713558689	Random thought: Why do we spend so much time complaining about school, but then miss it during breaks? 🤔 #CollegeLife #Irony	2025-10-03 02:30:44.313256	2025-10-03 02:30:44.313256	\N	\N	\N	f	0		f	en	43	t	115445893227871976	24	\N	\N	\N	\N	\N	{}
115308836977807389	https://10.0.2.2/users/alice/statuses/115308836977807389	Today was one of those days when everything clicked. Got an A on my exam AND had the best lunch ever. Feeling good! 🙌 #GoodVibes #Winning	2025-10-03 06:33:40.486599	2025-10-03 06:33:40.486599	\N	\N	\N	f	0		f	en	44	t	115445893227871976	24	\N	\N	\N	\N	\N	{115308832804318672}
115314485135812197	https://10.0.2.2/users/alice/statuses/115314485135812197	Counting down the days until the weekend. Any good study spots on campus?	2025-10-04 06:30:04.5387	2025-10-04 06:30:04.5387	\N	\N	\N	f	0		f	en	45	t	115445893227871976	24	\N	\N	\N	\N	\N	{}
115319571928036858	https://10.0.2.2/users/alice/statuses/115319571928036858	Can’t believe it’s my birthday today! 🎉 21 years of life and I still don’t know how to adult. Grateful for another year. #BirthdayVibes	2025-10-05 04:03:42.850768	2025-10-05 04:03:42.850768	\N	\N	\N	f	0		f	en	46	t	115445893227871976	24	\N	\N	\N	\N	\N	{115319571613720632,115319571636093130,115319571655011162}
115330883097070218	https://10.0.2.2/users/alice/statuses/115330883097070218	Love how peaceful the campus looks in the fall. Might actually make me late to class though 😅 #NatureBreak	2025-10-07 04:00:17.570832	2025-10-07 04:00:17.570832	\N	\N	\N	f	0		f	en	47	t	115445893227871976	24	\N	\N	\N	\N	\N	{}
115342206980244455	https://10.0.2.2/users/alice/statuses/115342206980244455	Thought I had studied enough for the chem exam… turns out I had no idea what was going on. #Oops #CollegeStruggles	2025-10-09 04:00:06.314923	2025-10-09 04:00:06.314923	\N	\N	\N	f	0		f	en	48	t	115445893227871976	24	\N	\N	\N	\N	\N	{}
115353531426940040	https://10.0.2.2/users/alice/statuses/115353531426940040	That moment when your third coffee hits and you feel unstoppable… until you spill it on your notes. #StudentLife	2025-10-11 04:00:03.660272	2025-10-11 04:00:03.660272	\N	\N	\N	f	0		f	en	49	t	115445893227871976	24	\N	\N	\N	\N	\N	{}
115353533205151985	https://10.0.2.2/users/alice/statuses/115353533205151985	Does anyone else talk to their plants when stressed or is it just me? 🌱 #CollegeWeirdness	2025-10-11 04:00:30.791735	2025-10-11 04:00:30.791735	\N	\N	\N	f	0		f	en	50	t	115445893227871976	24	\N	\N	\N	\N	\N	{}
115383769269972821	https://10.0.2.2/users/openUniversity/statuses/115383769269972821	🎓 Excited to share next week’s #OpenTalk!\nTopic: AI-Powered Urban Mobility\nSpeaker: Dr. Lin Qiao (Associate Professor, Institute of Intelligent Systems)\nDate & Time: Oct 24, 2025 (Mon) 15:00 – 16:30\nVenue: Auditorium 2-A, Innovation Building\n\n🚗💡 With cities facing congestion and sustainability challenges, this talk explores how modern machine learning can transform traffic prediction, fleet optimization, and eco-routing.\n\n#OpenTalk	2025-10-16 12:09:56.528564	2025-10-27 13:37:16.276116	\N	\N	\N	f	0		f	en	24	t	115383709981264049	18	\N	\N	\N	2025-10-27 13:37:16.270607	\N	{}
115308026943576527	https://10.0.2.2/users/olivia/statuses/115308026943576527	I’m excited to share that I’ve recently completed a major milestone at work – we just launched a new project that’s been in the works for months! It's been challenging but incredibly rewarding to see the team's hard work come to life. I'm looking forward to tackling the next big project and continuing to grow in this role. Onward and upward! 💼🚀 #CareerGrowth #ProjectSuccess	2025-10-03 03:07:40.348446	2025-10-03 03:07:40.348446	\N	\N	\N	f	0		f	en	51	t	115347680385540244	29	\N	\N	\N	\N	\N	{}
115308049928142735	https://10.0.2.2/users/kitty/statuses/115308049928142735	Meet the Persian Cat – the ultimate lap companion! With their long, luxurious coats and sweet, gentle temperament, Persians are known for their calm nature. They’re a bit on the quiet side, but that just makes their cuddles even more precious. 😻 #PersianCat #FluffyFriend	2025-10-03 03:13:31.064128	2025-10-03 03:13:31.064128	\N	\N	\N	f	0		f	en	52	t	115347680582977591	30	\N	\N	\N	\N	\N	{115308049647805210}
115308052122327485	https://10.0.2.2/users/kitty/statuses/115308052122327485	Siamese cats are truly unique with their striking blue eyes and sleek, short coats. These vocal kitties love attention and aren't afraid to speak their minds – their "meow" is their signature! If you want a social and playful cat, the Siamese is your perfect match. 🐱💙 #SiameseCat #ChattyKitty	2025-10-03 03:14:04.545666	2025-10-03 03:14:04.545666	\N	\N	\N	f	0		f	en	53	t	115347680582977591	30	\N	\N	\N	\N	\N	{115308052044984137}
115308055215904871	https://10.0.2.2/users/kitty/statuses/115308055215904871	The Maine Coon is not just one of the largest cat breeds; they are also one of the friendliest! With their tufted ears, bushy tails, and outgoing personalities, these gentle giants are known for being loving and playful. Plus, they get along well with kids and other pets! 🐾❤️ #MaineCoon #GentleGiant	2025-10-03 03:14:51.747184	2025-10-03 03:14:51.747184	\N	\N	\N	f	0		f	en	54	t	115347680582977591	30	\N	\N	\N	\N	\N	{115308055136052802}
115308073936777032	https://10.0.2.2/users/gourmet/statuses/115308073936777032	Ah, Italy – where food is an art form. 🍕 The classic Pizza Margherita is the epitome of simplicity and perfection. Fresh basil, mozzarella, and tomatoes on a crispy thin crust – it doesn’t get better than this! Pair it with a glass of Chianti, and you're in heaven. 🇮🇹 #PizzaMargherita #ItalianCuisine #FoodPerfection	2025-10-03 03:19:37.405603	2025-10-03 03:19:37.405603	\N	\N	\N	f	0		f	en	55	t	115347680754305497	32	\N	\N	\N	\N	\N	{115308073851626368}
115308075855485062	https://10.0.2.2/users/gourmet/statuses/115308075855485062	Sushi in Japan is not just a meal; it’s an experience. 🍣 From the delicate nigiri to the bold maki rolls, every bite is a burst of fresh flavor. I’ll always have a soft spot for traditional tuna and salmon – the perfect balance of fish and rice. 🍚 #SushiLover #JapaneseCuisine #FreshAndDelicious	2025-10-03 03:20:06.682419	2025-10-03 03:20:06.682419	\N	\N	\N	f	0		f	en	56	t	115347680754305497	32	\N	\N	\N	\N	\N	{115308075481948251}
115308077295869622	https://10.0.2.2/users/gourmet/statuses/115308077295869622	Tacos – the quintessential Mexican street food. 🌮 Whether filled with tender carne asada, slow-cooked carnitas, or crispy fish, these handheld delights are packed with flavor! Don’t forget the salsa, cilantro, and lime for that perfect bite. 🌶️ #TacoTime #MexicanFood #FlavorExplosion	2025-10-03 03:20:28.661011	2025-10-03 03:20:28.661011	\N	\N	\N	f	0		f	en	57	t	115347680754305497	32	\N	\N	\N	\N	\N	{115308077121034110}
115325929067286527	https://10.0.2.2/users/gourmet/statuses/115325929067286527	Butter Chicken, also known as Murgh Makhani, is a creamy, savory dream. 🍛 The chicken is marinated to perfection, then cooked in a rich tomato gravy with aromatic spices and a generous dollop of butter. Serve it with some fluffy naan bread, and you’re in for a treat! 🍗 #ButterChicken #IndianCuisine #SpiceLover	2025-10-06 07:00:25.074943	2025-10-06 07:00:25.074943	\N	\N	\N	f	0		f	en	58	t	115347680754305497	32	\N	\N	\N	\N	\N	{}
115325930808153244	https://10.0.2.2/users/gourmet/statuses/115325930808153244	Pad Thai – the perfect balance of sweet, sour, salty, and savory. 🍜 Stir-fried noodles with shrimp, peanuts, eggs, and a zesty lime finish – every bite is a celebration of Thai flavors. Can’t go wrong with this classic street food. 🌶️ #PadThai #ThaiCuisine #StreetFood	2025-10-06 07:00:51.639734	2025-10-06 07:00:51.639734	\N	\N	\N	f	0		f	en	59	t	115347680754305497	32	\N	\N	\N	\N	\N	{115325930719635226}
115325932408442041	https://10.0.2.2/users/gourmet/statuses/115325932408442041	Nothing says "Parisian breakfast" like a flaky, buttery croissant. 🥐 Freshly baked, crispy on the outside and soft on the inside, it's the kind of pastry you savor with your morning coffee. Perfect with a touch of jam or simply enjoyed on its own. 🇫🇷 #Croissant #FrenchPastry #BreakfastDelight	2025-10-06 07:01:16.05889	2025-10-06 07:01:16.05889	\N	\N	\N	f	0		f	en	60	t	115347680754305497	32	\N	\N	\N	\N	\N	{115325932212881428}
115325935124985356	https://10.0.2.2/users/kitty/statuses/115325935124985356	If you love cuddles, the Ragdoll cat is your dream cat! Known for their docile and affectionate nature, Ragdolls are incredibly laid-back. They’ll literally go limp in your arms, hence the name “Ragdoll.” They’re perfect for anyone looking for a snuggly companion. 😺💤 #RagdollCat #CuddleBuddy	2025-10-06 07:01:57.508911	2025-10-06 07:01:57.508911	\N	\N	\N	f	0		f	en	61	t	115347680582977591	31	\N	\N	\N	\N	\N	{115325935043482800}
115325936733960590	https://10.0.2.2/users/kitty/statuses/115325936733960590	With their stunning spotted coats and wild look, Bengal cats are a unique breed. They’re energetic, intelligent, and love to explore their surroundings. If you have an active lifestyle, a Bengal will keep up with you – they love to play and learn new tricks! 🐆 #BengalCat #WildAtHeart	2025-10-06 07:02:22.060436	2025-10-06 07:02:22.060436	\N	\N	\N	f	0		f	en	62	t	115347680582977591	31	\N	\N	\N	\N	\N	{115325936633561364}
115325938770523080	https://10.0.2.2/users/kitty/statuses/115325938770523080	The British Shorthair, with its round face and thick, plush coat, is a calm, easy-going companion. These cats are great for those who appreciate a more independent feline friend. They enjoy your company but aren’t overly demanding of attention. 🐾✨ #BritishShorthair #ChillCat	2025-10-06 07:02:53.136841	2025-10-06 07:02:53.136841	\N	\N	\N	f	0		f	en	63	t	115347680582977591	31	\N	\N	\N	\N	\N	{115325938618326427}
115325940405933880	https://10.0.2.2/users/olivia/statuses/115325940405933880	Feeling inspired and ready for new challenges at work! The recent success of our team has motivated me to aim higher. Whether it's leading new initiatives or tackling more complex problems, I'm eager to step up and push my boundaries. Here's to continued growth and taking on new responsibilities! #NewGoals #CareerDevelopment	2025-10-06 07:03:18.088652	2025-10-06 07:03:18.088652	\N	\N	\N	f	0		f	en	64	t	115347680385540244	29	\N	\N	\N	\N	\N	{}
115342681979737543	https://10.0.2.2/users/gourmet/statuses/115342681979737543	Moussaka – the Greek version of comfort food. 🍽️ Layers of tender eggplant, spiced ground beef, and a creamy béchamel sauce make this dish a hearty, satisfying meal. Every bite feels like a warm hug. 🍆 #Moussaka #GreekCuisine #ComfortFood	2025-10-09 06:00:54.232352	2025-10-09 06:00:54.232352	\N	\N	\N	f	0		f	en	66	t	115347680754305497	32	\N	\N	\N	\N	\N	{115342681848384912}
115342679183802668	https://10.0.2.2/users/olivia/statuses/115342679183802668	Reflecting on my journey at work so far – it’s been a fulfilling ride with lots of learning and growth. One of the proudest moments has been seeing my team thrive and deliver on key projects. But now, I’m looking for something new to keep me on my toes. Ready to embrace new challenges and make an even bigger impact in the coming months! #LookingAhead #ProfessionalGrowth	2025-10-09 06:00:11.570006	2025-10-09 06:00:11.570006	\N	\N	\N	f	0		f	en	65	t	115347680385540244	29	\N	\N	\N	\N	\N	{}
115342685859632441	https://10.0.2.2/users/gourmet/statuses/115342685859632441	Paella – a flavorful rice dish from the heart of Spain. 🍤🍚 Packed with seafood, saffron, and a variety of meats, this dish is as vibrant as it is delicious. Whether you enjoy seafood or a mixed version with chicken and rabbit, it's a perfect meal for sharing. 🇪🇸 #Paella #SpanishCuisine #FlavorBurst	2025-10-09 06:01:53.435113	2025-10-09 06:01:53.435113	\N	\N	\N	f	0		f	en	68	t	115347680754305497	32	\N	\N	\N	\N	\N	{115342685782967789}
115342688336777048	https://10.0.2.2/users/kitty/statuses/115342688336777048	The Sphynx cat is famous for being hairless, but don’t let their lack of fur fool you – they’re full of personality! These cats are playful, affectionate, and love attention. If you want a cat that will cuddle with you all day, the Sphynx is a great choice. 🖤 #SphynxCat #BoldAndBeautiful	2025-10-09 06:02:31.23526	2025-10-09 06:02:31.23526	\N	\N	\N	f	0		f	en	69	t	115347680582977591	31	\N	\N	\N	\N	\N	{115342688241294115}
115342691128783945	https://10.0.2.2/users/kitty/statuses/115342691128783945	Those signature folded ears give the Scottish Fold an unmistakable look. They are calm, affectionate, and enjoy being around their humans. If you're looking for a cute and loving companion, this breed's sweet and soft nature will win you over. 🐱💖 #ScottishFold #CuteCat	2025-10-09 06:03:13.835557	2025-10-09 06:03:13.835557	\N	\N	\N	f	0		f	en	70	t	115347680582977591	31	\N	\N	\N	\N	\N	{115342691058981547}
115359674190777168	https://10.0.2.2/users/gourmet/statuses/115359674190777168	Peking Duck – a Chinese delicacy that never disappoints. 🦆 Crispy skin, tender meat, and served with pancakes, hoisin sauce, and fresh scallions – it’s a feast for the senses. Every bite is a perfect combination of savory, sweet, and smoky. 🍽️ #PekingDuck #ChineseCuisine #FoodGoals	2025-10-12 06:02:14.797072	2025-10-12 06:02:14.797072	\N	\N	\N	f	0		f	en	73	t	115347680754305497	32	\N	\N	\N	\N	\N	{115359673243901586,115359673257944538}
115342683847008004	https://10.0.2.2/users/gourmet/statuses/115342683847008004	Hummus – the creamy, smooth dip that’s a staple in Lebanese cuisine. 🧆 Made from pureed chickpeas, tahini, garlic, and lemon juice, it’s the perfect spread for pita or veggies. Simple, yet oh-so-delicious! 🇱🇧 #Hummus #LebaneseCuisine #HealthyEats	2025-10-09 06:01:22.727843	2025-10-09 06:01:22.727843	\N	\N	\N	f	0		f	en	67	t	115347680754305497	32	\N	\N	\N	\N	\N	{115342683753382629}
115359676029383172	https://10.0.2.2/users/olivia/statuses/115359676029383172	Big news – I’ve officially made a career change! I’ve accepted a new role that excites me and aligns with my long-term goals. As part of this transition, I have a new phone number: (555) 123-4567 and a new work email: olivia@gmail.com\n. Looking forward to this new chapter and the opportunities ahead! #NewBeginnings #CareerTransition	2025-10-12 06:02:42.851411	2025-10-12 06:02:42.851411	\N	\N	\N	f	0		f	en	74	t	115347680385540244	29	\N	\N	\N	\N	\N	{}
115359670141158913	https://10.0.2.2/users/kitty/statuses/115359670141158913	Looking for a Persian but with less grooming? The Exotic Shorthair is the perfect match! They have the same sweet, affectionate personality as the Persian but with a short, manageable coat. These cats are calm, loving, and make wonderful companions. 😽 #ExoticShorthair #EasyCare #cats	2025-10-12 06:01:13.004231	2025-10-12 06:06:48.489985	\N	\N	\N	f	0		f	en	72	t	115347680582977591	31	\N	\N	\N	2025-10-12 06:06:48.488338	\N	{}
115342692663348018	https://10.0.2.2/users/kitty/statuses/115342692663348018	The Abyssinian is one of the most active cat breeds! Their sleek, ticked coat and agile nature make them excellent climbers and explorers. These cats are highly intelligent and love to interact with their humans, always keeping you on your toes with their playful antics. 🐾💨 #AbyssinianCat #EnergeticCat #cats	2025-10-09 06:03:37.253356	2025-10-12 06:06:59.88286	\N	\N	\N	f	0		f	en	71	t	115347680582977591	31	\N	\N	\N	2025-10-12 06:06:59.881974	\N	{115342692590126513}
115378662120962265	https://10.0.2.2/users/test/statuses/115378662120962265	HOW beautiful it is!!!	2025-10-15 14:31:07.618809	2025-10-15 14:31:07.618809	\N	\N	\N	f	0		f	en	84	t	115338428522805842	61	\N	\N	\N	\N	\N	{115378658256750739}
115378670262150858	https://10.0.2.2/users/jack/statuses/115378670262150858	这是我今年在淘店上购买的最划算的商品，这个鞋子穿起来非常舒服,性价比很高，我非常喜欢。\n我推荐给大家购买，想要跟我买同款的小伙伴可以直接搜索休闲鞋, 是图片中展示的这款,别买错了	2025-10-15 14:33:11.842463	2025-10-15 14:33:11.842463	\N	\N	\N	f	0		f	en	85	t	115407279554762986	63	\N	\N	\N	\N	\N	{115378670173986245}
115305055209559170	https://10.0.2.2/users/openCompany/statuses/115305055209559170	IT Maintenance Notice\n\nWe will be performing a scheduled system upgrade this Saturday from 00:00 to 04:00. During this time, the collaboration platform and SSO login may be temporarily unavailable. Please plan your work accordingly. Thanks for your understanding.	2025-10-02 14:31:55.282718	2025-10-02 14:31:55.282718	\N	\N	\N	f	0		f	en	86	t	115378678396852544	65	\N	\N	\N	\N	\N	{}
115305056394168901	https://10.0.2.2/users/openCompany/statuses/115305056394168901	New Feature Release\n\nOur latest update is now live! This version introduces Dark Mode and batch file uploads, along with several performance improvements. Feel free to try it out and share your feedback with us.	2025-10-02 14:32:13.35848	2025-10-02 14:32:13.35848	\N	\N	\N	f	0		f	en	87	t	115378678396852544	65	\N	\N	\N	\N	\N	{}
115316372893382635	https://10.0.2.2/users/openCompany/statuses/115316372893382635	Temporary Network Outage\n\nWe’re currently experiencing network instability due to a data center issue, which may cause temporary service interruptions. Our team is actively working on recovery. Sorry for any inconvenience caused.	2025-10-04 14:30:09.432754	2025-10-04 14:30:09.432754	\N	\N	\N	f	0		f	en	88	t	115378678396852544	65	\N	\N	\N	\N	\N	{}
115316373540597242	https://10.0.2.2/users/openCompany/statuses/115316373540597242	Security Advisory\n\nA series of phishing emails have been reported recently. Please avoid clicking unknown links or attachments. If you receive a suspicious message, contact the IT security team immediately.	2025-10-04 14:30:19.309843	2025-10-04 14:30:19.309843	\N	\N	\N	f	0		f	en	89	t	115378678396852544	65	\N	\N	\N	\N	\N	{}
115327697414001493	https://10.0.2.2/users/openCompany/statuses/115327697414001493	Office Power Interruption\n\nThere will be a brief power outage in the East Office Area tomorrow from 9:00 to 10:00 AM due to building maintenance. Please save your work in advance and shut down your devices if necessary.	2025-10-06 14:30:07.903899	2025-10-06 14:30:07.903899	\N	\N	\N	f	0		f	en	90	t	115378678396852544	65	\N	\N	\N	\N	\N	{}
115327698341433387	https://10.0.2.2/users/openCompany/statuses/115327698341433387	Service Migration Update\n\nWe are migrating our storage service to a new cluster this afternoon. Uploading files may be slower or temporarily affected until the migration is complete. Thank you for your patience.	2025-10-06 14:30:22.055095	2025-10-06 14:30:22.055095	\N	\N	\N	f	0		f	en	91	t	115378678396852544	65	\N	\N	\N	\N	\N	{}
115344684578144697	https://10.0.2.2/users/openCompany/statuses/115344684578144697	Pricing Adjustment Notice\n\nDue to changes in operational costs, several premium features will undergo a price adjustment starting next month. We will share the full details soon to help you prepare.	2025-10-09 14:30:11.458458	2025-10-09 14:30:11.458458	\N	\N	\N	f	0		f	en	92	t	115378678396852544	65	\N	\N	\N	\N	\N	{}
115367333849715879	https://10.0.2.2/users/openCompany/statuses/115367333849715879	Team Announcement\n\nStarting today, Alice will take on the role of Head of Product, overseeing product strategy and delivery. Please join us in welcoming her to the new position and supporting her work.	2025-10-13 14:30:11.915325	2025-10-13 14:30:11.915325	\N	\N	\N	f	0		f	en	93	t	115378678396852544	65	\N	\N	\N	\N	\N	{}
115378660925180041	https://10.0.2.2/users/openCompany/statuses/115378660925180041	🏃‍♂️ Company Sports Day Announcement\n\nWe’re excited to announce that our annual Company Sports Day will take place on October 22, 2025, from 9:00 AM to 5:00 PM at the City Sports Center Stadium.\n\nThis year’s theme is “Stronger Together”, highlighting teamwork, health, and community spirit. The event will include a variety of activities such as relay races, basketball games, fun team challenges, and an open fitness session.\n\nAll employees are welcome to join!	2025-10-15 14:30:49.371328	2025-10-15 14:30:49.371328	\N	\N	\N	f	0		f	en	94	t	115378678396852544	65	\N	\N	\N	\N	\N	{}
\.


--
-- Data for Name: statuses_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.statuses_tags (status_id, tag_id) FROM stdin;
115348102480027134	1
115383769269972821	2
115383802106899661	2
115383849716842309	2
115383884712317564	2
115383987272402574	2
115384014916118822	2
115410810887077411	1
115410810887077411	3
115410813905484454	4
115410813905484454	3
115410813905484454	1
115410818912936581	5
115410818912936581	4
115410818912936581	1
115410836820181445	3
115410836820181445	1
115410836820181445	4
115410836820181445	6
115296559617869861	7
115296559617869861	8
115297747807930559	9
115297747807930559	10
115302217969195468	11
115302220743550512	12
115302220743550512	13
115307881713558689	7
115307881713558689	14
115308836977807389	15
115308836977807389	16
115319571928036858	17
115330883097070218	18
115342206980244455	19
115342206980244455	20
115353531426940040	21
115353533205151985	22
115308026943576527	23
115308026943576527	24
115308049928142735	25
115308049928142735	26
115308052122327485	27
115308052122327485	28
115308055215904871	29
115308055215904871	30
115308073936777032	31
115308073936777032	32
115308073936777032	33
115308075855485062	34
115308075855485062	35
115308075855485062	36
115308077295869622	37
115308077295869622	38
115308077295869622	39
115325929067286527	40
115325929067286527	41
115325929067286527	42
115325930808153244	43
115325930808153244	44
115325930808153244	45
115325932408442041	46
115325932408442041	47
115325932408442041	48
115325935124985356	49
115325935124985356	50
115325936733960590	51
115325936733960590	52
115325938770523080	53
115325938770523080	54
115325940405933880	55
115325940405933880	56
115342679183802668	57
115342679183802668	58
115342681979737543	59
115342681979737543	60
115342681979737543	61
115342683847008004	62
115342683847008004	63
115342683847008004	64
115342685859632441	65
115342685859632441	66
115342685859632441	67
115342688336777048	68
115342688336777048	69
115342691128783945	70
115342691128783945	71
115342692663348018	72
115342692663348018	73
115359670141158913	74
115359670141158913	75
115359674190777168	76
115359674190777168	77
115359674190777168	78
115359676029383172	79
115359676029383172	80
115359670141158913	81
115342692663348018	81
\.


--
-- Data for Name: tag_follows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tag_follows (id, tag_id, account_id, created_at, updated_at) FROM stdin;
3	1	115338428522805842	2025-10-12 06:03:35.41609	2025-10-12 06:03:35.41609
4	24	115338428522805842	2025-10-12 06:05:19.791992	2025-10-12 06:05:19.791992
5	58	115338428522805842	2025-10-12 06:05:22.899075	2025-10-12 06:05:22.899075
6	57	115338428522805842	2025-10-12 06:05:31.606953	2025-10-12 06:05:31.606953
7	55	115338428522805842	2025-10-12 06:05:38.925481	2025-10-12 06:05:38.925481
8	79	115338428522805842	2025-10-12 06:05:41.608519	2025-10-12 06:05:41.608519
9	23	115338428522805842	2025-10-12 06:05:51.608449	2025-10-12 06:05:51.608449
10	80	115338428522805842	2025-10-12 06:05:53.524491	2025-10-12 06:05:53.524491
11	78	115338428522805842	2025-10-12 06:07:51.161534	2025-10-12 06:07:51.161534
12	33	115338428522805842	2025-10-12 06:07:54.491103	2025-10-12 06:07:54.491103
13	67	115338428522805842	2025-10-12 06:08:16.191919	2025-10-12 06:08:16.191919
14	81	115338428522805842	2025-10-12 06:08:21.4252	2025-10-12 06:08:21.4252
15	77	115338428522805842	2025-10-12 06:08:35.907392	2025-10-12 06:08:35.907392
16	62	115338428522805842	2025-10-12 06:08:48.140357	2025-10-12 06:08:48.140357
36	89	115378678396852544	2025-10-15 14:31:10.336643	2025-10-15 14:31:10.336643
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tags (id, name, created_at, updated_at, usable, trendable, listable, reviewed_at, requested_review_at, last_status_at, max_score, max_score_at, display_name) FROM stdin;
1	dogs	2025-10-10 04:59:25.120233	2025-10-10 04:59:25.120233	\N	\N	\N	\N	\N	\N	\N	\N	dogs
2	opentalk	2025-10-16 12:09:56.588393	2025-10-16 12:09:56.588393	\N	\N	\N	\N	\N	\N	\N	\N	OpenTalk
3	puppy	2025-10-21 06:46:58.928466	2025-10-21 06:46:58.928466	\N	\N	\N	\N	\N	\N	\N	\N	puppy
4	pets	2025-10-21 06:47:44.996459	2025-10-21 06:47:44.996459	\N	\N	\N	\N	\N	\N	\N	\N	pets
5	lovely	2025-10-21 06:49:01.422712	2025-10-21 06:49:01.422712	\N	\N	\N	\N	\N	\N	\N	\N	lovely
6	cute	2025-10-21 06:53:34.620434	2025-10-21 06:53:34.620434	\N	\N	\N	\N	\N	\N	\N	\N	cute
7	collegelife	2025-10-01 02:31:22.978987	2025-10-01 02:31:22.978987	\N	\N	\N	\N	\N	\N	\N	\N	CollegeLife
8	studygrind	2025-10-01 02:31:22.998952	2025-10-01 02:31:22.998952	\N	\N	\N	\N	\N	\N	\N	\N	StudyGrind
9	studentwins	2025-10-01 07:33:33.659254	2025-10-01 07:33:33.659254	\N	\N	\N	\N	\N	\N	\N	\N	StudentWins
10	collegestress	2025-10-01 07:33:33.687683	2025-10-01 07:33:33.687683	\N	\N	\N	\N	\N	\N	\N	\N	CollegeStress
11	techtalk	2025-10-02 02:30:23.462165	2025-10-02 02:30:23.462165	\N	\N	\N	\N	\N	\N	\N	\N	TechTalk
12	collegejourney	2025-10-02 02:31:05.834496	2025-10-02 02:31:05.834496	\N	\N	\N	\N	\N	\N	\N	\N	CollegeJourney
13	learningeveryday	2025-10-02 02:31:05.940875	2025-10-02 02:31:05.940875	\N	\N	\N	\N	\N	\N	\N	\N	LearningEveryday
14	irony	2025-10-03 02:30:44.377771	2025-10-03 02:30:44.377771	\N	\N	\N	\N	\N	\N	\N	\N	Irony
15	goodvibes	2025-10-03 06:33:40.544425	2025-10-03 06:33:40.544425	\N	\N	\N	\N	\N	\N	\N	\N	GoodVibes
16	winning	2025-10-03 06:33:40.556336	2025-10-03 06:33:40.556336	\N	\N	\N	\N	\N	\N	\N	\N	Winning
17	birthdayvibes	2025-10-05 04:03:42.955795	2025-10-05 04:03:42.955795	\N	\N	\N	\N	\N	\N	\N	\N	BirthdayVibes
18	naturebreak	2025-10-07 04:00:19.00027	2025-10-07 04:00:19.00027	\N	\N	\N	\N	\N	\N	\N	\N	NatureBreak
19	oops	2025-10-09 04:00:07.171528	2025-10-09 04:00:07.171528	\N	\N	\N	\N	\N	\N	\N	\N	Oops
20	collegestruggles	2025-10-09 04:00:07.315788	2025-10-09 04:00:07.315788	\N	\N	\N	\N	\N	\N	\N	\N	CollegeStruggles
21	studentlife	2025-10-11 04:00:04.760282	2025-10-11 04:00:04.760282	\N	\N	\N	\N	\N	\N	\N	\N	StudentLife
22	collegeweirdness	2025-10-11 04:00:30.968009	2025-10-11 04:00:30.968009	\N	\N	\N	\N	\N	\N	\N	\N	CollegeWeirdness
23	careergrowth	2025-10-03 03:07:40.484921	2025-10-03 03:07:40.484921	\N	\N	\N	\N	\N	\N	\N	\N	CareerGrowth
24	projectsuccess	2025-10-03 03:07:40.506307	2025-10-03 03:07:40.506307	\N	\N	\N	\N	\N	\N	\N	\N	ProjectSuccess
25	persiancat	2025-10-03 03:13:31.118791	2025-10-03 03:13:31.118791	\N	\N	\N	\N	\N	\N	\N	\N	PersianCat
26	fluffyfriend	2025-10-03 03:13:31.132835	2025-10-03 03:13:31.132835	\N	\N	\N	\N	\N	\N	\N	\N	FluffyFriend
27	siamesecat	2025-10-03 03:14:04.623197	2025-10-03 03:14:04.623197	\N	\N	\N	\N	\N	\N	\N	\N	SiameseCat
28	chattykitty	2025-10-03 03:14:04.643806	2025-10-03 03:14:04.643806	\N	\N	\N	\N	\N	\N	\N	\N	ChattyKitty
29	mainecoon	2025-10-03 03:14:51.804905	2025-10-03 03:14:51.804905	\N	\N	\N	\N	\N	\N	\N	\N	MaineCoon
30	gentlegiant	2025-10-03 03:14:51.81585	2025-10-03 03:14:51.81585	\N	\N	\N	\N	\N	\N	\N	\N	GentleGiant
31	pizzamargherita	2025-10-03 03:19:37.462127	2025-10-03 03:19:37.462127	\N	\N	\N	\N	\N	\N	\N	\N	PizzaMargherita
32	italiancuisine	2025-10-03 03:19:37.475291	2025-10-03 03:19:37.475291	\N	\N	\N	\N	\N	\N	\N	\N	ItalianCuisine
33	foodperfection	2025-10-03 03:19:37.490292	2025-10-03 03:19:37.490292	\N	\N	\N	\N	\N	\N	\N	\N	FoodPerfection
34	sushilover	2025-10-03 03:20:07.625199	2025-10-03 03:20:07.625199	\N	\N	\N	\N	\N	\N	\N	\N	SushiLover
35	japanesecuisine	2025-10-03 03:20:07.637707	2025-10-03 03:20:07.637707	\N	\N	\N	\N	\N	\N	\N	\N	JapaneseCuisine
36	freshanddelicious	2025-10-03 03:20:07.652944	2025-10-03 03:20:07.652944	\N	\N	\N	\N	\N	\N	\N	\N	FreshAndDelicious
37	tacotime	2025-10-03 03:20:29.843366	2025-10-03 03:20:29.843366	\N	\N	\N	\N	\N	\N	\N	\N	TacoTime
38	mexicanfood	2025-10-03 03:20:30.083917	2025-10-03 03:20:30.083917	\N	\N	\N	\N	\N	\N	\N	\N	MexicanFood
39	flavorexplosion	2025-10-03 03:20:30.384332	2025-10-03 03:20:30.384332	\N	\N	\N	\N	\N	\N	\N	\N	FlavorExplosion
40	butterchicken	2025-10-06 07:00:25.144677	2025-10-06 07:00:25.144677	\N	\N	\N	\N	\N	\N	\N	\N	ButterChicken
41	indiancuisine	2025-10-06 07:00:25.156728	2025-10-06 07:00:25.156728	\N	\N	\N	\N	\N	\N	\N	\N	IndianCuisine
42	spicelover	2025-10-06 07:00:25.171227	2025-10-06 07:00:25.171227	\N	\N	\N	\N	\N	\N	\N	\N	SpiceLover
43	padthai	2025-10-06 07:00:51.731896	2025-10-06 07:00:51.731896	\N	\N	\N	\N	\N	\N	\N	\N	PadThai
44	thaicuisine	2025-10-06 07:00:51.767773	2025-10-06 07:00:51.767773	\N	\N	\N	\N	\N	\N	\N	\N	ThaiCuisine
45	streetfood	2025-10-06 07:00:51.816005	2025-10-06 07:00:51.816005	\N	\N	\N	\N	\N	\N	\N	\N	StreetFood
46	croissant	2025-10-06 07:01:17.02297	2025-10-06 07:01:17.02297	\N	\N	\N	\N	\N	\N	\N	\N	Croissant
47	frenchpastry	2025-10-06 07:01:17.035915	2025-10-06 07:01:17.035915	\N	\N	\N	\N	\N	\N	\N	\N	FrenchPastry
48	breakfastdelight	2025-10-06 07:01:17.051013	2025-10-06 07:01:17.051013	\N	\N	\N	\N	\N	\N	\N	\N	BreakfastDelight
49	ragdollcat	2025-10-06 07:01:57.992789	2025-10-06 07:01:57.992789	\N	\N	\N	\N	\N	\N	\N	\N	RagdollCat
50	cuddlebuddy	2025-10-06 07:01:58.00772	2025-10-06 07:01:58.00772	\N	\N	\N	\N	\N	\N	\N	\N	CuddleBuddy
51	bengalcat	2025-10-06 07:02:22.607102	2025-10-06 07:02:22.607102	\N	\N	\N	\N	\N	\N	\N	\N	BengalCat
52	wildatheart	2025-10-06 07:02:22.622284	2025-10-06 07:02:22.622284	\N	\N	\N	\N	\N	\N	\N	\N	WildAtHeart
53	britishshorthair	2025-10-06 07:02:53.183916	2025-10-06 07:02:53.183916	\N	\N	\N	\N	\N	\N	\N	\N	BritishShorthair
54	chillcat	2025-10-06 07:02:53.198624	2025-10-06 07:02:53.198624	\N	\N	\N	\N	\N	\N	\N	\N	ChillCat
55	newgoals	2025-10-06 07:03:18.14308	2025-10-06 07:03:18.14308	\N	\N	\N	\N	\N	\N	\N	\N	NewGoals
56	careerdevelopment	2025-10-06 07:03:18.165404	2025-10-06 07:03:18.165404	\N	\N	\N	\N	\N	\N	\N	\N	CareerDevelopment
57	lookingahead	2025-10-09 06:00:11.621288	2025-10-09 06:00:11.621288	\N	\N	\N	\N	\N	\N	\N	\N	LookingAhead
58	professionalgrowth	2025-10-09 06:00:11.63674	2025-10-09 06:00:11.63674	\N	\N	\N	\N	\N	\N	\N	\N	ProfessionalGrowth
59	moussaka	2025-10-09 06:00:54.283225	2025-10-09 06:00:54.283225	\N	\N	\N	\N	\N	\N	\N	\N	Moussaka
60	greekcuisine	2025-10-09 06:00:54.295481	2025-10-09 06:00:54.295481	\N	\N	\N	\N	\N	\N	\N	\N	GreekCuisine
61	comfortfood	2025-10-09 06:00:54.310934	2025-10-09 06:00:54.310934	\N	\N	\N	\N	\N	\N	\N	\N	ComfortFood
62	hummus	2025-10-09 06:01:23.186367	2025-10-09 06:01:23.186367	\N	\N	\N	\N	\N	\N	\N	\N	Hummus
63	lebanesecuisine	2025-10-09 06:01:23.200485	2025-10-09 06:01:23.200485	\N	\N	\N	\N	\N	\N	\N	\N	LebaneseCuisine
64	healthyeats	2025-10-09 06:01:23.216547	2025-10-09 06:01:23.216547	\N	\N	\N	\N	\N	\N	\N	\N	HealthyEats
65	paella	2025-10-09 06:01:53.484448	2025-10-09 06:01:53.484448	\N	\N	\N	\N	\N	\N	\N	\N	Paella
66	spanishcuisine	2025-10-09 06:01:53.498139	2025-10-09 06:01:53.498139	\N	\N	\N	\N	\N	\N	\N	\N	SpanishCuisine
67	flavorburst	2025-10-09 06:01:53.51243	2025-10-09 06:01:53.51243	\N	\N	\N	\N	\N	\N	\N	\N	FlavorBurst
68	sphynxcat	2025-10-09 06:02:31.290747	2025-10-09 06:02:31.290747	\N	\N	\N	\N	\N	\N	\N	\N	SphynxCat
69	boldandbeautiful	2025-10-09 06:02:31.311449	2025-10-09 06:02:31.311449	\N	\N	\N	\N	\N	\N	\N	\N	BoldAndBeautiful
70	scottishfold	2025-10-09 06:03:13.888674	2025-10-09 06:03:13.888674	\N	\N	\N	\N	\N	\N	\N	\N	ScottishFold
71	cutecat	2025-10-09 06:03:13.910191	2025-10-09 06:03:13.910191	\N	\N	\N	\N	\N	\N	\N	\N	CuteCat
72	abyssiniancat	2025-10-09 06:03:38.291875	2025-10-09 06:03:38.291875	\N	\N	\N	\N	\N	\N	\N	\N	AbyssinianCat
73	energeticcat	2025-10-09 06:03:38.416327	2025-10-09 06:03:38.416327	\N	\N	\N	\N	\N	\N	\N	\N	EnergeticCat
74	exoticshorthair	2025-10-12 06:01:13.05556	2025-10-12 06:01:13.05556	\N	\N	\N	\N	\N	\N	\N	\N	ExoticShorthair
75	easycare	2025-10-12 06:01:13.070558	2025-10-12 06:01:13.070558	\N	\N	\N	\N	\N	\N	\N	\N	EasyCare
76	pekingduck	2025-10-12 06:02:14.848981	2025-10-12 06:02:14.848981	\N	\N	\N	\N	\N	\N	\N	\N	PekingDuck
77	chinesecuisine	2025-10-12 06:02:14.86071	2025-10-12 06:02:14.86071	\N	\N	\N	\N	\N	\N	\N	\N	ChineseCuisine
78	foodgoals	2025-10-12 06:02:14.877984	2025-10-12 06:02:14.877984	\N	\N	\N	\N	\N	\N	\N	\N	FoodGoals
79	newbeginnings	2025-10-12 06:02:43.251518	2025-10-12 06:02:43.251518	\N	\N	\N	\N	\N	\N	\N	\N	NewBeginnings
80	careertransition	2025-10-12 06:02:43.386174	2025-10-12 06:02:43.386174	\N	\N	\N	\N	\N	\N	\N	\N	CareerTransition
81	cats	2025-10-12 06:06:48.508303	2025-10-12 06:06:48.508303	\N	\N	\N	\N	\N	\N	\N	\N	cats
89	test	2025-10-15 14:31:10.334799	2025-10-15 14:31:10.334799	\N	\N	\N	\N	\N	\N	\N	\N	test
\.


--
-- Data for Name: tombstones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tombstones (id, account_id, uri, created_at, updated_at, by_moderator) FROM stdin;
\.


--
-- Data for Name: unavailable_domains; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.unavailable_domains (id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_invite_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_invite_requests (id, user_id, text, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles (id, name, color, "position", permissions, highlighted, created_at, updated_at) FROM stdin;
-99			-1	65536	f	2025-10-08 11:57:25.016816	2025-10-08 11:57:25.016816
1	Moderator		10	1308	t	2025-10-08 11:57:25.195273	2025-10-08 11:57:25.195273
2	Admin		100	983036	t	2025-10-08 11:57:25.228197	2025-10-08 11:57:25.228197
3	Owner		1000	1	t	2025-10-08 11:57:25.270679	2025-10-08 11:57:25.270679
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, created_at, updated_at, encrypted_password, reset_password_token, reset_password_sent_at, sign_in_count, current_sign_in_at, last_sign_in_at, confirmation_token, confirmed_at, confirmation_sent_at, unconfirmed_email, locale, encrypted_otp_secret, encrypted_otp_secret_iv, encrypted_otp_secret_salt, consumed_timestep, otp_required_for_login, last_emailed_at, otp_backup_codes, account_id, disabled, invite_id, chosen_languages, created_by_application_id, approved, sign_in_token, sign_in_token_sent_at, webauthn_id, sign_up_ip, skip_sign_in_token, role_id, settings, time_zone, otp_secret) FROM stdin;
2	demo@gmail.com	2025-10-08 11:59:08.71742	2025-10-10 04:48:05.174063	$2a$10$xcedQHWis6tZPE69ufAiIel/qIAmwUheKCYay/wMXZAMiDhhyYZS6	\N	\N	3	2025-10-10 04:48:05.173384	2025-10-08 14:20:18.79106	\N	2025-10-08 11:59:09.168978	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	115338428325536028	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	{}	\N	\N
5	frank@gmail.com	2025-10-16 11:38:47.872024	2025-10-16 11:41:51.333965	$2a$10$hjx.Ibc8JybZLjOq74yaSOotPUvxUxdlLKQfoiSVXSSmEmcYUHUpa	\N	\N	1	2025-10-16 11:41:51.331145	2025-10-16 11:41:51.331145	\N	2025-10-16 11:38:47.923584	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	115383646696917550	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	{}	\N	\N
7	alex@gmail.com	2025-10-20 15:48:47.902022	2025-10-20 15:48:49.40228	$2a$10$RvUp12gbWO.D/cDybF7VYOL7Es1d19ARD/eWpZ2LrOapluMVMrf9y	\N	\N	0	\N	\N	\N	2025-10-20 15:48:47.961209	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	115407279078399620	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	{}	\N	\N
8	emma@gmail.com	2025-10-20 15:48:51.830947	2025-10-20 15:48:52.727801	$2a$10$iAN46wG8p7HNoQ2TWb9ux.ge.ANOAovHkOQZKs7fasMxUPOL2q1CS	\N	\N	0	\N	\N	\N	2025-10-20 15:48:51.86985	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	115407279337451464	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	{}	\N	\N
10	rb123@gmail.com	2025-10-20 15:48:57.657001	2025-10-20 15:48:58.199599	$2a$10$6A1ndQrbj1E/IqQZ/BUGOur1gQcqjhwSx7z1uhP8PR.zq4Z7geZQK	\N	\N	0	\N	\N	\N	2025-10-20 15:48:58.020126	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	115407279720254077	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	{}	\N	\N
11	pupper@gmail.com	2025-10-21 06:38:41.737348	2025-10-21 06:40:03.282492	$2a$10$L56DrNp0NHc4TYBmnjDf7u4c5iohbsAwrhA9W//tZUPRRDmd1eZwS	\N	\N	1	2025-10-21 06:40:03.281229	2025-10-21 06:40:03.281229	\N	2025-10-21 06:38:42.390687	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	115410778295457737	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	{}	\N	\N
12	alice@gmail.com	2025-10-27 11:28:52.973419	2025-10-11 04:00:01.64389	$2a$10$WmFGBxyq4wCePlLC5yQMTu7NXwgLmbrlv6IVGonYjJisleMOdlqpO	\N	\N	1	2025-10-11 04:00:01.643651	2025-10-09 04:00:04.136908	\N	2025-10-27 11:28:53.023665	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	115445893227871976	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	{}	\N	\N
6	openuniversity@gmail.com	2025-10-16 11:54:52.012595	2025-10-27 13:36:40.948483	$2a$10$Qsl1Za9WTlAMxF8JA2tAaOfbu/X4xQXyqybz8aBndQsWayaLifkVm	\N	\N	2	2025-10-27 13:36:40.948013	2025-10-16 12:08:56.742531	\N	2025-10-16 11:54:52.074157	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	115383709981264049	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	{}	\N	\N
46	opencompany@gmail.com	2025-10-15 14:35:16.247272	2025-10-15 14:30:04.524885	$2a$10$DVsmDr.5qvoeCdjPYavJOOfZTaZaXhPRpFhoRhFcFWePq54hX1U4y	\N	\N	1	2025-10-15 14:30:04.524711	2025-10-13 14:30:09.506023	\N	2025-10-15 14:35:16.291247	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	115378678396852544	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	{}	\N	\N
14	kitty@gmail.com	2025-10-10 03:12:07.047307	2025-10-12 06:00:06.325313	$2a$10$HDnK9kLfkTruuFY0FtEuT.uvba7ASYXm1R.Ki4TJ6whXInhLs3VbG	\N	\N	1	2025-10-12 06:00:06.324707	2025-10-09 06:02:02.605628	\N	2025-10-10 03:12:07.077022	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	115347680582977591	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	{}	\N	\N
13	olivia@gmail.com	2025-10-10 03:12:04.370695	2025-10-12 06:00:08.637768	$2a$10$Xya4kZkzGPmWX8VyYQxC4O6lX0fJlKkQqErZGd2t3Xol8SGFHeEqq	\N	\N	1	2025-10-12 06:00:08.637554	2025-10-09 06:00:06.910245	\N	2025-10-10 03:12:04.413237	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	115347680385540244	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	{}	\N	\N
15	gourmet@gmail.com	2025-10-10 03:12:09.798204	2025-10-12 06:01:51.649162	$2a$10$hJB..L/eC8xHWSnKOIEQVO73vKjzeCUv00BGHLKZWDWoVElDTyGaW	\N	\N	1	2025-10-12 06:01:51.649057	2025-10-09 06:00:23.697491	\N	2025-10-10 03:12:09.836886	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	115347680754305497	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	{}	\N	\N
1	owner@gmail.com	2025-10-08 11:59:06.200661	2025-11-17 12:15:31.319174	$2a$10$ODaDuNbdHY6MKan/m1gDSesW3Wu7Tx/Oe9E1TYbw9.bskR1hghzPu	\N	\N	2	2025-11-17 12:15:31.317335	2025-10-15 14:31:53.901905	\N	2025-10-08 11:59:06.233714	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	115338428152261473	f	\N	\N	\N	t	\N	\N	\N	\N	\N	3	{}	\N	\N
3	test@gmail.com	2025-10-08 11:59:11.849401	2025-11-17 12:15:54.145198	$2a$10$yEfjfVmXu3kzCxuHKgR2UuWUXTQ1WQXkeehvXvZV05GwsDwg7sy1.	\N	\N	14	2025-11-17 12:15:54.144456	2025-11-17 06:40:20.70372	\N	2025-10-08 11:59:12.581379	\N	\N	en	\N	\N	\N	\N	f	\N	\N	115338428522805842	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	{"default_privacy":"public","default_sensitive":false,"default_language":"en","theme":"system","web.advanced_layout":false,"web.trends":true,"web.use_blurhash":true,"web.use_pending_items":false,"web.use_system_font":false,"web.disable_swiping":false,"web.disable_hover_cards":false,"web.delete_modal":true,"web.reblog_modal":false,"web.reduce_motion":false,"web.expand_content_warnings":false,"web.display_media":"default","web.auto_play":false}	\N	\N
9	jack@gmail.com	2025-10-20 15:48:55.09099	2025-10-15 14:32:35.072257	$2a$10$r3lOJrmvNIDlUKX1/b2Yxe.dNKsXRNNNBw3flqpzIi9E2xlsIKaCW	\N	\N	1	2025-10-15 14:32:35.070699	2025-10-15 14:32:35.070699	\N	2025-10-20 15:48:55.121685	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	115407279554762986	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	{}	\N	\N
\.


--
-- Data for Name: web_push_subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.web_push_subscriptions (id, endpoint, key_p256dh, key_auth, data, created_at, updated_at, access_token_id, user_id) FROM stdin;
\.


--
-- Data for Name: web_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.web_settings (id, data, created_at, updated_at, user_id) FROM stdin;
1	{"notifications":{"alerts":{"follow_request":false,"favourite":false,"update":false,"mention":false,"follow":false,"status":false,"admin.report":false,"reblog":false,"admin.sign_up":false,"poll":false},"quickFilter":{"active":"all","show":true,"advanced":false},"dismissPermissionBanner":false,"showUnread":true,"minimizeFilteredBanner":false,"shows":{"follow_request":false,"favourite":true,"update":true,"mention":true,"follow":true,"status":true,"admin.report":true,"reblog":true,"admin.sign_up":true,"poll":true},"sounds":{"follow_request":false,"favourite":true,"update":true,"mention":true,"follow":true,"status":true,"admin.report":true,"reblog":true,"admin.sign_up":true,"poll":true},"group":{"follow":true}},"public":{"regex":{"body":""}},"direct":{"regex":{"body":""}},"community":{"regex":{"body":""}},"skinTone":1,"firehose":{"onlyMedia":false},"dismissed_banners":{"public_timeline":true,"community_timeline":false,"home/follow-suggestions":false,"explore/links":false,"explore/statuses":false,"explore/tags":false},"trends":{"show":true},"columns":[{"id":"COMPOSE","uuid":"e5d2c26d-f99e-429e-b261-dc14abf92e78","params":{}},{"id":"HOME","uuid":"14bb3520-1d5c-4614-a68d-a18cb83909df","params":{}},{"id":"NOTIFICATIONS","uuid":"fbed00e8-f87e-47b1-b61b-28080e547814","params":{}}],"home":{"shows":{"reblog":true,"reply":true},"regex":{"body":""}}}	2025-10-13 11:53:09.566015	2025-10-13 11:53:09.566015	3
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.webauthn_credentials (id, external_id, public_key, nickname, sign_count, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.webhooks (id, url, events, secret, enabled, created_at, updated_at, template) FROM stdin;
\.


--
-- Name: account_aliases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_aliases_id_seq', 1, false);


--
-- Name: account_conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_conversations_id_seq', 1, false);


--
-- Name: account_deletion_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_deletion_requests_id_seq', 1, false);


--
-- Name: account_domain_blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_domain_blocks_id_seq', 1, false);


--
-- Name: account_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_migrations_id_seq', 1, false);


--
-- Name: account_moderation_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_moderation_notes_id_seq', 1, false);


--
-- Name: account_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_notes_id_seq', 1, false);


--
-- Name: account_pins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_pins_id_seq', 1, false);


--
-- Name: account_relationship_severance_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_relationship_severance_events_id_seq', 1, false);


--
-- Name: account_stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_stats_id_seq', 166, true);


--
-- Name: account_statuses_cleanup_policies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_statuses_cleanup_policies_id_seq', 1, false);


--
-- Name: account_warning_presets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_warning_presets_id_seq', 1, false);


--
-- Name: account_warnings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_warnings_id_seq', 1, false);


--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_id_seq', 46, true);


--
-- Name: admin_action_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.admin_action_logs_id_seq', 1, false);


--
-- Name: announcement_mutes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.announcement_mutes_id_seq', 1, false);


--
-- Name: announcement_reactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.announcement_reactions_id_seq', 1, false);


--
-- Name: announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.announcements_id_seq', 1, false);


--
-- Name: appeals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.appeals_id_seq', 1, false);


--
-- Name: backups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.backups_id_seq', 1, false);


--
-- Name: blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blocks_id_seq', 1, true);


--
-- Name: bookmarks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bookmarks_id_seq', 36, true);


--
-- Name: bulk_import_rows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bulk_import_rows_id_seq', 1, false);


--
-- Name: bulk_imports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bulk_imports_id_seq', 1, false);


--
-- Name: canonical_email_blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.canonical_email_blocks_id_seq', 1, false);


--
-- Name: conversation_mutes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.conversation_mutes_id_seq', 1, false);


--
-- Name: conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.conversations_id_seq', 94, true);


--
-- Name: custom_emoji_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.custom_emoji_categories_id_seq', 1, false);


--
-- Name: custom_emojis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.custom_emojis_id_seq', 1, false);


--
-- Name: custom_filter_keywords_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.custom_filter_keywords_id_seq', 6, true);


--
-- Name: custom_filter_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.custom_filter_statuses_id_seq', 1, false);


--
-- Name: custom_filters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.custom_filters_id_seq', 2, true);


--
-- Name: domain_allows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.domain_allows_id_seq', 1, false);


--
-- Name: domain_blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.domain_blocks_id_seq', 1, false);


--
-- Name: email_domain_blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_domain_blocks_id_seq', 1, false);


--
-- Name: favourites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.favourites_id_seq', 3, true);


--
-- Name: featured_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.featured_tags_id_seq', 1, false);


--
-- Name: follow_recommendation_mutes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.follow_recommendation_mutes_id_seq', 1, false);


--
-- Name: follow_recommendation_suppressions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.follow_recommendation_suppressions_id_seq', 1, false);


--
-- Name: follow_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.follow_requests_id_seq', 1, false);


--
-- Name: follows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.follows_id_seq', 41, true);


--
-- Name: generated_annual_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.generated_annual_reports_id_seq', 1, false);


--
-- Name: identities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.identities_id_seq', 1, false);


--
-- Name: imports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.imports_id_seq', 1, false);


--
-- Name: invites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invites_id_seq', 4, true);


--
-- Name: ip_blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ip_blocks_id_seq', 1, false);


--
-- Name: list_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.list_accounts_id_seq', 2, true);


--
-- Name: lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lists_id_seq', 3, true);


--
-- Name: login_activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.login_activities_id_seq', 57, true);


--
-- Name: markers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.markers_id_seq', 43, true);


--
-- Name: media_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.media_attachments_id_seq', 91, true);


--
-- Name: mentions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mentions_id_seq', 1, true);


--
-- Name: mutes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mutes_id_seq', 1, true);


--
-- Name: notification_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_permissions_id_seq', 1, false);


--
-- Name: notification_policies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_policies_id_seq', 1, true);


--
-- Name: notification_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_requests_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_id_seq', 59, true);


--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_access_grants_id_seq', 65, true);


--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_access_tokens_id_seq', 86, true);


--
-- Name: oauth_applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_applications_id_seq', 68, true);


--
-- Name: pghero_space_stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pghero_space_stats_id_seq', 2292, true);


--
-- Name: poll_votes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.poll_votes_id_seq', 1, true);


--
-- Name: polls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.polls_id_seq', 2, true);


--
-- Name: preview_card_providers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.preview_card_providers_id_seq', 1, false);


--
-- Name: preview_card_trends_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.preview_card_trends_id_seq', 1, false);


--
-- Name: preview_cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.preview_cards_id_seq', 1, false);


--
-- Name: relationship_severance_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.relationship_severance_events_id_seq', 1, false);


--
-- Name: relays_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.relays_id_seq', 1, false);


--
-- Name: report_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.report_notes_id_seq', 1, false);


--
-- Name: reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reports_id_seq', 2, true);


--
-- Name: rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rules_id_seq', 1, false);


--
-- Name: scheduled_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.scheduled_statuses_id_seq', 1, false);


--
-- Name: session_activations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.session_activations_id_seq', 57, true);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.settings_id_seq', 1, false);


--
-- Name: severed_relationships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.severed_relationships_id_seq', 1, false);


--
-- Name: site_uploads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.site_uploads_id_seq', 1, false);


--
-- Name: software_updates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.software_updates_id_seq', 3, true);


--
-- Name: status_edits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.status_edits_id_seq', 38, true);


--
-- Name: status_pins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.status_pins_id_seq', 1, false);


--
-- Name: status_stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.status_stats_id_seq', 3, true);


--
-- Name: status_trends_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.status_trends_id_seq', 1, false);


--
-- Name: statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.statuses_id_seq', 96, true);


--
-- Name: tag_follows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tag_follows_id_seq', 36, true);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tags_id_seq', 89, true);


--
-- Name: tombstones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tombstones_id_seq', 1, false);


--
-- Name: unavailable_domains_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.unavailable_domains_id_seq', 1, false);


--
-- Name: user_invite_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_invite_requests_id_seq', 1, false);


--
-- Name: user_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_roles_id_seq', 3, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 46, true);


--
-- Name: web_push_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.web_push_subscriptions_id_seq', 1, false);


--
-- Name: web_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.web_settings_id_seq', 1, true);


--
-- Name: webauthn_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.webauthn_credentials_id_seq', 1, false);


--
-- Name: webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.webhooks_id_seq', 1, false);


--
-- Name: account_aliases account_aliases_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_aliases
    ADD CONSTRAINT account_aliases_pkey PRIMARY KEY (id);


--
-- Name: account_conversations account_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_conversations
    ADD CONSTRAINT account_conversations_pkey PRIMARY KEY (id);


--
-- Name: account_deletion_requests account_deletion_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_deletion_requests
    ADD CONSTRAINT account_deletion_requests_pkey PRIMARY KEY (id);


--
-- Name: account_domain_blocks account_domain_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_domain_blocks
    ADD CONSTRAINT account_domain_blocks_pkey PRIMARY KEY (id);


--
-- Name: account_migrations account_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_migrations
    ADD CONSTRAINT account_migrations_pkey PRIMARY KEY (id);


--
-- Name: account_moderation_notes account_moderation_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_moderation_notes
    ADD CONSTRAINT account_moderation_notes_pkey PRIMARY KEY (id);


--
-- Name: account_notes account_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_notes
    ADD CONSTRAINT account_notes_pkey PRIMARY KEY (id);


--
-- Name: account_pins account_pins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_pins
    ADD CONSTRAINT account_pins_pkey PRIMARY KEY (id);


--
-- Name: account_relationship_severance_events account_relationship_severance_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_relationship_severance_events
    ADD CONSTRAINT account_relationship_severance_events_pkey PRIMARY KEY (id);


--
-- Name: account_stats account_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_stats
    ADD CONSTRAINT account_stats_pkey PRIMARY KEY (id);


--
-- Name: account_statuses_cleanup_policies account_statuses_cleanup_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_statuses_cleanup_policies
    ADD CONSTRAINT account_statuses_cleanup_policies_pkey PRIMARY KEY (id);


--
-- Name: account_warning_presets account_warning_presets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_warning_presets
    ADD CONSTRAINT account_warning_presets_pkey PRIMARY KEY (id);


--
-- Name: account_warnings account_warnings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_warnings
    ADD CONSTRAINT account_warnings_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: accounts_tags accounts_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_tags
    ADD CONSTRAINT accounts_tags_pkey PRIMARY KEY (tag_id, account_id);


--
-- Name: admin_action_logs admin_action_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_action_logs
    ADD CONSTRAINT admin_action_logs_pkey PRIMARY KEY (id);


--
-- Name: announcement_mutes announcement_mutes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_mutes
    ADD CONSTRAINT announcement_mutes_pkey PRIMARY KEY (id);


--
-- Name: announcement_reactions announcement_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_reactions
    ADD CONSTRAINT announcement_reactions_pkey PRIMARY KEY (id);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: appeals appeals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appeals
    ADD CONSTRAINT appeals_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: blocks blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blocks
    ADD CONSTRAINT blocks_pkey PRIMARY KEY (id);


--
-- Name: bookmarks bookmarks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookmarks
    ADD CONSTRAINT bookmarks_pkey PRIMARY KEY (id);


--
-- Name: bulk_import_rows bulk_import_rows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bulk_import_rows
    ADD CONSTRAINT bulk_import_rows_pkey PRIMARY KEY (id);


--
-- Name: bulk_imports bulk_imports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bulk_imports
    ADD CONSTRAINT bulk_imports_pkey PRIMARY KEY (id);


--
-- Name: canonical_email_blocks canonical_email_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.canonical_email_blocks
    ADD CONSTRAINT canonical_email_blocks_pkey PRIMARY KEY (id);


--
-- Name: conversation_mutes conversation_mutes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_mutes
    ADD CONSTRAINT conversation_mutes_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: custom_emoji_categories custom_emoji_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_emoji_categories
    ADD CONSTRAINT custom_emoji_categories_pkey PRIMARY KEY (id);


--
-- Name: custom_emojis custom_emojis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_emojis
    ADD CONSTRAINT custom_emojis_pkey PRIMARY KEY (id);


--
-- Name: custom_filter_keywords custom_filter_keywords_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_filter_keywords
    ADD CONSTRAINT custom_filter_keywords_pkey PRIMARY KEY (id);


--
-- Name: custom_filter_statuses custom_filter_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_filter_statuses
    ADD CONSTRAINT custom_filter_statuses_pkey PRIMARY KEY (id);


--
-- Name: custom_filters custom_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_filters
    ADD CONSTRAINT custom_filters_pkey PRIMARY KEY (id);


--
-- Name: domain_allows domain_allows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.domain_allows
    ADD CONSTRAINT domain_allows_pkey PRIMARY KEY (id);


--
-- Name: domain_blocks domain_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.domain_blocks
    ADD CONSTRAINT domain_blocks_pkey PRIMARY KEY (id);


--
-- Name: email_domain_blocks email_domain_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_domain_blocks
    ADD CONSTRAINT email_domain_blocks_pkey PRIMARY KEY (id);


--
-- Name: favourites favourites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favourites
    ADD CONSTRAINT favourites_pkey PRIMARY KEY (id);


--
-- Name: featured_tags featured_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.featured_tags
    ADD CONSTRAINT featured_tags_pkey PRIMARY KEY (id);


--
-- Name: follow_recommendation_mutes follow_recommendation_mutes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follow_recommendation_mutes
    ADD CONSTRAINT follow_recommendation_mutes_pkey PRIMARY KEY (id);


--
-- Name: follow_recommendation_suppressions follow_recommendation_suppressions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follow_recommendation_suppressions
    ADD CONSTRAINT follow_recommendation_suppressions_pkey PRIMARY KEY (id);


--
-- Name: follow_requests follow_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follow_requests
    ADD CONSTRAINT follow_requests_pkey PRIMARY KEY (id);


--
-- Name: follows follows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_pkey PRIMARY KEY (id);


--
-- Name: generated_annual_reports generated_annual_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generated_annual_reports
    ADD CONSTRAINT generated_annual_reports_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: imports imports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imports
    ADD CONSTRAINT imports_pkey PRIMARY KEY (id);


--
-- Name: invites invites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT invites_pkey PRIMARY KEY (id);


--
-- Name: ip_blocks ip_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ip_blocks
    ADD CONSTRAINT ip_blocks_pkey PRIMARY KEY (id);


--
-- Name: list_accounts list_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.list_accounts
    ADD CONSTRAINT list_accounts_pkey PRIMARY KEY (id);


--
-- Name: lists lists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lists
    ADD CONSTRAINT lists_pkey PRIMARY KEY (id);


--
-- Name: login_activities login_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_activities
    ADD CONSTRAINT login_activities_pkey PRIMARY KEY (id);


--
-- Name: markers markers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.markers
    ADD CONSTRAINT markers_pkey PRIMARY KEY (id);


--
-- Name: media_attachments media_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_attachments
    ADD CONSTRAINT media_attachments_pkey PRIMARY KEY (id);


--
-- Name: mentions mentions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentions
    ADD CONSTRAINT mentions_pkey PRIMARY KEY (id);


--
-- Name: mutes mutes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mutes
    ADD CONSTRAINT mutes_pkey PRIMARY KEY (id);


--
-- Name: notification_permissions notification_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_permissions
    ADD CONSTRAINT notification_permissions_pkey PRIMARY KEY (id);


--
-- Name: notification_policies notification_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_policies
    ADD CONSTRAINT notification_policies_pkey PRIMARY KEY (id);


--
-- Name: notification_requests notification_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_requests
    ADD CONSTRAINT notification_requests_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_grants oauth_access_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_grants
    ADD CONSTRAINT oauth_access_grants_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_tokens oauth_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT oauth_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_applications oauth_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_applications
    ADD CONSTRAINT oauth_applications_pkey PRIMARY KEY (id);


--
-- Name: pghero_space_stats pghero_space_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pghero_space_stats
    ADD CONSTRAINT pghero_space_stats_pkey PRIMARY KEY (id);


--
-- Name: poll_votes poll_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_votes
    ADD CONSTRAINT poll_votes_pkey PRIMARY KEY (id);


--
-- Name: polls polls_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT polls_pkey PRIMARY KEY (id);


--
-- Name: preview_card_providers preview_card_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preview_card_providers
    ADD CONSTRAINT preview_card_providers_pkey PRIMARY KEY (id);


--
-- Name: preview_card_trends preview_card_trends_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preview_card_trends
    ADD CONSTRAINT preview_card_trends_pkey PRIMARY KEY (id);


--
-- Name: preview_cards preview_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preview_cards
    ADD CONSTRAINT preview_cards_pkey PRIMARY KEY (id);


--
-- Name: preview_cards_statuses preview_cards_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preview_cards_statuses
    ADD CONSTRAINT preview_cards_statuses_pkey PRIMARY KEY (status_id, preview_card_id);


--
-- Name: relationship_severance_events relationship_severance_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relationship_severance_events
    ADD CONSTRAINT relationship_severance_events_pkey PRIMARY KEY (id);


--
-- Name: relays relays_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relays
    ADD CONSTRAINT relays_pkey PRIMARY KEY (id);


--
-- Name: report_notes report_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_notes
    ADD CONSTRAINT report_notes_pkey PRIMARY KEY (id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: rules rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rules
    ADD CONSTRAINT rules_pkey PRIMARY KEY (id);


--
-- Name: scheduled_statuses scheduled_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduled_statuses
    ADD CONSTRAINT scheduled_statuses_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: session_activations session_activations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_activations
    ADD CONSTRAINT session_activations_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: severed_relationships severed_relationships_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.severed_relationships
    ADD CONSTRAINT severed_relationships_pkey PRIMARY KEY (id);


--
-- Name: site_uploads site_uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_uploads
    ADD CONSTRAINT site_uploads_pkey PRIMARY KEY (id);


--
-- Name: software_updates software_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.software_updates
    ADD CONSTRAINT software_updates_pkey PRIMARY KEY (id);


--
-- Name: status_edits status_edits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_edits
    ADD CONSTRAINT status_edits_pkey PRIMARY KEY (id);


--
-- Name: status_pins status_pins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_pins
    ADD CONSTRAINT status_pins_pkey PRIMARY KEY (id);


--
-- Name: status_stats status_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_stats
    ADD CONSTRAINT status_stats_pkey PRIMARY KEY (id);


--
-- Name: status_trends status_trends_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_trends
    ADD CONSTRAINT status_trends_pkey PRIMARY KEY (id);


--
-- Name: statuses statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_pkey PRIMARY KEY (id);


--
-- Name: statuses_tags statuses_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statuses_tags
    ADD CONSTRAINT statuses_tags_pkey PRIMARY KEY (tag_id, status_id);


--
-- Name: tag_follows tag_follows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tag_follows
    ADD CONSTRAINT tag_follows_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tombstones tombstones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tombstones
    ADD CONSTRAINT tombstones_pkey PRIMARY KEY (id);


--
-- Name: unavailable_domains unavailable_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unavailable_domains
    ADD CONSTRAINT unavailable_domains_pkey PRIMARY KEY (id);


--
-- Name: user_invite_requests user_invite_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_invite_requests
    ADD CONSTRAINT user_invite_requests_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: web_push_subscriptions web_push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.web_push_subscriptions
    ADD CONSTRAINT web_push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: web_settings web_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.web_settings
    ADD CONSTRAINT web_settings_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: idx_on_account_id_language_sensitive_250461e1eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_on_account_id_language_sensitive_250461e1eb ON public.account_summaries USING btree (account_id, language, sensitive);


--
-- Name: idx_on_account_id_relationship_severance_event_id_7bd82bf20e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_on_account_id_relationship_severance_event_id_7bd82bf20e ON public.account_relationship_severance_events USING btree (account_id, relationship_severance_event_id);


--
-- Name: idx_on_account_id_target_account_id_a8c8ddf44e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_on_account_id_target_account_id_a8c8ddf44e ON public.follow_recommendation_mutes USING btree (account_id, target_account_id);


--
-- Name: idx_on_relationship_severance_event_id_403f53e707; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_on_relationship_severance_event_id_403f53e707 ON public.account_relationship_severance_events USING btree (relationship_severance_event_id);


--
-- Name: index_account_aliases_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_account_aliases_on_account_id ON public.account_aliases USING btree (account_id);


--
-- Name: index_account_aliases_on_account_id_and_uri; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_account_aliases_on_account_id_and_uri ON public.account_aliases USING btree (account_id, uri);


--
-- Name: index_account_conversations_on_conversation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_account_conversations_on_conversation_id ON public.account_conversations USING btree (conversation_id);


--
-- Name: index_account_deletion_requests_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_account_deletion_requests_on_account_id ON public.account_deletion_requests USING btree (account_id);


--
-- Name: index_account_domain_blocks_on_account_id_and_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_account_domain_blocks_on_account_id_and_domain ON public.account_domain_blocks USING btree (account_id, domain);


--
-- Name: index_account_migrations_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_account_migrations_on_account_id ON public.account_migrations USING btree (account_id);


--
-- Name: index_account_migrations_on_target_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_account_migrations_on_target_account_id ON public.account_migrations USING btree (target_account_id) WHERE (target_account_id IS NOT NULL);


--
-- Name: index_account_moderation_notes_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_account_moderation_notes_on_account_id ON public.account_moderation_notes USING btree (account_id);


--
-- Name: index_account_moderation_notes_on_target_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_account_moderation_notes_on_target_account_id ON public.account_moderation_notes USING btree (target_account_id);


--
-- Name: index_account_notes_on_account_id_and_target_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_account_notes_on_account_id_and_target_account_id ON public.account_notes USING btree (account_id, target_account_id);


--
-- Name: index_account_notes_on_target_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_account_notes_on_target_account_id ON public.account_notes USING btree (target_account_id);


--
-- Name: index_account_pins_on_account_id_and_target_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_account_pins_on_account_id_and_target_account_id ON public.account_pins USING btree (account_id, target_account_id);


--
-- Name: index_account_pins_on_target_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_account_pins_on_target_account_id ON public.account_pins USING btree (target_account_id);


--
-- Name: index_account_relationship_severance_events_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_account_relationship_severance_events_on_account_id ON public.account_relationship_severance_events USING btree (account_id);


--
-- Name: index_account_stats_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_account_stats_on_account_id ON public.account_stats USING btree (account_id);


--
-- Name: index_account_stats_on_last_status_at_and_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_account_stats_on_last_status_at_and_account_id ON public.account_stats USING btree (last_status_at DESC NULLS LAST, account_id);


--
-- Name: index_account_statuses_cleanup_policies_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_account_statuses_cleanup_policies_on_account_id ON public.account_statuses_cleanup_policies USING btree (account_id);


--
-- Name: index_account_summaries_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_account_summaries_on_account_id ON public.account_summaries USING btree (account_id);


--
-- Name: index_account_warnings_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_account_warnings_on_account_id ON public.account_warnings USING btree (account_id);


--
-- Name: index_account_warnings_on_target_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_account_warnings_on_target_account_id ON public.account_warnings USING btree (target_account_id);


--
-- Name: index_accounts_on_domain_and_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_accounts_on_domain_and_id ON public.accounts USING btree (domain, id);


--
-- Name: index_accounts_on_moved_to_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_accounts_on_moved_to_account_id ON public.accounts USING btree (moved_to_account_id) WHERE (moved_to_account_id IS NOT NULL);


--
-- Name: index_accounts_on_uri; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_accounts_on_uri ON public.accounts USING btree (uri);


--
-- Name: index_accounts_on_url; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_accounts_on_url ON public.accounts USING btree (url text_pattern_ops) WHERE (url IS NOT NULL);


--
-- Name: index_accounts_on_username_and_domain_lower; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_accounts_on_username_and_domain_lower ON public.accounts USING btree (lower((username)::text), COALESCE(lower((domain)::text), ''::text));


--
-- Name: index_accounts_tags_on_account_id_and_tag_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_accounts_tags_on_account_id_and_tag_id ON public.accounts_tags USING btree (account_id, tag_id);


--
-- Name: index_admin_action_logs_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_admin_action_logs_on_account_id ON public.admin_action_logs USING btree (account_id);


--
-- Name: index_admin_action_logs_on_target_type_and_target_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_admin_action_logs_on_target_type_and_target_id ON public.admin_action_logs USING btree (target_type, target_id);


--
-- Name: index_announcement_mutes_on_account_id_and_announcement_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_announcement_mutes_on_account_id_and_announcement_id ON public.announcement_mutes USING btree (account_id, announcement_id);


--
-- Name: index_announcement_mutes_on_announcement_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_announcement_mutes_on_announcement_id ON public.announcement_mutes USING btree (announcement_id);


--
-- Name: index_announcement_reactions_on_account_id_and_announcement_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_announcement_reactions_on_account_id_and_announcement_id ON public.announcement_reactions USING btree (account_id, announcement_id, name);


--
-- Name: index_announcement_reactions_on_announcement_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_announcement_reactions_on_announcement_id ON public.announcement_reactions USING btree (announcement_id);


--
-- Name: index_announcement_reactions_on_custom_emoji_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_announcement_reactions_on_custom_emoji_id ON public.announcement_reactions USING btree (custom_emoji_id) WHERE (custom_emoji_id IS NOT NULL);


--
-- Name: index_appeals_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_appeals_on_account_id ON public.appeals USING btree (account_id);


--
-- Name: index_appeals_on_account_warning_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_appeals_on_account_warning_id ON public.appeals USING btree (account_warning_id);


--
-- Name: index_appeals_on_approved_by_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_appeals_on_approved_by_account_id ON public.appeals USING btree (approved_by_account_id) WHERE (approved_by_account_id IS NOT NULL);


--
-- Name: index_appeals_on_rejected_by_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_appeals_on_rejected_by_account_id ON public.appeals USING btree (rejected_by_account_id) WHERE (rejected_by_account_id IS NOT NULL);


--
-- Name: index_backups_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_backups_on_user_id ON public.backups USING btree (user_id);


--
-- Name: index_blocks_on_account_id_and_target_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_blocks_on_account_id_and_target_account_id ON public.blocks USING btree (account_id, target_account_id);


--
-- Name: index_blocks_on_target_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_blocks_on_target_account_id ON public.blocks USING btree (target_account_id);


--
-- Name: index_bookmarks_on_account_id_and_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_bookmarks_on_account_id_and_status_id ON public.bookmarks USING btree (account_id, status_id);


--
-- Name: index_bookmarks_on_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_bookmarks_on_status_id ON public.bookmarks USING btree (status_id);


--
-- Name: index_bulk_import_rows_on_bulk_import_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_bulk_import_rows_on_bulk_import_id ON public.bulk_import_rows USING btree (bulk_import_id);


--
-- Name: index_bulk_imports_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_bulk_imports_on_account_id ON public.bulk_imports USING btree (account_id);


--
-- Name: index_bulk_imports_unconfirmed; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_bulk_imports_unconfirmed ON public.bulk_imports USING btree (id) WHERE (state = 0);


--
-- Name: index_canonical_email_blocks_on_canonical_email_hash; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_canonical_email_blocks_on_canonical_email_hash ON public.canonical_email_blocks USING btree (canonical_email_hash);


--
-- Name: index_canonical_email_blocks_on_reference_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_canonical_email_blocks_on_reference_account_id ON public.canonical_email_blocks USING btree (reference_account_id);


--
-- Name: index_conversation_mutes_on_account_id_and_conversation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_conversation_mutes_on_account_id_and_conversation_id ON public.conversation_mutes USING btree (account_id, conversation_id);


--
-- Name: index_conversations_on_uri; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_conversations_on_uri ON public.conversations USING btree (uri text_pattern_ops) WHERE (uri IS NOT NULL);


--
-- Name: index_custom_emoji_categories_on_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_custom_emoji_categories_on_name ON public.custom_emoji_categories USING btree (name);


--
-- Name: index_custom_emojis_on_shortcode_and_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_custom_emojis_on_shortcode_and_domain ON public.custom_emojis USING btree (shortcode, domain);


--
-- Name: index_custom_filter_keywords_on_custom_filter_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_custom_filter_keywords_on_custom_filter_id ON public.custom_filter_keywords USING btree (custom_filter_id);


--
-- Name: index_custom_filter_statuses_on_custom_filter_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_custom_filter_statuses_on_custom_filter_id ON public.custom_filter_statuses USING btree (custom_filter_id);


--
-- Name: index_custom_filter_statuses_on_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_custom_filter_statuses_on_status_id ON public.custom_filter_statuses USING btree (status_id);


--
-- Name: index_custom_filter_statuses_on_status_id_and_custom_filter_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_custom_filter_statuses_on_status_id_and_custom_filter_id ON public.custom_filter_statuses USING btree (status_id, custom_filter_id);


--
-- Name: index_custom_filters_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_custom_filters_on_account_id ON public.custom_filters USING btree (account_id);


--
-- Name: index_domain_allows_on_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_domain_allows_on_domain ON public.domain_allows USING btree (domain);


--
-- Name: index_domain_blocks_on_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_domain_blocks_on_domain ON public.domain_blocks USING btree (domain);


--
-- Name: index_email_domain_blocks_on_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_email_domain_blocks_on_domain ON public.email_domain_blocks USING btree (domain);


--
-- Name: index_favourites_on_account_id_and_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_favourites_on_account_id_and_id ON public.favourites USING btree (account_id, id);


--
-- Name: index_favourites_on_account_id_and_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_favourites_on_account_id_and_status_id ON public.favourites USING btree (account_id, status_id);


--
-- Name: index_favourites_on_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_favourites_on_status_id ON public.favourites USING btree (status_id);


--
-- Name: index_featured_tags_on_account_id_and_tag_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_featured_tags_on_account_id_and_tag_id ON public.featured_tags USING btree (account_id, tag_id);


--
-- Name: index_featured_tags_on_tag_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_featured_tags_on_tag_id ON public.featured_tags USING btree (tag_id);


--
-- Name: index_follow_recommendation_mutes_on_target_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_follow_recommendation_mutes_on_target_account_id ON public.follow_recommendation_mutes USING btree (target_account_id);


--
-- Name: index_follow_recommendation_suppressions_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_follow_recommendation_suppressions_on_account_id ON public.follow_recommendation_suppressions USING btree (account_id);


--
-- Name: index_follow_requests_on_account_id_and_target_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_follow_requests_on_account_id_and_target_account_id ON public.follow_requests USING btree (account_id, target_account_id);


--
-- Name: index_follows_on_account_id_and_target_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_follows_on_account_id_and_target_account_id ON public.follows USING btree (account_id, target_account_id);


--
-- Name: index_follows_on_target_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_follows_on_target_account_id ON public.follows USING btree (target_account_id);


--
-- Name: index_generated_annual_reports_on_account_id_and_year; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_generated_annual_reports_on_account_id_and_year ON public.generated_annual_reports USING btree (account_id, year);


--
-- Name: index_global_follow_recommendations_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_global_follow_recommendations_on_account_id ON public.global_follow_recommendations USING btree (account_id);


--
-- Name: index_identities_on_uid_and_provider; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_identities_on_uid_and_provider ON public.identities USING btree (uid, provider);


--
-- Name: index_identities_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_identities_on_user_id ON public.identities USING btree (user_id);


--
-- Name: index_instances_on_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_instances_on_domain ON public.instances USING btree (domain);


--
-- Name: index_instances_on_reverse_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_instances_on_reverse_domain ON public.instances USING btree (reverse(('.'::text || (domain)::text)), domain);


--
-- Name: index_invites_on_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_invites_on_code ON public.invites USING btree (code);


--
-- Name: index_invites_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_invites_on_user_id ON public.invites USING btree (user_id);


--
-- Name: index_ip_blocks_on_ip; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_ip_blocks_on_ip ON public.ip_blocks USING btree (ip);


--
-- Name: index_list_accounts_on_account_id_and_list_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_list_accounts_on_account_id_and_list_id ON public.list_accounts USING btree (account_id, list_id);


--
-- Name: index_list_accounts_on_follow_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_list_accounts_on_follow_id ON public.list_accounts USING btree (follow_id) WHERE (follow_id IS NOT NULL);


--
-- Name: index_list_accounts_on_follow_request_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_list_accounts_on_follow_request_id ON public.list_accounts USING btree (follow_request_id) WHERE (follow_request_id IS NOT NULL);


--
-- Name: index_list_accounts_on_list_id_and_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_list_accounts_on_list_id_and_account_id ON public.list_accounts USING btree (list_id, account_id);


--
-- Name: index_lists_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_lists_on_account_id ON public.lists USING btree (account_id);


--
-- Name: index_login_activities_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_login_activities_on_user_id ON public.login_activities USING btree (user_id);


--
-- Name: index_markers_on_user_id_and_timeline; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_markers_on_user_id_and_timeline ON public.markers USING btree (user_id, timeline);


--
-- Name: index_media_attachments_on_account_id_and_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_media_attachments_on_account_id_and_status_id ON public.media_attachments USING btree (account_id, status_id DESC);


--
-- Name: index_media_attachments_on_scheduled_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_media_attachments_on_scheduled_status_id ON public.media_attachments USING btree (scheduled_status_id) WHERE (scheduled_status_id IS NOT NULL);


--
-- Name: index_media_attachments_on_shortcode; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_media_attachments_on_shortcode ON public.media_attachments USING btree (shortcode text_pattern_ops) WHERE (shortcode IS NOT NULL);


--
-- Name: index_media_attachments_on_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_media_attachments_on_status_id ON public.media_attachments USING btree (status_id);


--
-- Name: index_mentions_on_account_id_and_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_mentions_on_account_id_and_status_id ON public.mentions USING btree (account_id, status_id);


--
-- Name: index_mentions_on_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_mentions_on_status_id ON public.mentions USING btree (status_id);


--
-- Name: index_mutes_on_account_id_and_target_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_mutes_on_account_id_and_target_account_id ON public.mutes USING btree (account_id, target_account_id);


--
-- Name: index_mutes_on_target_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_mutes_on_target_account_id ON public.mutes USING btree (target_account_id);


--
-- Name: index_notification_permissions_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notification_permissions_on_account_id ON public.notification_permissions USING btree (account_id);


--
-- Name: index_notification_permissions_on_from_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notification_permissions_on_from_account_id ON public.notification_permissions USING btree (from_account_id);


--
-- Name: index_notification_policies_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_notification_policies_on_account_id ON public.notification_policies USING btree (account_id);


--
-- Name: index_notification_requests_on_account_id_and_from_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_notification_requests_on_account_id_and_from_account_id ON public.notification_requests USING btree (account_id, from_account_id);


--
-- Name: index_notification_requests_on_from_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notification_requests_on_from_account_id ON public.notification_requests USING btree (from_account_id);


--
-- Name: index_notification_requests_on_last_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notification_requests_on_last_status_id ON public.notification_requests USING btree (last_status_id);


--
-- Name: index_notifications_on_account_id_and_group_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_account_id_and_group_key ON public.notifications USING btree (account_id, group_key) WHERE (group_key IS NOT NULL);


--
-- Name: index_notifications_on_account_id_and_id_and_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_account_id_and_id_and_type ON public.notifications USING btree (account_id, id DESC, type);


--
-- Name: index_notifications_on_activity_id_and_activity_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_activity_id_and_activity_type ON public.notifications USING btree (activity_id, activity_type);


--
-- Name: index_notifications_on_filtered; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_filtered ON public.notifications USING btree (account_id, id DESC, type) WHERE (filtered = false);


--
-- Name: index_notifications_on_from_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_notifications_on_from_account_id ON public.notifications USING btree (from_account_id);


--
-- Name: index_oauth_access_grants_on_resource_owner_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_oauth_access_grants_on_resource_owner_id ON public.oauth_access_grants USING btree (resource_owner_id);


--
-- Name: index_oauth_access_grants_on_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_oauth_access_grants_on_token ON public.oauth_access_grants USING btree (token);


--
-- Name: index_oauth_access_tokens_on_refresh_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_oauth_access_tokens_on_refresh_token ON public.oauth_access_tokens USING btree (refresh_token text_pattern_ops) WHERE (refresh_token IS NOT NULL);


--
-- Name: index_oauth_access_tokens_on_resource_owner_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_oauth_access_tokens_on_resource_owner_id ON public.oauth_access_tokens USING btree (resource_owner_id) WHERE (resource_owner_id IS NOT NULL);


--
-- Name: index_oauth_access_tokens_on_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_oauth_access_tokens_on_token ON public.oauth_access_tokens USING btree (token);


--
-- Name: index_oauth_applications_on_owner_id_and_owner_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_oauth_applications_on_owner_id_and_owner_type ON public.oauth_applications USING btree (owner_id, owner_type);


--
-- Name: index_oauth_applications_on_superapp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_oauth_applications_on_superapp ON public.oauth_applications USING btree (superapp) WHERE (superapp = true);


--
-- Name: index_oauth_applications_on_uid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_oauth_applications_on_uid ON public.oauth_applications USING btree (uid);


--
-- Name: index_pghero_space_stats_on_database_and_captured_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_pghero_space_stats_on_database_and_captured_at ON public.pghero_space_stats USING btree (database, captured_at);


--
-- Name: index_poll_votes_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_poll_votes_on_account_id ON public.poll_votes USING btree (account_id);


--
-- Name: index_poll_votes_on_poll_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_poll_votes_on_poll_id ON public.poll_votes USING btree (poll_id);


--
-- Name: index_polls_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_polls_on_account_id ON public.polls USING btree (account_id);


--
-- Name: index_polls_on_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_polls_on_status_id ON public.polls USING btree (status_id);


--
-- Name: index_preview_card_providers_on_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_preview_card_providers_on_domain ON public.preview_card_providers USING btree (domain);


--
-- Name: index_preview_card_trends_on_preview_card_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_preview_card_trends_on_preview_card_id ON public.preview_card_trends USING btree (preview_card_id);


--
-- Name: index_preview_cards_on_author_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_preview_cards_on_author_account_id ON public.preview_cards USING btree (author_account_id) WHERE (author_account_id IS NOT NULL);


--
-- Name: index_preview_cards_on_url; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_preview_cards_on_url ON public.preview_cards USING btree (url);


--
-- Name: index_relationship_severance_events_on_type_and_target_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_relationship_severance_events_on_type_and_target_name ON public.relationship_severance_events USING btree (type, target_name);


--
-- Name: index_report_notes_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_report_notes_on_account_id ON public.report_notes USING btree (account_id);


--
-- Name: index_report_notes_on_report_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_report_notes_on_report_id ON public.report_notes USING btree (report_id);


--
-- Name: index_reports_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_reports_on_account_id ON public.reports USING btree (account_id);


--
-- Name: index_reports_on_action_taken_by_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_reports_on_action_taken_by_account_id ON public.reports USING btree (action_taken_by_account_id) WHERE (action_taken_by_account_id IS NOT NULL);


--
-- Name: index_reports_on_assigned_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_reports_on_assigned_account_id ON public.reports USING btree (assigned_account_id) WHERE (assigned_account_id IS NOT NULL);


--
-- Name: index_reports_on_target_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_reports_on_target_account_id ON public.reports USING btree (target_account_id);


--
-- Name: index_scheduled_statuses_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_scheduled_statuses_on_account_id ON public.scheduled_statuses USING btree (account_id);


--
-- Name: index_scheduled_statuses_on_scheduled_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_scheduled_statuses_on_scheduled_at ON public.scheduled_statuses USING btree (scheduled_at);


--
-- Name: index_session_activations_on_access_token_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_session_activations_on_access_token_id ON public.session_activations USING btree (access_token_id);


--
-- Name: index_session_activations_on_session_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_session_activations_on_session_id ON public.session_activations USING btree (session_id);


--
-- Name: index_session_activations_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_session_activations_on_user_id ON public.session_activations USING btree (user_id);


--
-- Name: index_settings_on_thing_type_and_thing_id_and_var; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_settings_on_thing_type_and_thing_id_and_var ON public.settings USING btree (thing_type, thing_id, var);


--
-- Name: index_severed_relationships_on_local_account_and_event; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_severed_relationships_on_local_account_and_event ON public.severed_relationships USING btree (local_account_id, relationship_severance_event_id);


--
-- Name: index_severed_relationships_on_remote_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_severed_relationships_on_remote_account_id ON public.severed_relationships USING btree (remote_account_id);


--
-- Name: index_severed_relationships_on_unique_tuples; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_severed_relationships_on_unique_tuples ON public.severed_relationships USING btree (relationship_severance_event_id, local_account_id, direction, remote_account_id);


--
-- Name: index_site_uploads_on_var; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_site_uploads_on_var ON public.site_uploads USING btree (var);


--
-- Name: index_software_updates_on_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_software_updates_on_version ON public.software_updates USING btree (version);


--
-- Name: index_status_edits_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_status_edits_on_account_id ON public.status_edits USING btree (account_id);


--
-- Name: index_status_edits_on_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_status_edits_on_status_id ON public.status_edits USING btree (status_id);


--
-- Name: index_status_pins_on_account_id_and_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_status_pins_on_account_id_and_status_id ON public.status_pins USING btree (account_id, status_id);


--
-- Name: index_status_pins_on_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_status_pins_on_status_id ON public.status_pins USING btree (status_id);


--
-- Name: index_status_stats_on_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_status_stats_on_status_id ON public.status_stats USING btree (status_id);


--
-- Name: index_status_trends_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_status_trends_on_account_id ON public.status_trends USING btree (account_id);


--
-- Name: index_status_trends_on_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_status_trends_on_status_id ON public.status_trends USING btree (status_id);


--
-- Name: index_statuses_20190820; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_statuses_20190820 ON public.statuses USING btree (account_id, id DESC, visibility, updated_at) WHERE (deleted_at IS NULL);


--
-- Name: index_statuses_local_20190824; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_statuses_local_20190824 ON public.statuses USING btree (id DESC, account_id) WHERE ((local OR (uri IS NULL)) AND (deleted_at IS NULL) AND (visibility = 0) AND (reblog_of_id IS NULL) AND ((NOT reply) OR (in_reply_to_account_id = account_id)));


--
-- Name: index_statuses_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_statuses_on_account_id ON public.statuses USING btree (account_id);


--
-- Name: index_statuses_on_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_statuses_on_deleted_at ON public.statuses USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: index_statuses_on_in_reply_to_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_statuses_on_in_reply_to_account_id ON public.statuses USING btree (in_reply_to_account_id) WHERE (in_reply_to_account_id IS NOT NULL);


--
-- Name: index_statuses_on_in_reply_to_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_statuses_on_in_reply_to_id ON public.statuses USING btree (in_reply_to_id) WHERE (in_reply_to_id IS NOT NULL);


--
-- Name: index_statuses_on_reblog_of_id_and_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_statuses_on_reblog_of_id_and_account_id ON public.statuses USING btree (reblog_of_id, account_id);


--
-- Name: index_statuses_on_uri; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_statuses_on_uri ON public.statuses USING btree (uri text_pattern_ops) WHERE (uri IS NOT NULL);


--
-- Name: index_statuses_public_20200119; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_statuses_public_20200119 ON public.statuses USING btree (id DESC, account_id) WHERE ((deleted_at IS NULL) AND (visibility = 0) AND (reblog_of_id IS NULL) AND ((NOT reply) OR (in_reply_to_account_id = account_id)));


--
-- Name: index_statuses_tags_on_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_statuses_tags_on_status_id ON public.statuses_tags USING btree (status_id);


--
-- Name: index_tag_follows_on_account_id_and_tag_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_tag_follows_on_account_id_and_tag_id ON public.tag_follows USING btree (account_id, tag_id);


--
-- Name: index_tag_follows_on_tag_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_tag_follows_on_tag_id ON public.tag_follows USING btree (tag_id);


--
-- Name: index_tags_on_name_lower_btree; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_tags_on_name_lower_btree ON public.tags USING btree (lower((name)::text) text_pattern_ops);


--
-- Name: index_tombstones_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_tombstones_on_account_id ON public.tombstones USING btree (account_id);


--
-- Name: index_tombstones_on_uri; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_tombstones_on_uri ON public.tombstones USING btree (uri);


--
-- Name: index_unavailable_domains_on_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_unavailable_domains_on_domain ON public.unavailable_domains USING btree (domain);


--
-- Name: index_unique_conversations; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_unique_conversations ON public.account_conversations USING btree (account_id, conversation_id, participant_account_ids);


--
-- Name: index_user_invite_requests_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_user_invite_requests_on_user_id ON public.user_invite_requests USING btree (user_id);


--
-- Name: index_users_on_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_users_on_account_id ON public.users USING btree (account_id);


--
-- Name: index_users_on_confirmation_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_users_on_confirmation_token ON public.users USING btree (confirmation_token);


--
-- Name: index_users_on_created_by_application_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_users_on_created_by_application_id ON public.users USING btree (created_by_application_id) WHERE (created_by_application_id IS NOT NULL);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token text_pattern_ops) WHERE (reset_password_token IS NOT NULL);


--
-- Name: index_users_on_role_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_users_on_role_id ON public.users USING btree (role_id) WHERE (role_id IS NOT NULL);


--
-- Name: index_users_on_unconfirmed_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_users_on_unconfirmed_email ON public.users USING btree (unconfirmed_email) WHERE (unconfirmed_email IS NOT NULL);


--
-- Name: index_web_push_subscriptions_on_access_token_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_web_push_subscriptions_on_access_token_id ON public.web_push_subscriptions USING btree (access_token_id) WHERE (access_token_id IS NOT NULL);


--
-- Name: index_web_push_subscriptions_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_web_push_subscriptions_on_user_id ON public.web_push_subscriptions USING btree (user_id);


--
-- Name: index_web_settings_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_web_settings_on_user_id ON public.web_settings USING btree (user_id);


--
-- Name: index_webauthn_credentials_on_external_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_webauthn_credentials_on_external_id ON public.webauthn_credentials USING btree (external_id);


--
-- Name: index_webauthn_credentials_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_webauthn_credentials_on_user_id ON public.webauthn_credentials USING btree (user_id);


--
-- Name: index_webauthn_credentials_on_user_id_and_nickname; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_webauthn_credentials_on_user_id_and_nickname ON public.webauthn_credentials USING btree (user_id, nickname);


--
-- Name: index_webhooks_on_url; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_webhooks_on_url ON public.webhooks USING btree (url);


--
-- Name: search_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX search_index ON public.accounts USING gin ((((setweight(to_tsvector('simple'::regconfig, (display_name)::text), 'A'::"char") || setweight(to_tsvector('simple'::regconfig, (username)::text), 'B'::"char")) || setweight(to_tsvector('simple'::regconfig, (COALESCE(domain, ''::character varying))::text), 'C'::"char"))));


--
-- Name: web_settings fk_11910667b2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.web_settings
    ADD CONSTRAINT fk_11910667b2 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: account_domain_blocks fk_206c6029bd; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_domain_blocks
    ADD CONSTRAINT fk_206c6029bd FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: conversation_mutes fk_225b4212bb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_mutes
    ADD CONSTRAINT fk_225b4212bb FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: statuses_tags fk_3081861e21; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statuses_tags
    ADD CONSTRAINT fk_3081861e21 FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: follows fk_32ed1b5560; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT fk_32ed1b5560 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: oauth_access_grants fk_34d54b0a33; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_grants
    ADD CONSTRAINT fk_34d54b0a33 FOREIGN KEY (application_id) REFERENCES public.oauth_applications(id) ON DELETE CASCADE;


--
-- Name: blocks fk_4269e03e65; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blocks
    ADD CONSTRAINT fk_4269e03e65 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: reports fk_4b81f7522c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT fk_4b81f7522c FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: users fk_50500f500d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_50500f500d FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: favourites fk_5eb6c2b873; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favourites
    ADD CONSTRAINT fk_5eb6c2b873 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: oauth_access_grants fk_63b044929b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_grants
    ADD CONSTRAINT fk_63b044929b FOREIGN KEY (resource_owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: imports fk_6db1b6e408; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imports
    ADD CONSTRAINT fk_6db1b6e408 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: follows fk_745ca29eac; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT fk_745ca29eac FOREIGN KEY (target_account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: follow_requests fk_76d644b0e7; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follow_requests
    ADD CONSTRAINT fk_76d644b0e7 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: follow_requests fk_9291ec025d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follow_requests
    ADD CONSTRAINT fk_9291ec025d FOREIGN KEY (target_account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: blocks fk_9571bfabc1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blocks
    ADD CONSTRAINT fk_9571bfabc1 FOREIGN KEY (target_account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: session_activations fk_957e5bda89; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_activations
    ADD CONSTRAINT fk_957e5bda89 FOREIGN KEY (access_token_id) REFERENCES public.oauth_access_tokens(id) ON DELETE CASCADE;


--
-- Name: media_attachments fk_96dd81e81b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_attachments
    ADD CONSTRAINT fk_96dd81e81b FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE SET NULL;


--
-- Name: mentions fk_970d43f9d1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentions
    ADD CONSTRAINT fk_970d43f9d1 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: statuses fk_9bda1543f7; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT fk_9bda1543f7 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: oauth_applications fk_b0988c7c0a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_applications
    ADD CONSTRAINT fk_b0988c7c0a FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: favourites fk_b0e856845e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favourites
    ADD CONSTRAINT fk_b0e856845e FOREIGN KEY (status_id) REFERENCES public.statuses(id) ON DELETE CASCADE;


--
-- Name: mutes fk_b8d8daf315; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mutes
    ADD CONSTRAINT fk_b8d8daf315 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: reports fk_bca45b75fd; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT fk_bca45b75fd FOREIGN KEY (action_taken_by_account_id) REFERENCES public.accounts(id) ON DELETE SET NULL;


--
-- Name: identities fk_bea040f377; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identities
    ADD CONSTRAINT fk_bea040f377 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications fk_c141c8ee55; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_c141c8ee55 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: statuses fk_c7fa917661; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT fk_c7fa917661 FOREIGN KEY (in_reply_to_account_id) REFERENCES public.accounts(id) ON DELETE SET NULL;


--
-- Name: status_pins fk_d4cb435b62; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_pins
    ADD CONSTRAINT fk_d4cb435b62 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: session_activations fk_e5fda67334; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_activations
    ADD CONSTRAINT fk_e5fda67334 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: oauth_access_tokens fk_e84df68546; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT fk_e84df68546 FOREIGN KEY (resource_owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reports fk_eb37af34f0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT fk_eb37af34f0 FOREIGN KEY (target_account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: mutes fk_eecff219ea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mutes
    ADD CONSTRAINT fk_eecff219ea FOREIGN KEY (target_account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: oauth_access_tokens fk_f5fc4c1ee3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT fk_f5fc4c1ee3 FOREIGN KEY (application_id) REFERENCES public.oauth_applications(id) ON DELETE CASCADE;


--
-- Name: notifications fk_fbd6b0bf9e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_fbd6b0bf9e FOREIGN KEY (from_account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: account_relationship_severance_events fk_rails_030c916965; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_relationship_severance_events
    ADD CONSTRAINT fk_rails_030c916965 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: tag_follows fk_rails_091e831473; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tag_follows
    ADD CONSTRAINT fk_rails_091e831473 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: backups fk_rails_096669d221; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT fk_rails_096669d221 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tag_follows fk_rails_0deefe597f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tag_follows
    ADD CONSTRAINT fk_rails_0deefe597f FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: bookmarks fk_rails_11207ffcfd; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookmarks
    ADD CONSTRAINT fk_rails_11207ffcfd FOREIGN KEY (status_id) REFERENCES public.statuses(id) ON DELETE CASCADE;


--
-- Name: account_conversations fk_rails_1491654f9f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_conversations
    ADD CONSTRAINT fk_rails_1491654f9f FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: featured_tags fk_rails_174efcf15f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.featured_tags
    ADD CONSTRAINT fk_rails_174efcf15f FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: bulk_imports fk_rails_1d89c0f8b2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bulk_imports
    ADD CONSTRAINT fk_rails_1d89c0f8b2 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: canonical_email_blocks fk_rails_1ecb262096; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.canonical_email_blocks
    ADD CONSTRAINT fk_rails_1ecb262096 FOREIGN KEY (reference_account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: account_stats fk_rails_215bb31ff1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_stats
    ADD CONSTRAINT fk_rails_215bb31ff1 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: accounts fk_rails_2320833084; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT fk_rails_2320833084 FOREIGN KEY (moved_to_account_id) REFERENCES public.accounts(id) ON DELETE SET NULL;


--
-- Name: featured_tags fk_rails_23a9055c7c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.featured_tags
    ADD CONSTRAINT fk_rails_23a9055c7c FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: scheduled_statuses fk_rails_23bd9018f9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduled_statuses
    ADD CONSTRAINT fk_rails_23bd9018f9 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: account_statuses_cleanup_policies fk_rails_23d5f73cfe; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_statuses_cleanup_policies
    ADD CONSTRAINT fk_rails_23d5f73cfe FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: statuses fk_rails_256483a9ab; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT fk_rails_256483a9ab FOREIGN KEY (reblog_of_id) REFERENCES public.statuses(id) ON DELETE CASCADE;


--
-- Name: account_notes fk_rails_2801b48f1a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_notes
    ADD CONSTRAINT fk_rails_2801b48f1a FOREIGN KEY (target_account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: custom_filter_statuses fk_rails_2f6d20c0cf; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_filter_statuses
    ADD CONSTRAINT fk_rails_2f6d20c0cf FOREIGN KEY (status_id) REFERENCES public.statuses(id) ON DELETE CASCADE;


--
-- Name: media_attachments fk_rails_31fc5aeef1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_attachments
    ADD CONSTRAINT fk_rails_31fc5aeef1 FOREIGN KEY (scheduled_status_id) REFERENCES public.scheduled_statuses(id) ON DELETE SET NULL;


--
-- Name: preview_card_trends fk_rails_371593db34; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preview_card_trends
    ADD CONSTRAINT fk_rails_371593db34 FOREIGN KEY (preview_card_id) REFERENCES public.preview_cards(id) ON DELETE CASCADE;


--
-- Name: user_invite_requests fk_rails_3773f15361; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_invite_requests
    ADD CONSTRAINT fk_rails_3773f15361 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: lists fk_rails_3853b78dac; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lists
    ADD CONSTRAINT fk_rails_3853b78dac FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: reports fk_rails_3deb8c7acb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT fk_rails_3deb8c7acb FOREIGN KEY (application_id) REFERENCES public.oauth_applications(id) ON DELETE SET NULL;


--
-- Name: polls fk_rails_3e0d9f1115; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT fk_rails_3e0d9f1115 FOREIGN KEY (status_id) REFERENCES public.statuses(id) ON DELETE CASCADE;


--
-- Name: media_attachments fk_rails_3ec0cfdd70; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_attachments
    ADD CONSTRAINT fk_rails_3ec0cfdd70 FOREIGN KEY (status_id) REFERENCES public.statuses(id) ON DELETE SET NULL;


--
-- Name: account_moderation_notes fk_rails_3f8b75089b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_moderation_notes
    ADD CONSTRAINT fk_rails_3f8b75089b FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: email_domain_blocks fk_rails_408efe0a15; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_domain_blocks
    ADD CONSTRAINT fk_rails_408efe0a15 FOREIGN KEY (parent_id) REFERENCES public.email_domain_blocks(id) ON DELETE CASCADE;


--
-- Name: list_accounts fk_rails_40f9cc29f1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.list_accounts
    ADD CONSTRAINT fk_rails_40f9cc29f1 FOREIGN KEY (follow_id) REFERENCES public.follows(id) ON DELETE CASCADE;


--
-- Name: account_deletion_requests fk_rails_45bf2626b9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_deletion_requests
    ADD CONSTRAINT fk_rails_45bf2626b9 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: status_stats fk_rails_4a247aac42; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_stats
    ADD CONSTRAINT fk_rails_4a247aac42 FOREIGN KEY (status_id) REFERENCES public.statuses(id) ON DELETE CASCADE;


--
-- Name: generated_annual_reports fk_rails_4ca37f035c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generated_annual_reports
    ADD CONSTRAINT fk_rails_4ca37f035c FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: reports fk_rails_4e7a498fb4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT fk_rails_4e7a498fb4 FOREIGN KEY (assigned_account_id) REFERENCES public.accounts(id) ON DELETE SET NULL;


--
-- Name: account_notes fk_rails_4ee4503c69; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_notes
    ADD CONSTRAINT fk_rails_4ee4503c69 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: appeals fk_rails_501c3a6e13; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appeals
    ADD CONSTRAINT fk_rails_501c3a6e13 FOREIGN KEY (rejected_by_account_id) REFERENCES public.accounts(id) ON DELETE SET NULL;


--
-- Name: severed_relationships fk_rails_5054494e1e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.severed_relationships
    ADD CONSTRAINT fk_rails_5054494e1e FOREIGN KEY (relationship_severance_event_id) REFERENCES public.relationship_severance_events(id) ON DELETE CASCADE;


--
-- Name: notification_policies fk_rails_506d62f0da; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_policies
    ADD CONSTRAINT fk_rails_506d62f0da FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: notification_requests fk_rails_5632f121b4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_requests
    ADD CONSTRAINT fk_rails_5632f121b4 FOREIGN KEY (from_account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: mentions fk_rails_59edbe2887; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentions
    ADD CONSTRAINT fk_rails_59edbe2887 FOREIGN KEY (status_id) REFERENCES public.statuses(id) ON DELETE CASCADE;


--
-- Name: custom_filter_keywords fk_rails_5a49a74012; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_filter_keywords
    ADD CONSTRAINT fk_rails_5a49a74012 FOREIGN KEY (custom_filter_id) REFERENCES public.custom_filters(id) ON DELETE CASCADE;


--
-- Name: conversation_mutes fk_rails_5ab139311f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_mutes
    ADD CONSTRAINT fk_rails_5ab139311f FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: polls fk_rails_5b19a0c011; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT fk_rails_5b19a0c011 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: notification_requests fk_rails_61c7aa9c1f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_requests
    ADD CONSTRAINT fk_rails_61c7aa9c1f FOREIGN KEY (last_status_id) REFERENCES public.statuses(id) ON DELETE SET NULL;


--
-- Name: users fk_rails_642f17018b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_rails_642f17018b FOREIGN KEY (role_id) REFERENCES public.user_roles(id) ON DELETE SET NULL;


--
-- Name: status_pins fk_rails_65c05552f1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_pins
    ADD CONSTRAINT fk_rails_65c05552f1 FOREIGN KEY (status_id) REFERENCES public.statuses(id) ON DELETE CASCADE;


--
-- Name: status_trends fk_rails_68c610dc1a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_trends
    ADD CONSTRAINT fk_rails_68c610dc1a FOREIGN KEY (status_id) REFERENCES public.statuses(id) ON DELETE CASCADE;


--
-- Name: account_conversations fk_rails_6f5278b6e9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_conversations
    ADD CONSTRAINT fk_rails_6f5278b6e9 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: announcement_reactions fk_rails_7444ad831f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_reactions
    ADD CONSTRAINT fk_rails_7444ad831f FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: web_push_subscriptions fk_rails_751a9f390b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.web_push_subscriptions
    ADD CONSTRAINT fk_rails_751a9f390b FOREIGN KEY (access_token_id) REFERENCES public.oauth_access_tokens(id) ON DELETE CASCADE;


--
-- Name: notification_permissions fk_rails_7c0bed08df; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_permissions
    ADD CONSTRAINT fk_rails_7c0bed08df FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: report_notes fk_rails_7fa83a61eb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_notes
    ADD CONSTRAINT fk_rails_7fa83a61eb FOREIGN KEY (report_id) REFERENCES public.reports(id) ON DELETE CASCADE;


--
-- Name: list_accounts fk_rails_85fee9d6ab; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.list_accounts
    ADD CONSTRAINT fk_rails_85fee9d6ab FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: notification_requests fk_rails_881c7f71c4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_requests
    ADD CONSTRAINT fk_rails_881c7f71c4 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: account_relationship_severance_events fk_rails_8a34c3a361; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_relationship_severance_events
    ADD CONSTRAINT fk_rails_8a34c3a361 FOREIGN KEY (relationship_severance_event_id) REFERENCES public.relationship_severance_events(id) ON DELETE CASCADE;


--
-- Name: custom_filters fk_rails_8b8d786993; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_filters
    ADD CONSTRAINT fk_rails_8b8d786993 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: account_warnings fk_rails_8f2bab4b16; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_warnings
    ADD CONSTRAINT fk_rails_8f2bab4b16 FOREIGN KEY (report_id) REFERENCES public.reports(id) ON DELETE CASCADE;


--
-- Name: users fk_rails_8fb2a43e88; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_rails_8fb2a43e88 FOREIGN KEY (invite_id) REFERENCES public.invites(id) ON DELETE SET NULL;


--
-- Name: statuses fk_rails_94a6f70399; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT fk_rails_94a6f70399 FOREIGN KEY (in_reply_to_id) REFERENCES public.statuses(id) ON DELETE SET NULL;


--
-- Name: severed_relationships fk_rails_98ff099d4c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.severed_relationships
    ADD CONSTRAINT fk_rails_98ff099d4c FOREIGN KEY (local_account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: announcement_mutes fk_rails_9c99f8e835; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_mutes
    ADD CONSTRAINT fk_rails_9c99f8e835 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: appeals fk_rails_9deb2f63ad; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appeals
    ADD CONSTRAINT fk_rails_9deb2f63ad FOREIGN KEY (approved_by_account_id) REFERENCES public.accounts(id) ON DELETE SET NULL;


--
-- Name: bookmarks fk_rails_9f6ac182a6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookmarks
    ADD CONSTRAINT fk_rails_9f6ac182a6 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: announcement_reactions fk_rails_a1226eaa5c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_reactions
    ADD CONSTRAINT fk_rails_a1226eaa5c FOREIGN KEY (announcement_id) REFERENCES public.announcements(id) ON DELETE CASCADE;


--
-- Name: account_pins fk_rails_a176e26c37; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_pins
    ADD CONSTRAINT fk_rails_a176e26c37 FOREIGN KEY (target_account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials fk_rails_a4355aef77; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT fk_rails_a4355aef77 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: account_warnings fk_rails_a65a1bf71b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_warnings
    ADD CONSTRAINT fk_rails_a65a1bf71b FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE SET NULL;


--
-- Name: status_trends fk_rails_a6b527ea49; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_trends
    ADD CONSTRAINT fk_rails_a6b527ea49 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: poll_votes fk_rails_a6e6974b7e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_votes
    ADD CONSTRAINT fk_rails_a6e6974b7e FOREIGN KEY (poll_id) REFERENCES public.polls(id) ON DELETE CASCADE;


--
-- Name: markers fk_rails_a7009bc2b6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.markers
    ADD CONSTRAINT fk_rails_a7009bc2b6 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: admin_action_logs fk_rails_a7667297fa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_action_logs
    ADD CONSTRAINT fk_rails_a7667297fa FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: account_warnings fk_rails_a7ebbb1e37; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_warnings
    ADD CONSTRAINT fk_rails_a7ebbb1e37 FOREIGN KEY (target_account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: status_edits fk_rails_a960f234a0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_edits
    ADD CONSTRAINT fk_rails_a960f234a0 FOREIGN KEY (status_id) REFERENCES public.statuses(id) ON DELETE CASCADE;


--
-- Name: appeals fk_rails_a99f14546e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appeals
    ADD CONSTRAINT fk_rails_a99f14546e FOREIGN KEY (account_warning_id) REFERENCES public.account_warnings(id) ON DELETE CASCADE;


--
-- Name: follow_recommendation_mutes fk_rails_a9f09ec9a8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follow_recommendation_mutes
    ADD CONSTRAINT fk_rails_a9f09ec9a8 FOREIGN KEY (target_account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: web_push_subscriptions fk_rails_b006f28dac; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.web_push_subscriptions
    ADD CONSTRAINT fk_rails_b006f28dac FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: poll_votes fk_rails_b6c18cf44a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_votes
    ADD CONSTRAINT fk_rails_b6c18cf44a FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: announcement_reactions fk_rails_b742c91c0e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_reactions
    ADD CONSTRAINT fk_rails_b742c91c0e FOREIGN KEY (custom_emoji_id) REFERENCES public.custom_emojis(id) ON DELETE CASCADE;


--
-- Name: account_migrations fk_rails_c9f701caaf; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_migrations
    ADD CONSTRAINT fk_rails_c9f701caaf FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: report_notes fk_rails_cae66353f3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_notes
    ADD CONSTRAINT fk_rails_cae66353f3 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: follow_recommendation_mutes fk_rails_d36abd69ea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follow_recommendation_mutes
    ADD CONSTRAINT fk_rails_d36abd69ea FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: bulk_import_rows fk_rails_d39af34335; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bulk_import_rows
    ADD CONSTRAINT fk_rails_d39af34335 FOREIGN KEY (bulk_import_id) REFERENCES public.bulk_imports(id) ON DELETE CASCADE;


--
-- Name: account_pins fk_rails_d44979e5dd; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_pins
    ADD CONSTRAINT fk_rails_d44979e5dd FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: account_migrations fk_rails_d9a8dad070; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_migrations
    ADD CONSTRAINT fk_rails_d9a8dad070 FOREIGN KEY (target_account_id) REFERENCES public.accounts(id) ON DELETE SET NULL;


--
-- Name: status_edits fk_rails_dc8988c545; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_edits
    ADD CONSTRAINT fk_rails_dc8988c545 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE SET NULL;


--
-- Name: preview_cards fk_rails_dca4905b94; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preview_cards
    ADD CONSTRAINT fk_rails_dca4905b94 FOREIGN KEY (author_account_id) REFERENCES public.accounts(id) ON DELETE SET NULL;


--
-- Name: account_moderation_notes fk_rails_dd62ed5ac3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_moderation_notes
    ADD CONSTRAINT fk_rails_dd62ed5ac3 FOREIGN KEY (target_account_id) REFERENCES public.accounts(id);


--
-- Name: statuses_tags fk_rails_df0fe11427; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statuses_tags
    ADD CONSTRAINT fk_rails_df0fe11427 FOREIGN KEY (status_id) REFERENCES public.statuses(id) ON DELETE CASCADE;


--
-- Name: follow_recommendation_suppressions fk_rails_dfb9a1dbe2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follow_recommendation_suppressions
    ADD CONSTRAINT fk_rails_dfb9a1dbe2 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: custom_filter_statuses fk_rails_e2ddaf5b14; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_filter_statuses
    ADD CONSTRAINT fk_rails_e2ddaf5b14 FOREIGN KEY (custom_filter_id) REFERENCES public.custom_filters(id) ON DELETE CASCADE;


--
-- Name: announcement_mutes fk_rails_e35401adf1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_mutes
    ADD CONSTRAINT fk_rails_e35401adf1 FOREIGN KEY (announcement_id) REFERENCES public.announcements(id) ON DELETE CASCADE;


--
-- Name: notification_permissions fk_rails_e3e0aaad70; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_permissions
    ADD CONSTRAINT fk_rails_e3e0aaad70 FOREIGN KEY (from_account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: login_activities fk_rails_e4b6396b41; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_activities
    ADD CONSTRAINT fk_rails_e4b6396b41 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: list_accounts fk_rails_e54e356c88; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.list_accounts
    ADD CONSTRAINT fk_rails_e54e356c88 FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: appeals fk_rails_ea84881569; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appeals
    ADD CONSTRAINT fk_rails_ea84881569 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: users fk_rails_ecc9536e7c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_rails_ecc9536e7c FOREIGN KEY (created_by_application_id) REFERENCES public.oauth_applications(id) ON DELETE SET NULL;


--
-- Name: list_accounts fk_rails_f11f9d1fcc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.list_accounts
    ADD CONSTRAINT fk_rails_f11f9d1fcc FOREIGN KEY (follow_request_id) REFERENCES public.follow_requests(id) ON DELETE CASCADE;


--
-- Name: severed_relationships fk_rails_f7afd97ba4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.severed_relationships
    ADD CONSTRAINT fk_rails_f7afd97ba4 FOREIGN KEY (remote_account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: tombstones fk_rails_f95b861449; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tombstones
    ADD CONSTRAINT fk_rails_f95b861449 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: account_aliases fk_rails_fc91575d08; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_aliases
    ADD CONSTRAINT fk_rails_fc91575d08 FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: invites fk_rails_ff69dbb2ac; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT fk_rails_ff69dbb2ac FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: account_summaries; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public.account_summaries;


--
-- Name: global_follow_recommendations; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public.global_follow_recommendations;


--
-- Name: instances; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public.instances;


--
-- PostgreSQL database dump complete
--

\unrestrict WvlNJr3bqBYGRdg5bcOhWv9ARkFq3o0Iuw8mpiVzraDk7BgFWGSuRJR3rVKFbqA

